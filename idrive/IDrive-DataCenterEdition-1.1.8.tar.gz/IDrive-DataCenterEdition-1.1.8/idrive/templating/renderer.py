'''ldb.templating.renderer'''

from jinja2 import Environment, PackageLoader as PL
from os.path import basename, dirname, join

from idrive import PRODUCT, EMAIL
from idrive.utils.size_format import size_format


class Renderer(object):
    '''
    Simple class to handle rendering of all application templates outside of
    the webui package. All templates should go inside the ./templates
    directory.
    '''

    def __init__(self):
        self.ENV = Environment(loader=PL(basename(dirname(dirname(__file__))),
                                         join('templating', 'templates')))
        self.add_filters()
        self.add_globals()
        self.add_tests()

    def render(self, template_name, **kwargs):
        '''
        renders a template

        @param template_name: path to template file
        @param kwargs: optional keyword args to pass on to the template
        @return: the rendered template as a unicode string
        '''
        return self.ENV.get_template(template_name).render(**kwargs)

    def __add_item(self, dict_name, **items):
        '''
        Add items(s) to the jinja environment dict. The item will be available
        by the key name of the kwarg passed in

        @raise KeyError: if item name already exists
        '''
        env_dict = getattr(self.ENV, dict_name)

        for key, item in items.iteritems():
            if key in env_dict:
                raise KeyError('The {} filter name already exists'.format(key))

            env_dict[key] = item

    def add_filters(self):
        '''
        Internal hook for customizing the jinja environment by adding new
        filters to the filters dict on creation.
        '''
        self.add_filter(prettysize=size_format)

    def add_filter(self, **filters):
        '''
        Add filter(s) to the current environment. The filter will be available
        by the key name of the kwarg passed in
        '''
        self.__add_item('filters', **filters)

    def add_globals(self):
        '''
        Internal hook for customizing the jinja environment by adding new
        global vars to the globals dict on creation.
        '''
        self.add_global(PRODUCT=PRODUCT)
        self.add_global(SUPPORT_EMAIL=EMAIL)

    def add_global(self, **globals_):
        '''
        Add global var(s) to the current environment. The var will be available
        by the key name of the kwarg passed in
        '''
        self.__add_item('globals', **globals_)

    def add_tests(self):
        '''
        Internal hook for customizing the jinja environment by adding new
        tests to the tests dict on creation.
        '''
        pass

    def add_test(self, **tests):
        '''
        Add test(s) to the current environment. The test will be available
        by the key name of the kwarg passed in
        '''
        self.__add_item('tests', **tests)
