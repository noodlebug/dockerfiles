"""Login data after user logs in.

Singleton class to share data across modules.

"""

import cPickle as pickle
import os

from idrive.conf.settings import UserSettings
from idrive.utils.encryption import encrypt_data, decrypt_data, EncryptError
from idrive.utils.singleton import MetaSingleton


class LoginData(object):
    """Singleton class to share login info across modules."""

    __metaclass__ = MetaSingleton

    LOGIN_DATA_FILE = 'login.data'

    def __init__(self):
        """Constructor.

        If only username is provided, tries to load login data from disk.
        If password is also provided, it means its new LoginData, set()
        will be called to sync new data to disk.

        """

        self._username = None
        self._password = None
        self._pvtkey = None

    def load(self, username):
        """Load the login details from disk for particular username."""

        login_data_file = os.path.join(UserSettings(username).LOGIN_DATA.path,
                                       self.LOGIN_DATA_FILE)

        if os.path.exists(login_data_file):
            try:
                with open(login_data_file, 'r') as f:
                    login_data = pickle.loads(decrypt_data(f.read()))
            except (OSError, EncryptError) as err:
                raise OSError(err)
            else:
                self.__dict__.update(login_data.__dict__)
        else:
            raise ValueError("Login details not found for '{}'"
                             .format(username))

        return self

    def set(self, username, password, pvtkey=None):
        """Setter.

        Automatically syncs to disk. Call set() with password as None to
        delete data file.

        """

        user_settings = UserSettings(username)
        if not os.path.exists(user_settings.REMOTE.path):
            os.makedirs(user_settings.REMOTE.path, mode=0700)

        login_data_file = os.path.join(user_settings.LOGIN_DATA.path,
                                       self.LOGIN_DATA_FILE)

        self._username = username
        self._password = password
        self._pvtkey = pvtkey

        if password is None:
            if os.path.exists(login_data_file):
                os.remove(login_data_file)
        else:
            try:
                with open(login_data_file, 'w') as f:
                    f.write(encrypt_data(pickle.dumps(self)))
            except (OSError, EncryptError) as err:
                raise OSError(err)

        return self

    def get(self):
        """Getter."""

        return self._username, self._password, self._pvtkey
