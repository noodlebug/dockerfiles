from wtforms import Form
from wtforms.validators import DataRequired, Length
from wtforms.fields.core import StringField


class SearchForm(Form):
    '''Generic search form'''

    q = StringField('Search Query', [DataRequired(), Length(3, 50)])
