import datetime

from wtforms import Form, TextField, StringField, ValidationError, validators


class LogsForm(Form):
    '''Logs Form'''

    since_date = TextField('Since Date')

    def validate_since_date(self, field):
        """since date validation."""

        if not field.data:
            return

        try:
            since_date = datetime.datetime.strptime(field.data, '%Y:%m:%d')
        except ValueError:
            raise ValidationError("Invalid date")

        if since_date - datetime.datetime.now() > datetime.timedelta(0, 1):
            raise ValidationError("Cannot be in future")

        field.data = since_date.date()


class RecordIdForm(Form):
    """Record id"""

    # Note: validator should be DataRequired(), not InputRequired() for
    #  it to work with non form data, like URL segment
    # Note: record_id is not stored as int in LogRecord, but as a string.
    #  Don't use IntegerField, just validate its a string of digits.
    record_id = StringField('Log Record', [validators.DataRequired()])

    def validate_record_id(self, field):
        """Must be a string of digits."""
        try:
            int(field.data)
        except ValueError:
            raise ValidationError("Must be digits only")
