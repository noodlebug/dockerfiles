'''Backup/restore set update form'''

from wtforms import Form, StringField
from wtforms.fields.core import FieldList, IntegerField
from wtforms.validators import InputRequired, AnyOf, Optional, NumberRange

from idrive.webui.app.helpers.form_validations import ValidPath


class SetUpdateForm(Form):
    '''Set Update Form'''

    operation = StringField('Set Operation', [InputRequired(),
                                              AnyOf(['add', 'remove'],
                            message='Please specify a valid set operation')])

    paths = FieldList(StringField('Path', [InputRequired(), ValidPath()]))

    versions = FieldList(IntegerField('Version', [Optional(),
                                                  NumberRange(min=0)]))
