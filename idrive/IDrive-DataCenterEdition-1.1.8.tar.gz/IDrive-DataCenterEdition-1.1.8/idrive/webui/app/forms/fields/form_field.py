'''ldb.webui.app.forms.fields.form_field'''

from wtforms import FormField

from idrive.webui.app.forms.widgets.form_field import LDBFormFieldWidget


class LDBFormField(FormField):
    '''The form field provides better default rendering of its Field items.
    Normally all fields in here would be rendered in a <table>. This just
    replaces the default.
    '''

    widget = LDBFormFieldWidget()
