'''ldb.webui.app.forms.widgets.form_field'''

from wtforms.widgets import html_params, HTMLString


class LDBFormFieldWidget(object):

    def __init__(self, row=False):
        self.row = row

    def __call__(self, field, **kwargs):
        '''Better widget for rendering a FormField that doesn't use
        <table>s
        '''
        kwargs.setdefault('id', field.id)
        kwargs.setdefault('class', 'form-field')
        if self.row:
            kwargs['class'] += ' row'

        html = ['<div %s>' % html_params(**kwargs)]
        for subfield in field:
            html.append(subfield())
        html.append('</div>')

        return HTMLString(u''.join(html))
