'''Account login forms

Note: even though these forms are similar, do not change the field [name]
attributes to be simply "username" or "password". It messes up the autofill
behavior. See bug #311 for details.
'''

from wtforms import Form, StringField, PasswordField, validators

from idrive import PRODUCT


class LocalLoginForm(Form):
    '''Local Login Form'''

    local_username = StringField(u'Local System Username', [
        validators.InputRequired()
    ])

    local_password = PasswordField(u'Local System Password', [
        validators.InputRequired()
    ])


class RemoteLoginForm(Form):
    '''Remote Login Form'''

    remote_username = StringField(u'{} Username'.format(PRODUCT), [
        validators.InputRequired(),
        validators.Length(min=4)
    ])

    remote_password = PasswordField(u'{} Password'.format(PRODUCT), [
        validators.InputRequired(),
        validators.Length(min=4)
    ])
