'''Optional Unless custom validator'''

from wtforms.validators import StopValidation, DataRequired


class OptionalUnless(DataRequired):
    '''
    a validator which makes a field optional unless other field(s) are set
    and have a truth-y value or the value specified

    @note: this class inherits from DataRequired and not InputRequired because
           it can be used on a FieldList in which case it needs the
           post-coercion data for the tests
    '''

    def __init__(self, other_field_name, required_value=None, *args, **kwargs):
        if not isinstance(other_field_name, list):
            other_field_name = [other_field_name]

        self.other_field_names = other_field_name
        self.required_value = required_value
        super(OptionalUnless, self).__init__(*args, **kwargs)

    def __call__(self, form, field):
        required = False

        for other_field_name in self.other_field_names:
            other_field = form._fields.get(other_field_name)
            if other_field is None:
                raise Exception('no field named "%s" in form' %
                                other_field_name)

            if self.required_value is not None:
                if other_field.data == self.required_value:
                    required = True
                    break

            elif bool(other_field.data):
                required = True
                break

        if required:
            super(OptionalUnless, self).__call__(form, field)
        elif not field.raw_data or not field.raw_data[0]:
            field.errors[:] = []
            raise StopValidation()  # if not required & has no data we're done
