'''Settings specific validators'''

SETTING_FLAGS = {
    'LOCAL': 'local',
    'REMOTE': 'remote'
}


class RemoteSetting(object):
    """
    Sets a flag on the field to mark it as a remote setting
    """
    field_flags = (SETTING_FLAGS['REMOTE'],)

    def __call__(self, form, field):
        pass


class LocalSetting(object):
    """
    Sets a flag on the field to mark it as a local setting
    """
    field_flags = (SETTING_FLAGS['LOCAL'],)

    def __call__(self, form, field):
        pass
