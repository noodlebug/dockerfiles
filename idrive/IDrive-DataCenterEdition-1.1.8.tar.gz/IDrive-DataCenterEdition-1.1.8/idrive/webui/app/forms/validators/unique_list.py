'''unique field list validation'''

from wtforms import ValidationError


class UniqueList(object):
    '''
    Ensures the field list has all unique values
    '''

    def __init__(self, message=None):
        if not message:
            message = u'Must not contain duplicate values'
        self.message = message

    def __call__(self, form, fieldlist):
        values = []

        for entry in fieldlist.entries:
            if entry.data in values:
                raise ValidationError(self.message)
            values.append(entry.data)
