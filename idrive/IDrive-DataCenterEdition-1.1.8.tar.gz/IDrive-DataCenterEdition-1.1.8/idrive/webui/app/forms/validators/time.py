'''time validation'''

import re

from wtforms import ValidationError

from idrive.utils.validations import time_occurs_after
from idrive.webui.app.helpers.time import time_from_hms


class Time(object):
    '''
    Validates time formatting
    '''

    def __call__(self, form, field):
        """Valid time."""
        if re.match(r'^\d{1,2}:\d{2}:\d{2}', field.data) is None:
            raise ValidationError('Must be in HH:MM:SS format')

        hour, minute, second = [int(x) for x in field.data.split(':')]
        if (hour < 0 or hour > 24 or minute < 0 or minute > 59 or
                second < 0 or second > 50):
            raise ValidationError('Not a real time')


class OccursAfter(object):
    '''validates that the field's time occurs after another field's time'''

    def __init__(self, other_field_name):
        self.other_field_name = other_field_name

    def __call__(self, form, field):
        other_field = form._fields.get(self.other_field_name)
        if other_field is None:
            raise Exception('no field named "%s" in form' %
                            self.other_field_name)

        given_time = time_from_hms(other_field.data)
        later_time = time_from_hms(field.data)

        if not time_occurs_after(given_time, later_time):
            error = '{} does not occur after {}'.format(
                later_time.strftime('%I:%M %p'),
                given_time.strftime('%I:%M %p'))
            raise ValidationError(error)
