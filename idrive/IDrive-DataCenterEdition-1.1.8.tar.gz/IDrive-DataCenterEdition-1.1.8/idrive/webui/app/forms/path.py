'''Generic form that validates paths'''

from wtforms import Form, StringField
from wtforms.fields.core import FieldList
from wtforms.validators import InputRequired, DataRequired
from idrive.webui.app.helpers.form_validations import ValidPath


class PathForm(Form):
    '''Path Form'''

    path = StringField('Path', [InputRequired(), ValidPath()])


class PathsForm(Form):
    '''Multiple Paths Form'''

    paths = FieldList(StringField('Paths', [InputRequired(), ValidPath()]),
                      min_entries=1)


class DefaultPathForm(Form):
    '''Path Form
    If no path is provided, path will be '/'
    '''

    path = StringField('Path', [DataRequired(), ValidPath()], default='/')
