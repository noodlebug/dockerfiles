import re

from wtforms import Form, RadioField, PasswordField
from wtforms.validators import InputRequired, EqualTo, Regexp, Length

from idrive import PRODUCT
from idrive.webui.app.forms.validators.optional_unless import OptionalUnless

DEFAULT = 'default'
PRIVATE = 'private'


class ConfigureAccountForm(Form):
    '''Configure Account Form'''

    encryption_type = RadioField(
        u'Account Encryption Type',
        validators=[InputRequired()],
        choices=[(DEFAULT, 'Default Encryption'),
                 (PRIVATE, 'Private Key Encryption')],
        description=('Choose the desired encryption level for your account. '
                     'By choosing <i>"Default Encryption"</i>, {} will '
                     'set an encryption key to encrypt all your data. '
                     'Choosing <i>"Private Key Encryption"</i> will allow '
                     'you to set your own private encryption key to encrypt '
                     'all your data.'.format(PRODUCT)),
        default=DEFAULT)

    private_key = PasswordField(
        u'Private Encryption Key',
        validators=[OptionalUnless('encryption_type', required_value=PRIVATE),
                    Length(min=4, max=255),
                    Regexp(r'^[^ ]+$', re.IGNORECASE,
                           message='May not contain spaces'),
                    EqualTo('private_key_confirm',
                            message=('Private key fields do not equal '
                                     'each other'))])

    private_key_confirm = PasswordField(u'Confirm Private Encryption Key')
