'''Generic form that validates paths'''

from wtforms import Form, StringField
from wtforms.validators import InputRequired

from idrive.webui.app.helpers.form_validations import ValidPath, NotEqualTo


class RenameForm(Form):

    old = StringField('Old Path', [InputRequired(), ValidPath(),
                                   NotEqualTo('new', 'New name cannot be ' +
                                              'the same as the old name')])

    new = StringField('New Path', [InputRequired(), ValidPath()])
