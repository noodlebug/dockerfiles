"""Login controller"""

import random
import string

from flask import Blueprint, render_template, redirect, request, url_for, \
    session, current_app
from idrive.webui.app.controllers import INTERNAL_ERROR_TXT
from idrive.webui.app.forms.login import LocalLoginForm, RemoteLoginForm
from idrive.webui.app.forms.pvt_key import PvtKeyForm
from idrive.webui.app.models.authenticate import local as auth_local
from idrive.webui.app.models.authenticate import remote as auth_remote
from idrive.webui.app.models.authenticate.check import check_authentication, \
    AUTH_NONE, AUTH_REMOTE_PVT, AUTH_LOCAL, AUTH_CONFIG
from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.forms.configure_account import ConfigureAccountForm

bp = Blueprint('login', __name__, url_prefix='/login')
POM = PersistentObjManager()


def _get_login_status():
    """Internal function to check login status
    """
    auth = AUTH_NONE
    if POM.KEY_NAME in session:
        auth = check_authentication(session[POM.KEY_NAME])

    return auth


@bp.route('', methods=['GET'])
def index():
    return redirect(url_for('login.local'))


@bp.route('/local', methods=['GET', 'POST'])
def local():
    """Local login"""
    form = LocalLoginForm(request.form)
    error = None
    root_login = None
    auth = _get_login_status()

    if auth != AUTH_NONE:
        return redirect(url_for('login.remote'))

    elif request.method == 'POST' and form.validate():
        username = form.local_username.data
        password = form.local_password.data

        if POM.KEY_NAME not in session:
            session_string = \
                u''.join(random.choice(string.ascii_letters) for _ in range(3))
            session[POM.KEY_NAME] = '{}_{}'.format(username, session_string)

        try:
            auth_local.authenticate(session[POM.KEY_NAME], username, password)
            session['local_username'] = username

            return redirect(url_for('login.remote'))

        except ValueError as e:
            current_app.logger.error(unicode(e))
            del session[POM.KEY_NAME]
            error = 'Invalid username or password'
            if username == 'root':
                root_login = True
        except RuntimeError as e:
            current_app.logger.error(unicode(e))
            del session[POM.KEY_NAME]
            error = INTERNAL_ERROR_TXT

    return render_template('login/local.html', form=form, error=error,
                           root_login=root_login)


@bp.route('/remote', methods=['GET', 'POST'])
def remote():
    """Remote login"""
    form = RemoteLoginForm(request.form)
    error = None
    auth = _get_login_status()

    if auth == AUTH_REMOTE_PVT:
        return redirect(url_for('login.pvtkey'))
    elif auth == AUTH_CONFIG:
        return redirect(url_for('login.configure'))
    elif auth != AUTH_LOCAL:
        return redirect(url_for('index.index'))

    if request.method == 'POST' and form.validate():
        username = form.remote_username.data
        password = form.remote_password.data

        try:
            result = auth_remote.authenticate(session[POM.KEY_NAME], username,
                                              password)
            session['remote_username'] = username

            if result == auth_remote.PVT_KEY:
                to_url = 'login.pvtkey'

            elif result == auth_remote.UNCONFIGURED:
                to_url = 'login.configure'

            else:
                to_url = 'index.index'

            return redirect(url_for(to_url))

        except ValueError as e:
            current_app.logger.error(unicode(e))
            error = unicode(e)
        except RuntimeError as e:
            current_app.logger.error(unicode(e))
            error = INTERNAL_ERROR_TXT

    return render_template('login/remote.html', form=form, error=error)


@bp.route('/pvtkey', methods=['GET', 'POST'])
def pvtkey():
    """Private key login"""
    form = PvtKeyForm(request.form)
    error = None
    auth = _get_login_status()

    if auth != AUTH_REMOTE_PVT:
        return redirect(url_for('index.index'))

    if request.method == 'POST' and form.validate():
        pvtkey = form.pvtkey.data
        try:
            auth_remote.validate_pvtkey(session[POM.KEY_NAME], pvtkey)
            session['pvtkey'] = True
            return redirect(url_for('index.index'))

        except ValueError as e:
            current_app.logger.error(unicode(e))
            error = unicode(e)
        except RuntimeError as e:
            current_app.logger.error(unicode(e))
            error = INTERNAL_ERROR_TXT

    return render_template('login/pvtkey.html', form=form, error=error)


@bp.route('/configure', methods=['GET', 'POST'])
def configure():
    """Account configuration"""
    form = ConfigureAccountForm(request.form)
    error = None
    auth = _get_login_status()

    if auth != AUTH_CONFIG:
        return redirect(url_for('index.index'))

    if request.method == 'POST' and form.validate():
        pvtkey = None
        if form.encryption_type.data == 'private':
            pvtkey = form.private_key.data

        try:
            auth_remote.configure_account(session[POM.KEY_NAME], pvtkey)
            if pvtkey is not None:
                session['pvtkey'] = True
            return redirect(url_for('index.index'))

        except ValueError as e:
            current_app.logger.error(unicode(e))
            error = unicode(e)
        except RuntimeError:
            current_app.logger.error(unicode(e))
            error = INTERNAL_ERROR_TXT

    return render_template('login/configure.html', form=form, error=error)
