from flask import Blueprint, redirect, url_for

bp = Blueprint('index', __name__)

from idrive.webui.app.controllers import logged_in


@bp.route('/', methods=['GET'])
def index():

    if logged_in():
        return redirect(url_for('backup.index'))

    return redirect(url_for('login.index'))
