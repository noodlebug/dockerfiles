'''Settings page'''

import urllib
import urllib2
import contextlib

from flask import Blueprint, render_template, request, session, current_app, \
    flash, redirect, url_for

from idrive import SETTINGS_URL
from idrive.utils.bunch import Bunch
from idrive.webui.app.controllers import require_login, INTERNAL_ERROR_TXT
from idrive.webui.app.forms.settings import SettingsForm
from idrive.webui.app.models import user_settings
from idrive.webui.app.models.authenticate.remote import get
from idrive.webui.core.models import PersistentObjManager

bp = Blueprint('settings', __name__, url_prefix='/settings')
bp.before_request(require_login)

POM = PersistentObjManager()


@bp.route('', methods=['GET', 'POST'])
def index():
    '''
    Settings index page
    '''
    error = None
    form = SettingsForm(request.form)
    key = session[POM.KEY_NAME]
    network_proxy = None
    user_quota = Bunch({'percent': 0, 'max_quota': 0, 'used_quota': 0})

    try:
        settings = user_settings.get(key, True)
    except (ValueError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        if isinstance(e, ValueError):
            error = unicode(e)
        else:
            error = INTERNAL_ERROR_TXT
    else:
        form = SettingsForm(request.form, **settings.as_dict())
        user_quota = settings.QUOTA
        network_proxy = settings.NETWORKPROXY

        # update settings
        if request.method == 'POST' and form.validate():
            try:
                for field in form:
                    # parse the section/key from the name
                    field_name = field.name.split('_')
                    section = field_name.pop(0)
                    name = '_'.join(field_name)

                    if field.flags.remote:
                        updater = user_settings.update_remote
                    else:
                        updater = user_settings.update_local

                    updater(key, section, name, field.data)

            except ValueError as e:
                current_app.logger.error(unicode(e))
                error = unicode(e)
            except RuntimeError as e:
                current_app.logger.error(unicode(e))
                error = INTERNAL_ERROR_TXT

            if error:
                flash(error, 'notify_danger')
            else:
                flash(u'Settings updated successfully', 'notify_success')
            return redirect(url_for('settings.index'))

    # normal get request or form has errors
    return render_template('settings/index.html', settings=True, error=error,
                           form=form, quota=user_quota,
                           network_proxy=network_proxy)


@bp.route('/update_profile', endpoint='update_profile', methods=['GET'],
          defaults={'do_what': 'pwd_chng'})
@bp.route('/upgrade', endpoint='upgrade', methods=['GET'],
          defaults={'do_what': 'upgrade'})
def manage(do_what):
    """Upgrade/Profile update. Redirects to application website"""

    quota = Bunch({'percent': 0, 'max_quota': 0, 'used_quota': 0})
    try:
        key = session[POM.KEY_NAME]
        remote_login_data = get(key)
        quota = user_settings.get(key, True).QUOTA
    except ValueError as e:
        current_app.logger.error(unicode(e))
        error = unicode(e)
    except RuntimeError as e:
        current_app.logger.error(unicode(e))
        error = INTERNAL_ERROR_TXT
    else:
        data = urllib.urlencode({'uid': remote_login_data.username,
                                 'pwd': remote_login_data.password,
                                 'op_type': do_what})
        url = SETTINGS_URL[0]
        try:
            with contextlib.closing(urllib2.urlopen(url, data)) as req:
                if req.getcode() != 200:
                    raise RuntimeError(req.read(1000))

                response = req.read()
                token = response.split(':')[1].rstrip()
                if token == 'INVALID USERNAME PASSWORD':
                    raise RuntimeError(token)

        except (urllib2.URLError, RuntimeError) as err:
            current_app.logger.error(unicode(err))
            error = unicode(err)
        except IndexError:
            current_app.logger.error(response)
            error = response
        else:
            redirect_url = "{}?token={}".format(SETTINGS_URL[1], token)
            return redirect(redirect_url, 301)

    return render_template('error/error.html', reason=error, quota=quota)
