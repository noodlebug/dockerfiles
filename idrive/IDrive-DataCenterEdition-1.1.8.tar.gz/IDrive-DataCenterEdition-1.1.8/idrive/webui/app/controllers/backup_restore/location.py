"""Backup/Restore location."""

from flask import request, session, render_template, jsonify, current_app

from . import bp_backup, bp_restore, POM, INTERNAL_ERROR_TXT
from idrive.webui.app.forms.path import PathForm
from idrive.webui.app.helpers import jsonify_error
from idrive.webui.app.models import backup_restore_set


_CONF_SECTION = {
    backup_restore_set.BACKUP_SET: 'BACKUP',
    backup_restore_set.RESTORE_SET: 'RESTORE'
}
_BR_LOC_NAME = 'location'


@bp_backup.route('/location/get', endpoint='location/get', methods=['GET'],
                 defaults={'set_type': backup_restore_set.BACKUP_SET})
@bp_restore.route('/location/get', endpoint='location/get', methods=['GET'],
                  defaults={'set_type': backup_restore_set.RESTORE_SET})
def get(set_type):
    """Return backup/restore location.

    Location is stored in the BackupRestoreSet.

    """
    key = session[POM.KEY_NAME]

    try:
        br_set = backup_restore_set.get(key, set_type)
    except ValueError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=unicode(e)))
    except RuntimeError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))
    else:
        return jsonify(path=br_set.get()[1])


@bp_backup.route('/location/set', endpoint='location/set', methods=['POST'],
                 defaults={'set_type': backup_restore_set.BACKUP_SET})
@bp_restore.route('/location/set', endpoint='location/set', methods=['POST'],
                  defaults={'set_type': backup_restore_set.RESTORE_SET})
def set_(set_type):
    """Sets the backup/restore location.

    Location is stored in the BackupRestoreSet.

    """
    form = PathForm(request.form)

    try:
        if not form.validate():
            raise ValueError()

        key = session[POM.KEY_NAME]
        backup_restore_set.update(key, set_type, backup_restore_set.SET_PATH,
                                  location=form.path.data)

    except ValueError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=unicode(e)))
    except RuntimeError as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))
    else:
        return jsonify(success=True)
