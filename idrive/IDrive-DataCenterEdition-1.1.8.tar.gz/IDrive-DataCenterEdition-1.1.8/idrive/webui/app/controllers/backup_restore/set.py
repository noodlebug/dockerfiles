"""Backup/Restore set listing update."""

import os
import copy

from flask import request, session, render_template, jsonify, current_app

from . import bp_backup, bp_restore, POM, INTERNAL_ERROR_TXT
from idrive.core.data_types.dir_entry import DirEntry
from idrive.webui.app.forms.set_update import SetUpdateForm
from idrive.webui.app.helpers import jsonify_error
from idrive.webui.app.models import backup_restore_set, list_files, \
    changeset


@bp_backup.route('/set/list', endpoint='set/list', methods=['GET'],
                 defaults={'set_type': backup_restore_set.BACKUP_SET,
                           'is_backup': True})
@bp_restore.route('/set/list', endpoint='set/list', methods=['GET'],
                  defaults={'set_type': backup_restore_set.RESTORE_SET,
                            'is_backup': False})
def list_(set_type, is_backup):
    """Returns backup/restore set.

    Output is JSON.
    Format
    {
        error: True,              // only in case of error
        reason: <error reason>,   //only in case of error
        html: "HTML of backup/restore set"
    }

    """

    br_set = None
    items = []
    try:
        br_set = backup_restore_set.get(session[POM.KEY_NAME], set_type)
        if br_set:
            for item in br_set.dir_entry_set:
                items.append(item.name)
    except ValueError as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=unicode(err)))
    except RuntimeError as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    return jsonify(html=render_template('backup_restore/br_set_item.html',
                                        br_set=br_set.dir_entry_set,
                                        backup=is_backup,
                                        restore=not is_backup),
                   br_set=sorted(items))


@bp_backup.route('/set/update', methods=["POST"], endpoint='set/update',
                 defaults={'set_type': backup_restore_set.BACKUP_SET,
                           'from_': list_files.LOCAL,
                           'is_backup': True})
@bp_restore.route('/set/update', methods=["POST"], endpoint='set/update',
                  defaults={'set_type': backup_restore_set.RESTORE_SET,
                            'from_': list_files.REMOTE,
                            'is_backup': False})
def update(set_type, from_, is_backup):
    """Updates backup/restore set

    @return: calls list_() function
    """
    form = SetUpdateForm(request.form)
    dir_entries = []
    key = session[POM.KEY_NAME]

    try:
        if not form.validate():
            raise ValueError()

        is_add = form.operation.data == 'add'
        # create a list of paths
        for i, path in enumerate(form.paths.data):
            try:
                # load the parent directory
                lister = 'local' if from_ == list_files.LOCAL else 'remote'
                getattr(list_files, lister)(key, os.path.dirname(path))
                # load the dir entry
                dir_entry = list_files.get_dir_entry(key, path, from_)
            except (ValueError, KeyError):
                if is_add:
                    raise  # we don't add files to things that don't exist
                else:
                    dir_entry = path  # we are removing a deleted path

            if isinstance(dir_entry, DirEntry):
                try:
                    # and version info (if present)
                    version = form.versions.data[i]
                    # store the current version for later
                    if not hasattr(dir_entry, 'current_version'):
                        dir_entry.current_version = dir_entry.version
                    dir_entry = copy.copy(dir_entry)
                    dir_entry.version = version
                except (IndexError, AttributeError):
                    pass
            dir_entries.append(dir_entry)

        # generate the actual change set
        to_add, to_remove = changeset.calculate(key, is_add,
                                                from_ == list_files.LOCAL,
                                                set_type, dir_entries)

        # update (remove)
        if to_remove:
            backup_restore_set.update(key, set_type, backup_restore_set.REMOVE,
                                      to_remove)
        # update (add)
        if to_add:
            backup_restore_set.update(key, set_type, backup_restore_set.ADD,
                                      to_add)

    except ValueError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=unicode(e)))
    except RuntimeError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))
    return list_(set_type, is_backup)
