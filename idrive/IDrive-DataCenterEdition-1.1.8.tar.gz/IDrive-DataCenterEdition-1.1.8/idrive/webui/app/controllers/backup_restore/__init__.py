"""Backup/Restore page."""

import operator
import datetime

from flask import Blueprint

from idrive.webui.app.controllers import require_login, INTERNAL_ERROR_TXT
from idrive.webui.core.models import PersistentObjManager


bp_backup = Blueprint('backup', __name__, url_prefix='/backup')
bp_backup.before_request(require_login)
bp_restore = Blueprint('restore', __name__, url_prefix='/restore')
bp_restore.before_request(require_login)

POM = PersistentObjManager()


# Rest of the routes are defined in individual files
from idrive.webui.app.controllers.backup_restore import index, files, set, \
    operation, location
