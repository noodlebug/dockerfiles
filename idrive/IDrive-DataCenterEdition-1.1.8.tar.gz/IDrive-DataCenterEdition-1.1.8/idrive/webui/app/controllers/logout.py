"""Logout controller"""

from flask import Blueprint, redirect, session, url_for, request

from idrive.webui.core.models import PersistentObjManager

bp = Blueprint('logout', __name__, url_prefix='/logout')

POM = PersistentObjManager()


@bp.route('', methods=['GET'])
def index():
    """Logout."""

    key_name = POM.KEY_NAME
    if key_name in session:
        key = session[key_name]
        try:
            POM.remove(key)
        except KeyError:
            pass

    session.clear()

    headers = request.headers
    redirect_to = headers['Referer'] if 'Referer' in headers \
        else url_for('index.index')

    return redirect(redirect_to)
