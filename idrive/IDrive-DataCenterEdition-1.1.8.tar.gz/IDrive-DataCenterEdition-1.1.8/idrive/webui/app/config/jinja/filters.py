'''
Custom jinja filters
'''

import os
import datetime

from idrive import LONG_NAME, SHORT_NAME, URL, EMAIL, SIGNUP_URL, \
    FORGOT_PASS_URL, PRODUCT, get_version
from idrive.flavors import get_config
from idrive.utils.pluralize import pluralize
from idrive.utils.size_format import size_format
from idrive.webui.app import app
from idrive.webui.app.helpers import files

_VERSION = get_version()


@app.context_processor
def filters():
    '''Add custom filter to allow access by all templates'''

    def current_year():
        '''Return the current year'''
        return datetime.date.today().strftime('%Y')

    def basename(path):
        """Returns basename"""

        return os.path.basename(path)

    def dirname(path):
        """Returns basename"""

        return os.path.dirname(path)

    def enumerate_list(the_list):
        """Enumerate a list."""

        return enumerate(the_list)

    def format_filesize(size):
        return size_format(size)

    def pluralize_(word, num=None):
        '''Returns a pluralized version of the word'''
        return pluralize(word, num)

    def app_details():
        """Returns application LONG_NAME, PRODUCT, URL, EMAIL"""

        return (LONG_NAME, PRODUCT, URL, EMAIL, SIGNUP_URL, FORGOT_PASS_URL,
                _VERSION, SHORT_NAME)

    def flavor_class():
        '''Class friendly representation for different versions'''

        return 'flavor-' + SHORT_NAME.lower()

    def flavor_config():
        '''Return the flavor config parser'''
        return get_config()

    return dict(
        current_year=current_year,
        basename=basename,
        dirname=dirname,
        enumerate=enumerate_list,
        size_format=format_filesize,
        pluralize=pluralize_,
        app_details=app_details,
        flavor_class=flavor_class,
        flavor_config=flavor_config,
        get_icon=files.get_icon
    )
