'''WebUI Jinja config'''
