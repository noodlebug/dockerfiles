"""Model to interact with session_log"""

import datetime
import operator

import idrive.proxy.interface as p_interface

from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.models.authenticate.data_types import SysLoginData, \
    RemoteLoginData

POM = PersistentObjManager()

_GET_RECORDS = 'session_log.get_records'
_GET_RECORD_DETAILS = 'session_log.get_record_details'
_DELETE_RECORD = 'session_log.delete'

_SESSION_LOG_KEY = 'session_log_records'


def get_log_records(key, since=None, refresh=False):
    """Get session log records for logged in user.

    @raise ValueError: Error fro session_log interface or invalid input
    @raise RuntimeError: All other error

    """

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    if since is not None and not isinstance(since, datetime.date):
        raise ValueError("'since' is invalid")

    # try to get from the pom first
    try:
        logs_list = POM.get(key, _SESSION_LOG_KEY)
    except KeyError:
        refresh = True

    if refresh:
        username = sys_login_data.username
        password = sys_login_data.password
        remote_username = remote_login_data.username

        logs_list = p_interface.passthru(username, password, _GET_RECORDS,
                                         {'params': (remote_username, since)})

        if isinstance(logs_list, ValueError):
            raise logs_list
        elif isinstance(logs_list, Exception):
            raise RuntimeError(str(logs_list))

        # store result in the pom
        if logs_list:
            POM.set(key, _SESSION_LOG_KEY, logs_list)

    result = logs_list
    if since is not None:
        result = []
        for log_records in logs_list:
            for log_record in log_records:
                # all LogRecord in a LogRecords container have the same date
                # we need to verify only one LogRecord start time
                if log_record.op_start_time >= since:
                    result.append(log_records)
                break

    return result


def get_sorted_log_records(key, since=None):
    '''Return a list of log records sorted by start time. Optionally after
    a certain date

    @return: [LogRecords]
    '''
    result = get_log_records(key, since, True)
    records = []
    for log_records in result:
        for log_record in log_records:
            records.append(log_record)

    records.sort(key=operator.attrgetter('op_start_time'), reverse=True)

    return records


def get_record_details(key, log_record_id):
    """Get log record details.

    @raise KeyError: Record details not found
    @raise ValueError: Error from session_log interface
    @raise RuntimeError: All errors

    """

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    username = sys_login_data.username
    password = sys_login_data.password

    selected_log_record = None
    log_records_array = POM.get(key, _SESSION_LOG_KEY)
    for log_records in log_records_array:
        for log_record in log_records:
            if log_record.op_details_id == log_record_id:
                selected_log_record = log_record
                break

        if selected_log_record is not None:
            break
    else:
        raise KeyError("LogRecords not loaded")

    result = p_interface.passthru(username, password,
                                  _GET_RECORD_DETAILS,
                                  {'params': (selected_log_record,)})

    if isinstance(result, ValueError):
        raise result
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    return selected_log_record, result
