"""EVS File operations."""

import copy
import idrive.proxy.interface as p_interface

from os.path import dirname
from idrive.core.evs.files.data_types import FileVersionInfoError, DeleteError, \
    RenameError, RestoreError
from idrive.core.evs.files.data_types import EVSDirEntry
from idrive.webui.app.models import list_files
from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.models.authenticate.data_types import SysLoginData, \
    RemoteLoginData
from idrive.webui.app.models.list_files import REMOTE

POM = PersistentObjManager()

_GET_VERSION_CMD = 'file.getversion'
_RENAME_FILE_CMD = 'file.rename'
_REMOVE_FILES_CMD = 'files.delete'
_TRASH_RESTORE_CMD = 'trash.restore'
_REMOVE_TRASH_FILES_CMD = 'files.trash_delete'


def get_versions(key, evs_dir_entry):
    """Retrieves versions of a file and returns as as list
    of EVSDirEntries.

    @return: List of DirEntry objects of same file with version updated
    in it. Empty list of not version found.

    @raise ValueError: Invalid input
    @raise RuntimeError: All ohter error

    """

    if not isinstance(evs_dir_entry, EVSDirEntry):
        raise ValueError("Invalid parameters")

    if not evs_dir_entry.isfile:
        raise ValueError("Cannot get version of folder")

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username
    remote_password = remote_login_data.password
    path = evs_dir_entry.name

    version_info = p_interface.passthru(username, password,
                                        _GET_VERSION_CMD,
                                        {'params': (remote_username,
                                                    remote_password,
                                                    path)})

    result = []

    if isinstance(version_info, FileVersionInfoError):
        # no versions throws an error
        if str(version_info.message) == 'No versions found':
            return result

        raise ValueError(str(version_info.message))
    elif isinstance(version_info, Exception):
        raise RuntimeError(str(version_info))

    if not hasattr(evs_dir_entry, 'current_version'):
        evs_dir_entry.current_version = evs_dir_entry.version

    versions = version_info.versions
    for version_no in versions:
        new_dir_entry = copy.copy(evs_dir_entry)
        new_dir_entry.version = version_no
        new_dir_entry.modified_date = versions[version_no]['modified_date']
        new_dir_entry.size = versions[version_no]['size']

        result.append(new_dir_entry)

    return result


def remove_files(key, path_list, in_trash=False):
    """Deletes a list of files/folders from EVS.

    @raise ValueError: Error in evs side or invalid input
    @raise RuntimeError: All other error.

    """
    if (not isinstance(path_list, list)):
        raise ValueError("Invalid parameters")

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username
    remote_password = remote_login_data.password
    pvtkey = remote_login_data.pvtkey

    delete_result = \
        p_interface.passthru(username, password,
                             (_REMOVE_TRASH_FILES_CMD if in_trash else
                              _REMOVE_FILES_CMD),
                             {'params': (remote_username, remote_password,
                                         path_list, pvtkey)})

    if isinstance(delete_result, DeleteError):
        raise ValueError(str(delete_result.message))
    elif isinstance(delete_result, Exception):
        raise RuntimeError(str(delete_result))

    return delete_result


def rename(key, old_dir_entry, new):
    """Renames a file/folder in EVS

    @raise ValueError: Remote EVS error
    @raise RuntimeError: All other errors

    """
    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    # params
    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username
    remote_password = remote_login_data.password
    pvtkey = remote_login_data.pvtkey

    result = p_interface.passthru(username, password, _RENAME_FILE_CMD,
                                  {'params': (remote_username, remote_password,
                                              old_dir_entry.name, new,
                                              pvtkey)})

    if isinstance(result, RenameError):
        raise ValueError(str(result.message))
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    # folders must be invalidated in the POM
    if not old_dir_entry.isfile:
        try:
            file_list = POM.get(key, REMOTE)
            del file_list[old_dir_entry.name]
        except KeyError:
            # not loaded...
            pass

    # set the new path
    old_dir_entry.name = new

    return result


def trash_restore(key, evs_dir_entries):
    """Restores files/folders from trash in EVS

    @param evs_dir_entries: A list of EVSDirEntry objects

    @raise ValueError: Remote EVS errors
    @raise RuntimeError: All other errors

    """

    # input must be list of EVSDirEntry objects
    if not isinstance(evs_dir_entries, list):
        raise ValueError('Please provide a list of files/folders to restore')

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    # params
    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username
    remote_password = remote_login_data.password
    pvtkey = remote_login_data.pvtkey

    # restore
    restore_result = p_interface.passthru(username, password,
                                          _TRASH_RESTORE_CMD,
                                          {'params': (remote_username,
                                                      remote_password,
                                                      evs_dir_entries,
                                                      pvtkey)})

    if isinstance(restore_result, RestoreError):
        raise ValueError(str(restore_result.message))
    elif isinstance(restore_result, Exception):
        raise RuntimeError(str(restore_result))

    for result in restore_result.result:
        # the names for some reason have a trailing slash on them
        result['name'] = result['name'].rstrip('/')

        if result['success']:
            # invalidate all parent folders that held this item
            parent = dirname(result['name'])

            while(True):
                try:
                    list_files.remove_dir_entry(key, parent, REMOTE)
                except KeyError:
                    # no worries, the directory is not loaded
                    pass

                if parent == '/':
                    break
                parent = dirname(parent)

    return restore_result
