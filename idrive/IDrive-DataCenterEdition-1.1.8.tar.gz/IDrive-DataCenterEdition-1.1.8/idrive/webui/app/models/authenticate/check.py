"""Check authentication"""

from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.models.authenticate.data_types import SysLoginData
from idrive.webui.app.models.authenticate.remote import AUTH_DONE, \
    CONFIGURE_ACCOUNT

POM = PersistentObjManager()

AUTH_NONE = 10  # No authentication done yet
AUTH_LOCAL = 20  # Local Done
AUTH_REMOTE_PVT = 30  # Remote done but needs pvtkey auth
AUTH_REMOTE = 40  # Remote done, with pvtkey if pvtkey is required
AUTH_CONFIG = 50  # Remote done, account needs to be configured


def check_authentication(key):
    """Check if authentication is done. If so, which level.
    the further down the method goes the "auth" variable will be set to the
    appropriate level until either login is verified or KeyError is thrown
    """
    auth = AUTH_NONE
    if POM.key_exists(key):
        try:
            POM.get(key, type(SysLoginData()).__name__)
            # syslogin data set, user has at least logged in locally
            auth = AUTH_LOCAL

            auth_done = POM.get(key, AUTH_DONE)
            if auth_done:
                # user is fully logged in
                auth = AUTH_REMOTE

            else:
                # private key info required
                auth = AUTH_REMOTE_PVT

                POM.get(key, CONFIGURE_ACCOUNT)
                # user must configure account
                auth = AUTH_CONFIG

        except KeyError:
            pass

    return auth
