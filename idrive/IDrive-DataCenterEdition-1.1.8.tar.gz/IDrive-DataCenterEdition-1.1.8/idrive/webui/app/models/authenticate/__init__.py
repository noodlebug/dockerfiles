"""Local and Remote authentication."""
