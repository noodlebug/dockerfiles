"""Local Authentication."""

import idrive.proxy.interface as p_interface
from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.models.authenticate.data_types import SysLoginData

_AUTH_LOCAL_CMD = 'authenticate.local'


def authenticate(key, username, password):
    """Authenticates a local user and sets the SysLoginData information

    @return: None for success

    @raise ValueError: Authentication failure
    @raise RuntimeError: All other errors

    """
    try:
        valid_user = p_interface.passthru(username, password,
                                          _AUTH_LOCAL_CMD,
                                          {'params': (username, password)})
        if isinstance(valid_user, Exception):
            raise valid_user

    except ValueError:
        raise
    except Exception as err:
        raise RuntimeError(unicode(err))

    if valid_user:
        sys_login_data = SysLoginData()
        sys_login_data.username = username
        sys_login_data.password = password

        PersistentObjManager().set(key, type(sys_login_data).__name__,
                                   sys_login_data)

    else:
        raise ValueError("Authentication failure")
