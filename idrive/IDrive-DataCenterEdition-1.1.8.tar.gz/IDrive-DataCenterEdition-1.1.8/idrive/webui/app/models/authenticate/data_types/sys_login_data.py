"""Encapsulates system login data"""


class SysLoginData(object):
    """Encapsulates system login information"""

    def __init__(self):
        """Constructor."""

        self._username = None
        self._password = None

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        self._username = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value
