"""Authenticate with remove EVS system."""

import idrive.proxy.interface as p_interface

from idrive.core.evs.account.configure import ConfigureAccountError
from idrive.core.evs.account.validate import ValidateAccountError, \
    DEFAULT_KEY_ACCOUNT, PRIVATE_KEY_ACCOUNT, UNCONFIGURED_ACCOUNT
from idrive.webui.app.models.authenticate.data_types import SysLoginData, \
    RemoteLoginData
from idrive.webui.core.models import PersistentObjManager

POM = PersistentObjManager()

DEFAULT_KEY = 10
PVT_KEY = 20
UNCONFIGURED = 30

_LOGIN_VALIDATE = 'login.validate'
_LOGIN_VALIDATE_PVTKEY = 'login.validate.pvtkey'
_LOGIN_SET = 'login.set'
_CONFIGURE_ACCOUNT = 'login.configure'

AUTH_DONE = 'auth_done'
CONFIGURE_ACCOUNT = 'configure_account'


def authenticate(key, username, password):
    """Validates remote username/password

    @return: DEFAULT_KEY, PVT_KEY, UNCONFIGURED

    In case of DEFAULT_KEY, also stores the LoginData into persistence
    storage.

    @raise ValueError: Authentication failure with remote server
    @raise RuntimeError: All other errors

    """
    try:
        sys_login = SysLoginData()
        sys_login = POM.get(key, type(sys_login).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not found")

    result = p_interface.passthru(sys_login.username,
                                  sys_login.password,
                                  _LOGIN_VALIDATE,
                                  {'params': (username, password)})

    if isinstance(result, ValidateAccountError):
        raise ValueError(str(result.message))
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    remote_login_data = RemoteLoginData()
    if result == DEFAULT_KEY_ACCOUNT:
        res = p_interface.passthru(sys_login.username,
                                   sys_login.password,
                                   _LOGIN_SET,
                                   {'init_params': (),
                                    'method': 'set',
                                    'params': (username, password, None)})

        if isinstance(res, Exception):
            raise RuntimeError(str(res))

        # Set the login_data in persistent storage
        remote_login_data.username = username
        remote_login_data.password = password
        POM.set(key, type(remote_login_data).__name__, remote_login_data)

        POM.set(key, AUTH_DONE, True)

        return DEFAULT_KEY

    elif result == PRIVATE_KEY_ACCOUNT:
        # Set the login_data in persistent storage
        remote_login_data.username = username
        remote_login_data.password = password
        POM.set(key, type(remote_login_data).__name__, remote_login_data)

        POM.set(key, AUTH_DONE, False)

        return PVT_KEY

    elif result == UNCONFIGURED_ACCOUNT:
        # Set the login_data in persistent storage
        remote_login_data.username = username
        remote_login_data.password = password
        POM.set(key, type(remote_login_data).__name__, remote_login_data)

        POM.set(key, AUTH_DONE, False)
        POM.set(key, CONFIGURE_ACCOUNT, True)

        return UNCONFIGURED

    else:
        raise RuntimeError("Invalid response from proxy '{}'"
                           .format(str(result)))


def validate_pvtkey(key, pvtkey):
    """Validates remote private key.

    @return: None on success

    @raise ValueError: Authentication failure with pvtkey
    @raise RuntimeError: All other error

    """
    try:
        sys_login = SysLoginData()
        sys_login = POM.get(key, type(sys_login).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not found")

    try:
        remote_login_data = RemoteLoginData()
        remote_login_data = POM.get(key, type(remote_login_data).__name__)
    except KeyError:
        raise RuntimeError("'RemoteLoginData' not found")

    username = remote_login_data.username
    password = remote_login_data.password
    result = p_interface.passthru(sys_login.username,
                                  sys_login.password,
                                  _LOGIN_VALIDATE_PVTKEY,
                                  {'params': (username, password, pvtkey)})

    if isinstance(result, ValidateAccountError):
        raise ValueError(str(result.message))
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    result = p_interface.passthru(sys_login.username,
                                  sys_login.password,
                                  _LOGIN_SET,
                                  {'init_params': (),
                                   'method': 'set',
                                   'params': (username, password, pvtkey)})
    if isinstance(result, Exception):
        raise RuntimeError(str(result))

    remote_login_data.pvtkey = pvtkey

    POM.set(key, type(remote_login_data).__name__, remote_login_data)
    POM.set(key, AUTH_DONE, True)


def configure_account(key, pvtkey):
    """Configures account

    @return: None on success

    @raise ValueError: Failure at evs end
    @raise RuntimeError: All other error

    """
    try:
        sys_login = SysLoginData()
        sys_login = POM.get(key, type(sys_login).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not found")

    try:
        remote_login_data = RemoteLoginData()
        remote_login_data = POM.get(key, type(remote_login_data).__name__)
    except KeyError:
        raise RuntimeError("'RemoteLoginData' not found")

    username = remote_login_data.username
    password = remote_login_data.password
    if not pvtkey:
        pvtkey = None

    result = p_interface.passthru(sys_login.username,
                                  sys_login.password,
                                  _CONFIGURE_ACCOUNT,
                                  {'params': (username, password, pvtkey)})

    if isinstance(result, ConfigureAccountError):
        raise ValueError(str(result.message))
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    result = p_interface.passthru(sys_login.username,
                                  sys_login.password,
                                  _LOGIN_SET,
                                  {'init_params': (),
                                   'method': 'set',
                                   'params': (username, password, pvtkey)})
    if isinstance(result, Exception):
        raise RuntimeError(str(result))

    remote_login_data.pvtkey = pvtkey

    POM.set(key, type(remote_login_data).__name__, remote_login_data)
    POM.set(key, AUTH_DONE, True)
    try:
        POM.remove(key, CONFIGURE_ACCOUNT)
    except KeyError:
        pass


def get(key):
    """Returns cached remote login data, or exception if remote login is
    not done yet."""

    try:
        remote_login_data = RemoteLoginData()
        remote_login_data = POM.get(key, type(remote_login_data).__name__)
    except KeyError:
        raise RuntimeError("'RemoteLoginData' not found")

    return remote_login_data
