"""List files"""

import os
import re

from idrive.core.data_types.exceptions import ListingError
from idrive.proxy import interface as proxy
from idrive.webui.app.models.authenticate.data_types import SysLoginData, \
    RemoteLoginData
from idrive.webui.core.models import PersistentObjManager

POM = PersistentObjManager()

_LF_KEY = 'local_file_list'
_RF_KEY = 'remote_file_list'

_LOCAL_FILE_LIST_CMD = 'list.local'
_REMOTE_FILE_LIST_CMD = 'list.remote'
_REMOTE_SEARCH_CMD = 'list.remote.search'

LOCAL = _LF_KEY
REMOTE = _RF_KEY


def local(key, path, refresh=False):
    """List local files.

    @return: list of DirEntry objects.

    @raise ValueError: Error in listing reported by OS.
    @raise RuntimeError: All other errors

    """

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    if refresh:
        _clear_cached_files(key, _LF_KEY)

    try:
        file_list = POM.get(key, _LF_KEY)
    except KeyError:
        file_list = {}
        POM.set(key, _LF_KEY, file_list)

    if path not in file_list:
        username = sys_login_data.username
        password = sys_login_data.password

        dir_entries = proxy.passthru(username, password, _LOCAL_FILE_LIST_CMD,
                                     {'params': (path,)})

        if isinstance(dir_entries, ListingError):
            raise ValueError(str(dir_entries.message))
        elif isinstance(dir_entries, Exception):
            raise RuntimeError(dir_entries)

        file_list[path] = dir_entries

    return file_list[path]


def remote(key, path, search_key=None, in_trash=False, offset=0, limit=400,
           refresh=False):
    """List/search remote files.

    @param offset: Search only. The starting file offset.
    @param limit: Search only. Limit number of files to return
    @param refresh: To refresh file list into POM even if it already exists

    @return: a list of EVSDirEntry objects.

    @raise ValueError: Listing error, from EVS.
    @raise RuntimeError: All other errors

    """
    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    if refresh:
        _clear_cached_files(key, _RF_KEY)

    try:
        file_list = POM.get(key, _RF_KEY)
    except KeyError:
        file_list = {}
        POM.set(key, _RF_KEY, file_list)

    evs_dir_entries = None
    if path not in file_list or search_key is not None:
        username = sys_login_data.username
        password = sys_login_data.password
        remote_username = remote_login_data.username
        remote_password = remote_login_data.password
        remote_pvtkey = remote_login_data.pvtkey

        cmd = _REMOTE_FILE_LIST_CMD
        params = (remote_username, remote_password, path, remote_pvtkey)
        if search_key is not None:
            cmd = _REMOTE_SEARCH_CMD
            params = (remote_username, remote_password,
                      search_key, path, in_trash, None, offset, limit,
                      in_trash)  # Collate trash results

        evs_dir_entries = proxy.passthru(username, password, cmd,
                                         {'params': params})

        if isinstance(evs_dir_entries, ListingError):
            raise ValueError(str(evs_dir_entries.message))
        elif isinstance(evs_dir_entries, Exception):
            raise RuntimeError(str(evs_dir_entries))

        if len(evs_dir_entries) > 0:
            # store only non search entries
            if search_key is None:
                file_list[path] = evs_dir_entries

            # Search result (not trash) also contain entries which have search
            #  key in the path, but not in the file/folder name. Weed out
            #  such results
            elif not in_trash:
                search_result = []
                for evs_dir_entry in evs_dir_entries:
                    name = os.path.basename(evs_dir_entry.name)
                    if re.search(search_key, name, re.IGNORECASE) is not None:
                        search_result.append(evs_dir_entry)

                evs_dir_entries = search_result

    elif path in file_list:
        evs_dir_entries = file_list[path]

    return evs_dir_entries


def get_dir_entry(key, for_path, from_local_or_remote):
    """Returns an already loaded dir_entry.

    @return: EVSDirEntry or DirEntry

    @raise KeyError: Entry not loaded

    """

    obj_key = from_local_or_remote
    try:
        file_list = POM.get(key, obj_key)
    except KeyError:
        raise KeyError("File list not loaded")
    else:
        if os.path.dirname(for_path) not in file_list:
            if obj_key == _LF_KEY:
                local(key, os.path.dirname(for_path))
            else:
                remote(key, os.path.dirname(for_path))

            if os.path.dirname(for_path) not in file_list:
                raise KeyError("File list not loaded")

    for dir_entry in file_list[os.path.dirname(for_path)]:
        if for_path == dir_entry.name:
            return dir_entry
    else:
        raise KeyError("Dir entry not found")


def remove_dir_entry(key, item_path, from_local_or_remote):
    """Removes an already loaded dir_entry.

    @raise KeyError: if file list has not been loaded

    """
    parent_path = os.path.dirname(item_path)

    try:
        file_list = POM.get(key, from_local_or_remote)
    except KeyError:
        raise KeyError("File list not loaded")

    # first we remove the item from it's parents list
    if parent_path in file_list:
        for dir_entry in file_list[parent_path]:
            if item_path == dir_entry.name:
                file_list[parent_path].remove(dir_entry)
                break
        # if parent is now empty, remove it also
        if len(file_list[parent_path]) == 0:
            del file_list[parent_path]

    # then remove the item
    try:
        del file_list[item_path]
    except KeyError:
        pass

    # then any children paths
    if item_path != os.sep:
        for path_key in file_list.keys():
            if (item_path + os.sep) in path_key:
                del file_list[path_key]


def _clear_cached_files(key, pom_key):
    '''Clears loaded files from the POM

    @raise ValueError: if invalid POM key passed
    '''
    if pom_key not in [_LF_KEY, _RF_KEY]:
        raise ValueError('Invalid key')

    try:
        POM.remove(key, pom_key)
    except KeyError:
        pass
