"""Model to interact with the scheduler."""

import idrive.proxy.interface as p_interface

from idrive.core.evs.files.data_types import UploadError, DownloadError
from idrive.scheduler.data_types import JobSchedule
from idrive.scheduler.interface import BACKUP_JOB, RESTORE_JOB
from idrive.webui.app.models.authenticate.data_types import SysLoginData, \
    RemoteLoginData
from idrive.webui.core.models import PersistentObjManager

POM = PersistentObjManager()

_GET_SCHEDULES_CMD = 'schedule.get'
_ADD_SCHEDULE_CMD = 'schedule.add'
_REMOVE_SCHEDULE_CMD = 'schedule.remove'
_GET_JOB_PROGRESS = 'schedule.get_progress'
_CANCEL_JOB = 'schedule.cancel_job'


def _execute_command(key, command, job_type=None, job_schedule=None):
    """Internal function which interacts with schduler.interface."""

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username

    params = ()
    if job_type is not None:
        params = params + (job_type,)

    params = params + (remote_username,)

    if job_schedule is not None:
        params = params + (job_schedule,)

    result = p_interface.passthru(username, password,
                                  command,
                                  {'params': params})

    if (isinstance(result, ValueError) or
            isinstance(result, KeyError) or
            isinstance(result, RuntimeError)):
        raise result
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    return result


def _mark_progress_errors(progress, error_type):
    '''Mark all items in the progress result as having an error or not
    '''
    if progress is not None:
        for p in progress:
            p.error = isinstance(p, error_type)


def add_backup_job(key, job_schedule):
    """Add/Update a backup schedule job.

    If no backup schedule exits, it adds one, otherwise it updates the
    existing schedule.

    @raise ValueError: Error from scheduler
    @raise RuntimeError: All other errors

    """

    if not isinstance(job_schedule, JobSchedule):
        raise ValueError("Invalid input")

    return _execute_command(key, _ADD_SCHEDULE_CMD, BACKUP_JOB, job_schedule)


def add_restore_job(key, job_schedule):
    """Add/Update a restore schedule job.

    If no restore schedule exits, it adds one, otherwise it updates the
    existing schedule.

    @raise ValueError: Error from scheduler
    @raise RuntimeError: All other errors

    """

    if not isinstance(job_schedule, JobSchedule):
        raise ValueError("Invalid input")

    return _execute_command(key, _ADD_SCHEDULE_CMD, RESTORE_JOB, job_schedule)


def remove_backup_job(key):
    """Remove a backup schedule job.

    @raise ValueError: Error from scheduler
    @raise KeyError: No job to remove
    @raise RuntimeError: All other errors

    """

    return _execute_command(key, _REMOVE_SCHEDULE_CMD, BACKUP_JOB, None)


def remove_restore_job(key):
    """Remove a restore schedule job.

    @raise ValueError: Error from scheduler
    @raise KeyError: No job to remove
    @raise RuntimeError: All other errors

    """

    return _execute_command(key, _REMOVE_SCHEDULE_CMD, RESTORE_JOB, None)


def get_jobs(key):
    """Retrieves all schedules for particular user.

    @raise ValueError: Error from scheduler
    @raise RuntimeError: All other errors

    """

    return _execute_command(key, _GET_SCHEDULES_CMD, None, None)


def get_backup_job_progress(key):
    """Retrieves current backup job progress from scheduler.

    @return: Empty list of not progress but job running, None if no job running

    @raise RuntimeError: All errors


    """

    progress = _execute_command(key, _GET_JOB_PROGRESS, BACKUP_JOB, None)
    _mark_progress_errors(progress, UploadError)

    return progress


def get_restore_job_progress(key):
    """Retrieves current restore job progress from scheduler.

    @return: Empty list of not progress but job running, None if no job running

    @raise RuntimeError: All errors

    """

    progress = _execute_command(key, _GET_JOB_PROGRESS, RESTORE_JOB, None)
    _mark_progress_errors(progress, DownloadError)

    return progress


def cancel_backup_job(key):
    """Cancel currently running backup job.

    @return: True if job was interrupted, False otherwise, even if no
    job exists

    @raise RuntimeError: For all errors

    """

    return _execute_command(key, _CANCEL_JOB, BACKUP_JOB, None)


def cancel_restore_job(key):
    """Cancel currently running restore job

    @return: True if job was interrupted, False otherwise, even if no
    job exists

    @raise RuntimeError: For all errors

    """

    return _execute_command(key, _CANCEL_JOB, RESTORE_JOB, None)
