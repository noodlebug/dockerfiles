"""Backup/Restore set"""

import os
import platform

from idrive.common.data_types import BackupRestoreSet
from idrive.core.data_types.dir_entry import DirEntry
from idrive.proxy import interface
from idrive.webui.app.models.authenticate.data_types import RemoteLoginData, \
    SysLoginData
from idrive.webui.core.models import PersistentObjManager

POM = PersistentObjManager()

_BSET_KEY = 'backup_set'
_RSET_KEY = 'restore_set'

_BR_SET_GET_CMD = 'backup_restore_set.get'
_BR_SET_UPDATE_CMD = 'backup_restore_set.update'
_BRSET_ADD_METHOD = 'add'
_BRSET_REMOVE_METHOD = 'remove'
_BRSET_SETPATH_METHOD = 'setpath'

BACKUP_SET = BackupRestoreSet.BACKUP_SET
RESTORE_SET = BackupRestoreSet.RESTORE_SET

ADD = 10
REMOVE = 20
SET_PATH = 30


def get(key, set_type, reload_brset=False):
    """Retrieves the backup/restore set.

    @param set_type: BACKUP_SET, RESTORE_SET
    @param {boolean} reload_brset: if False, returned from cache,
                                   else reload from disk

    @raise ValueError: Error loading BR set
    @raise RuntimeError: All other errors
    """

    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    if set_type == BackupRestoreSet.BACKUP_SET:
        obj_key = _BSET_KEY
        # /{machine name}
        default_path = os.path.join('/', platform.node())
    else:
        obj_key = _RSET_KEY
        default_path = '/'

    if not reload_brset:
        try:
            br_set = POM.get(key, obj_key)
        except KeyError:
            reload_brset = True

    if reload_brset:
        username = sys_login_data.username
        password = sys_login_data.password
        remote_username = remote_login_data.username

        br_set = interface.passthru(username, password, _BR_SET_GET_CMD,
                                    {'init_params': (remote_username, set_type,
                                                     default_path)})

        if isinstance(br_set, ValueError):
            raise br_set
        elif isinstance(br_set, Exception):
            raise RuntimeError(str(br_set))

        POM.set(key, obj_key, br_set)

    return br_set


def update(key, set_type, operation, dir_entry_list=None, location=None):
    """Add/Remove a dir_entry to/from a backup/restore set, or
    update the location.

    @param set_type: BACKUP_SET or RESTORE_SET
    @param operation: ADD, REMOVE or SET_PATH
    @param dir_entry_list: (optional) list of DirEntry objects
    @param location: (optional) path for updating BackupRestoreSet.path

    @raise ValueError: Error updating BR set
    @raise RuntimeError: All other error

    """
    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username

    method = _BRSET_ADD_METHOD
    params = dir_entry_list
    if operation == REMOVE:
        method = _BRSET_REMOVE_METHOD
    elif operation == SET_PATH:
        method = _BRSET_SETPATH_METHOD
        params = [location]

    if params is None or not params:
        raise ValueError("Invalid input")

    for param in params:
        if (method == _BRSET_ADD_METHOD and isinstance(param, DirEntry) and
                param.name == u'/'):
            continue  # we do not allow adding "/" to the backup set

        result = interface.passthru(username, password, _BR_SET_UPDATE_CMD,
                                    {'init_params': (remote_username,
                                                     set_type),
                                     'method': method, 'params': (param,)})

        if isinstance(result, KeyError):
            raise ValueError("{} not found in set".format(result.args[0].name))
        if isinstance(result, Exception):
            raise RuntimeError(str(result))

    # reload backup_restore set after update
    return get(key, set_type, True)
