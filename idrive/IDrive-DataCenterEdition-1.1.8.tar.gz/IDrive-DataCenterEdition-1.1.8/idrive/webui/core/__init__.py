'''WebUI core classes'''
