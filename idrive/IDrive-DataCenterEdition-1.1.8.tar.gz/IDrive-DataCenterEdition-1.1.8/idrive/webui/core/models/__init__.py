'''WebUI core models'''

from idrive.webui.core.models.persistent_obj_manager import PersistentObjManager
