"""Datacenter Backup Application."""

import re
import os.path as path
import subprocess

import flavors

config = flavors.get_config()

VERSION = (1, 1, 8, 'final', 0)

PRODUCT = config.get('DEFAULT', 'name')
LONG_NAME = config.get('DEFAULT', 'full_name')
SHORT_NAME = config.get('DEFAULT', 'short_name')
PKG_NAME = config.get('DEFAULT', 'package')
URL = config.get('URL', 'site')
EMAIL = config.get('EMAIL', 'support')
SUPPORT_URL = config.get('URL', 'support')
SIGNUP_URL = config.get('URL', 'signup')
FORGOT_PASS_URL = config.get('URL', 'forgot_password')
SETTINGS_URL = [config.get('URL', 'login_token'),
                config.get('URL', 'login_auto')]
EXE = config.get('BIN', 'admin')


def get_version(from_svn=False):
    """PEP 386 styled version"""

    release = dict(alpha='a', beta='b', release='rc', final='')

    version = '.'.join(map(str, VERSION[:3])) + release[VERSION[3]]

    # Following is only for releases which are not 'final'
    if VERSION[3] != 'final':
        # If its not a 'final' release, its a release for testing.
        #  Lets append a sub version

        # This is usually called by build script which embeds the
        # repository version into a version file
        if from_svn:
            svnversion = ['svnversion', '-qn']
            svn_revision = subprocess.check_output(svnversion)
            svn_numbers = r'\d+'
            if re.search(svn_numbers, svn_revision) is None:
                svnversion.append('..')
                svn_revision = subprocess.check_output(svnversion)
            version += re.sub(r'[^\d]+', '', svn_revision.rsplit(':')[0])

        else:
            # If there is a VERSION file present, it means this is called
            #  during installation for test releases
            this_file = path.abspath(__file__)
            version_file = path.join(path.dirname(path.dirname(this_file)),
                                     'VERSION')
            if path.exists(version_file):
                # NOTE: do no use context manager statement here.
                # this file may be executed by python < 2.5
                f = open(version_file, 'r')
                try:
                    version = f.read().strip()
                finally:
                    f.close()
            else:
                # This is for already installed software
                try:
                    import pkg_resources
                    version = pkg_resources.get_distribution(PKG_NAME).version
                except (pkg_resources.DistributionNotFound, ImportError):
                    pass

    return version
