"""Create new folder locally."""

import os

from idrive.core.local.files.data_types import NewFolderError


def new_folder(path):
    """Create new folder locally."""

    if not os.path.isabs(path):
        raise NewFolderError("Path must be absolute")

    try:
        os.makedirs(path, mode=0700)
    except OSError as err:
        raise NewFolderError(err)

    return True
