"""List local files."""

import os

from idrive.core.data_types.dir_entry import DirEntry
from idrive.core.local.files.data_types.exceptions import ListingError


def list_files(path):
    """List local files."""

    file_list = []
    try:
        if os.path.isfile(path):
            file_list.append(DirEntry(path))
        else:
            for dir_entry in os.listdir(path):
                file_list.append(DirEntry(os.path.join(path, dir_entry)))
    except (ValueError, OSError) as err:
        raise ListingError(err)

    return sorted(file_list)

if __name__ == '__main__':
    import sys
    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    kwargs = process_command_line({'path'})

    try:
        file_list = list_files(**kwargs)
    except ListingError as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        print pickle.dumps(file_list)
        sys.exit(0)
