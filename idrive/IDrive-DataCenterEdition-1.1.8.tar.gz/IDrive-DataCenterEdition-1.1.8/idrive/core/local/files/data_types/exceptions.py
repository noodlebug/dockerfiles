"""Exceptions for local.files package."""

from idrive.core.data_types.exceptions import ListingError  # @UnusedImport


class NewFolderError(Exception):
    """New folder exception."""
    pass
