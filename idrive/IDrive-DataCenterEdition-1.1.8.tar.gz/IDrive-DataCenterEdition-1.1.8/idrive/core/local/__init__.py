"""Local system related functions."""
