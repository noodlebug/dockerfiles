"""Configure account with default/private encryption key"""

import sys

from xml.etree import ElementTree

from idrive.core.evs.account.data_types import ConfigureAccountError, \
    ConfigureAccountLoginError, ConfigureAccountAlreadyConfiguredError
from idrive.core.evs.idevsutil import execute_command, CONFIGURE
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSLoginError


def configure_account(username, password, pvtkey=None):
    """Configure account with default/private encryption key.

    @param username: EVS username
    @param password: EVS password
    @param pvtkey: Private key. Optional.

    @return: None on success

    @raise ConfigureAccountLoginError: Invalid username/password
    @raise ConfigureAccountError: All other error.

    """

    try:
        succ_xml, err_xml = execute_command(CONFIGURE, username, password,
                                            pvtkey=pvtkey)

        if err_xml:
            raise EVSErrorFactory.get_error(err_xml)

    except EVSLoginError as err:
        raise ConfigureAccountLoginError(err)
    except EVSError as err:
        if (hasattr(err, 'message') and
                err.message.lower() == 'your account is already configured'):
            raise ConfigureAccountAlreadyConfiguredError(('Account already '
                                                          'configured'))
        else:
            _, _, tb = sys.exc_info()
            raise ConfigureAccountError(err), None, tb

    try:
        xml = ElementTree.fromstringlist(succ_xml)
    except ElementTree.ParseError:
        raise ConfigureAccountError("Configure account failed : {xml}"
                                    .format(xml=succ_xml))
    if xml.get('message') == 'SUCCESS':
        return True
    else:
        raise ConfigureAccountError("Configure account failed : {xml}"
                                    .format(xml=succ_xml))

if __name__ == '__main__':
    """Command line execution."""

    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password'}
    optional_args = {'pvtkey.store'}
    kwargs = process_command_line(required_args, optional_args)

    try:
        config_status = configure_account(**kwargs)
    except ConfigureAccountError as err:
        sys.stdout.write(pickle.dumps(err))
        sys.exit(1)
    else:
        print pickle.dumps(config_status)
        sys.exit(0)
