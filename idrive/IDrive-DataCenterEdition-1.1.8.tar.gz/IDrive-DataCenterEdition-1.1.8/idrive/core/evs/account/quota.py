"""Get quota used by a user."""

import sys

from idrive.core.evs.account.server_address import get_server_address
from idrive.core.evs.account.data_types import ServerAddressError, Quota, \
    QuotaError, QuotaLoginError, ServerAddressLoginError
from idrive.core.evs.idevsutil import execute_command, QUOTA
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSInvalidServerError, EVSLoginError


def get_quota(username, password, pvtkey=None):
    """Returns quota of a particular user.

    @param username: EVS username
    @param password: EVS password
    @param pvtkey: Private key. Optional.

    @return: Instance of Quota class

    @raise QuotaLoginError: Invalid username/password
    @raise QuotaError: All other error

    """

    # Try again with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise QuotaLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise QuotaError(err), None, tb

        try:
            ipaddress = server_address.CLU_SERVER_IP
            succ_xml, err_xml = execute_command(QUOTA, username, password,
                                                pvtkey=pvtkey,
                                                server_address=ipaddress)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise QuotaLoginError(err)

        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise QuotaError(err)

        except EVSError as err:
            _, _, tb = sys.exc_info()
            raise QuotaError(err), None, tb
        else:
            break

    return Quota(succ_xml)

if __name__ == '__main__':
    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    kwargs = process_command_line({'username', 'password'})

    try:
        quota = get_quota(**kwargs)
    except QuotaError as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        print pickle.dumps(quota)
        sys.exit(0)
