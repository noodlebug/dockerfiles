"""Data types of account pacakge."""


from idrive.core.evs.account.data_types.exceptions import ServerAddressError,\
    ServerAddressLoginError, ValidateAccountError, ValidateAccountLoginError,\
    QuotaError, QuotaLoginError, ConfigureAccountError, \
    ConfigureAccountAlreadyConfiguredError, ConfigureAccountLoginError
from idrive.core.evs.account.data_types.quota import Quota
from idrive.core.evs.account.data_types.server_address import ServerAddress
