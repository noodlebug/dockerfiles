"""Validates a uesrname/password and return the account config status"""

import sys

from xml.etree import ElementTree

from idrive.core.evs.account.server_address import get_server_address, \
    ServerAddressError, ServerAddressLoginError
from idrive.core.evs.account.data_types import ValidateAccountError, \
    ValidateAccountLoginError
from idrive.core.evs.idevsutil import execute_command, VALIDATE, VALIDATE_PVTKEY
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSInvalidServerError, EVSLoginError, EVSMultipleError


UNCONFIGURED_ACCOUNT = 10
DEFAULT_KEY_ACCOUNT = 20
PRIVATE_KEY_ACCOUNT = 30


def validate_account(username, password):
    """Validates a username/password and returns the config status.

    @param username: EVS username
    @param password: EVS password

    @return: UNCONFIGURE_ACCOUNT, if account is not configured yet
    DEFAULT_KEY_ACCOUNT, if validation was successful and the account
    is a default key account
    PRIVATE_KEY_ACCOUNT, if validation was successful and the account
    is a private key account.

    @raise ValidateAccountLoginError: Invalid username/password
    @raise ValidateAccountError: All other errors

    """

    try:
        succ_xml, err_xml = execute_command(VALIDATE, username, password)

        if err_xml:
            raise EVSErrorFactory.get_error(err_xml)

    except EVSLoginError as err:
        raise ValidateAccountLoginError(err)
    except (EVSError, EVSMultipleError) as err:
        if isinstance(err, EVSMultipleError):
            err = err.errors[0]
        _, _, tb = sys.exc_info()
        raise ValidateAccountError(err), None, tb

    try:
        xml = ElementTree.fromstringlist(succ_xml)
    except ElementTree.ParseError:
        raise ValidateAccountError("Validation failed with server : {xml}"
                                   .format(xml=succ_xml))

    config_status = None
    if xml.get('configstatus') == 'NOT SET':
        config_status = UNCONFIGURED_ACCOUNT
    elif xml.get('configstatus') == 'SET':
        if xml.get('configtype') == 'DEFAULT':
            config_status = DEFAULT_KEY_ACCOUNT
        elif xml.get('configtype') == 'PRIVATE':
            config_status = PRIVATE_KEY_ACCOUNT

    if config_status is None:
        raise ValidateAccountError("Validaion failed with server : {xml}"
                                   .format(xml=succ_xml))

    return config_status


def validate_pvtkey(username, password, pvtkey):
    """Validates pvtkey for username/password/pvtkey.

    Does nothing if pvtkey is valid, throws error otherwise.
    This method would give undefined output for accounts with
    default encryption, i.e. with no pvtkey.

    @param username: EVS username
    @param password: EVS password
    @param pvtkey: Private key.

    @return: None on success

    @raise ValidateAccountLoginError: Invalid username/password
    @raise ValidateAccountError: All other errors

    """

    # For EVSInvalidServerError we retry with cached=False
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise ValidateAccountLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise ValidateAccountError(err), None, tb

        try:
            ipaddress = server_address.CLU_SERVER_IP
            _, err_xml = execute_command(VALIDATE_PVTKEY, username, password,
                                         server_address=ipaddress,
                                         pvtkey=pvtkey)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise ValidateAccountLoginError(err)
        except EVSInvalidServerError as err:
            # retry with cached=False
            if cached:
                continue
            else:
                raise ValidateAccountError(err)

        except EVSError as err:
            _, _, tb = sys.exc_info()
            raise ValidateAccountError(err), None, tb
        else:
            break


if __name__ == '__main__':
    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    kwargs = process_command_line({'username', 'password'})

    try:
        config_status = validate_account(**kwargs)
    except ValidateAccountError as err:
        sys.stdout.write(pickle.dumps(err))
        sys.exit(1)
    else:
        print pickle.dumps(config_status)
        sys.exit(0)
