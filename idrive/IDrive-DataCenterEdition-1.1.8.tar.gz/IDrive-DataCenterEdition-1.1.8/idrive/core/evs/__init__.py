"""EVS related APIs"""
