"""Delete/Restore operation.

This module is not directly used. It is imported into
files.restore and files.delete modules.
"""

import sys

from idrive.core.evs.idevsutil import execute_command, DELETE, RESTORE, \
    TRASH_DELETE
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, \
    EVSInvalidPathError, EVSInvalidServerError, EVSLoginError, EVSError

from idrive.core.evs.account import get_server_address, ServerAddressError
from idrive.core.evs.files.data_types import DeleteResult, DeleteError, \
    RestoreResult, RestoreError, DeleteLoginError, RestoreLoginError
from idrive.core.evs.account.data_types.exceptions import ServerAddressLoginError


def _get_error(operation, error):
    """Internal function to raise appropriate exception based on operation."""

    result = None
    if operation == DELETE or operation == TRASH_DELETE:
        if isinstance(error, EVSLoginError):
            result = DeleteLoginError(error)
        else:
            result = DeleteError(error)
    elif operation == RESTORE:
        if isinstance(error, EVSLoginError):
            result = RestoreLoginError(error)
        else:
            result = RestoreError(error)

    return result


def do_operation(operation, username, password, file_list, pvtkey=None):
    """Deletes/Restore files/folders from EVS.

    @param operation: DELETE, RESTORE, TRASH_DELETE
    @param username: EVS username
    @param password: EVS password
    @param file_list: list of file/folder path.
    @param pvtkey: Private key. Optional.

    @return: DeleteResult or RestoreResult

    @raise Delete|RestoreLoginError: Invalid username/password
    @raise Delete|RestoreError: All other error

    """

    # Retry with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        # get evs server address
        try:
            evs_server = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise _get_error(operation, err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise _get_error(operation, err), None, tb

        try:
            ipaddress = evs_server.CLU_SERVER_IP
            succ_xml, err_xml = execute_command(operation, username, password,
                                                pvtkey=pvtkey,
                                                server_address=ipaddress,
                                                file_list=file_list)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except (EVSInvalidPathError) as err:
            succ_xml = succ_xml + err_xml
            break
        except (EVSLoginError) as err:
            raise _get_error(operation, err)
        except (EVSInvalidServerError) as err:
            if cached:
                continue
            else:
                raise _get_error(operation, err)
        except (EVSError) as err:
            _, _, tb = sys.exc_info()
            raise _get_error(operation, err), None, tb
        else:
            break

    result = None
    if succ_xml:
        if operation == DELETE or operation == TRASH_DELETE:
            result = DeleteResult(succ_xml)
        elif operation == RESTORE:
            result = RestoreResult(succ_xml)

    return result


def do_operation_ci(operation):
    """Command line execution."""

    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password', 'file-list'}
    kwargs = process_command_line(required_args)

    try:
        result = do_operation(operation, **kwargs)
    except (DeleteError, RestoreError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        print pickle.dumps(result)
        sys.exit(0)
