"""Rename file/folder."""

import sys

from idrive.core.evs.idevsutil import execute_command, RENAME
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, \
    EVSInvalidPathError, EVSInvalidServerError, EVSLoginError, \
    EVSError
from idrive.core.evs.account import get_server_address, ServerAddressError, \
    ServerAddressLoginError
from idrive.core.evs.files.data_types import RenameResult
from idrive.core.evs.files.data_types.exceptions import RenameError, \
    RenameLoginError, RenameInvalidPathError


def rename(username, password, from_path, to_path, pvtkey=None):
    """Renames files/folders on EVS.

    @param username: EVS username
    @param password: EVS password
    @param from_path: Rename from path
    @param to_path: Rename to this new name
    @param pvtkey: EVS private key. Optional

    @return: Instance of RenameResult class

    @raise RenameLoginError: Invalid username/password
    @raise RenameInvalidPathError: Invalid path
    @raise RenameError: For all other error

    """

    # retry with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        # get evs server address
        try:
            evs_server = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise RenameLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise RenameError(err), None, tb

        # vars
        ipaddress = evs_server.CLU_SERVER_IP
        remote_path = {'from': from_path, 'to': to_path}

        try:
            succ_xml, err_xml = execute_command(RENAME, username, password,
                                                pvtkey=pvtkey,
                                                server_address=ipaddress,
                                                remote_path=remote_path)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise RenameLoginError(err)
        except EVSInvalidPathError as err:
            raise RenameInvalidPathError(err)
        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise RenameError(err)
        except (EVSError) as err:
            _, _, tb = sys.exc_info()
            raise RenameError(err), None, tb
        else:
            break

    return RenameResult(succ_xml)


if __name__ == '__main__':
    """Command line execution."""

    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password', 'from-path', 'to-path'}
    kwargs = process_command_line(required_args)

    try:
        result = rename(**kwargs)
    except (RenameError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)

    print pickle.dumps(result)
    sys.exit(0)
