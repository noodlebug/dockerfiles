"""Upload file(s) to EVS"""

import sys

from idrive.core.evs.idevsutil import execute_command, UPLOAD, CANCEL_OP
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, \
    EVSInvalidPathError, EVSInvalidServerError, EVSMultipleError, EVSError, \
    EVSLoginError, EVSAccountUnderMaintenanceError, EVSCommunicationError

from idrive.core.evs.account import get_server_address, ServerAddressError, \
    ServerAddressLoginError
from idrive.core.evs.files.data_types import UploadProgress
from idrive.core.evs.files.data_types.exceptions import UploadError, \
    UploadLoginError, UploadInvalidPathError, \
    UploadAccountUnderMaintenanceError, UploadCancelledError, \
    UploadCommunicationError


def _upload_callback(callback, success_xml, error_xml):
    '''
    Internal callback function
    @param callback: callback function to call
    @param success_xml: successfull XML data
    @param error_xml: error XML data
    '''
    err_list = []
    if error_xml:
        for err_xml in error_xml.split('\n'):
            try:
                raise EVSErrorFactory.get_error(err_xml)
            except EVSLoginError as err:
                err_list.append(UploadLoginError(err))
            except EVSAccountUnderMaintenanceError as err:
                err_list.append(UploadAccountUnderMaintenanceError(err))
            except EVSCommunicationError as err:
                err_list.append(UploadCommunicationError(err))
            except EVSInvalidPathError as err:
                err_list.append(UploadInvalidPathError(err))
            except EVSMultipleError as err:
                for error in err:
                    if isinstance(error, EVSInvalidPathError):
                        err_list.append(UploadInvalidPathError(error))
                    else:
                        err_list.append(UploadError(error))
            except EVSError as err:
                err_list.append(UploadError(err))

    if err_list:
        callback(err_list)

    file_list = []
    if success_xml:
        for xml_line in success_xml.split('\n'):
            if xml_line:
                try:
                    file_list.append(UploadProgress(xml_line))
                except UploadError as err:
                    callback([err])

    if file_list:
        callback(file_list)


def upload(username, password, path, dir_entry_list, pvtkey=None,
           callback=None, relative=None, cancel_lambda=None,
           bandwidth=100):
    """Upload files to EVS.

    @param relative: if None, the uploaded file path will take the form of
        {path} + basename(filename). if 'yes' the path will take the form
        of {path} + {filename}

    @param callback: used to monitor progress of upload.
        It is periodically called with lists of UploadProgress
        and UploadError objects as the case might be.

    @param cancel_lambda: used to cancel the upload process.
        It can be any object with one attribute, 'call', which
        will be assigned a function. The caller can then just call
        cancel_lambda.call() to cancel the upload.

    @param bandwidth: an object with the following attributes:
        "percent" - an integer between -1 and 100 indicating how much of
        the user's bandwidth the upload should use
        "call" - will be assigned a callback function that can be used to
        manipulate the bandwidth during an upload

    @return: list of UploadProgress objects

    @raise UploadLoginError: Invalid username/password
    @raise UploadInvalidPath: Invalid local path
    @raise UploadAccountUnderMaintenanceError: Account under maintenance
    @raise UploadError: All other error

    """
    # param checks
    if not isinstance(bandwidth, int):
        raise UploadError('bandwidth must be an integer')
    elif bandwidth < 1 or bandwidth > 100:
        raise UploadError('bandwidth percent must be between 1 and 100')

    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise UploadLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise UploadError(err), None, tb

        progress_callback = None
        if callback is not None:
            progress_callback = lambda s, e: _upload_callback(callback, s, e)

        file_list = []
        for dir_entry in dir_entry_list:
            file_list.append(dir_entry.name)

        progress_list = None
        error_list = None
        try:
            # cancel callback
            check_cancel = None
            if cancel_lambda and hasattr(cancel_lambda, 'call'):
                check_cancel = {'filename': False, 'cancelled': False}

                def cancel_upload():
                    if check_cancel['filename']:
                        with open(check_cancel['filename'], 'w') as f:
                            f.write(CANCEL_OP)
                    check_cancel['cancelled'] = True

                cancel_lambda.call = cancel_upload

            ipaddress = server_address.CLU_SERVER_IP
            succ_xml, err_xml = execute_command(UPLOAD, username, password,
                                                pvtkey=pvtkey,
                                                server_address=ipaddress,
                                                remote_path=path,
                                                file_list=file_list,
                                                relative=relative,
                                                callback=progress_callback,
                                                check_cancel=check_cancel,
                                                bandwidth=bandwidth)

            if check_cancel and check_cancel['cancelled']:
                error = UploadCancelledError()
                if callback is not None:
                    callback([error])
                else:
                    raise error

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise UploadLoginError(err)
        except EVSAccountUnderMaintenanceError as err:
            raise UploadAccountUnderMaintenanceError(err)
        except EVSCommunicationError as err:
            raise UploadCommunicationError(err)
        except EVSInvalidPathError as err:
            error_list = [UploadInvalidPathError(err)]
            break
        except EVSMultipleError as err:
            error_list = []
            for error in err:
                if isinstance(error, EVSInvalidPathError):
                    error_list.append(UploadInvalidPathError(error))
                else:
                    error_list.append(UploadError(error))
            break
        except UploadCancelledError as e:
            error_list = [e]
            break
        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise UploadError(err)
        except EVSError as err:
            _, _, tb = sys.exc_info()
            raise UploadError(err), None, tb
        else:
            break

    if callback is None:
        progress_list = []
        for xml_line in succ_xml.split('\n'):
            if xml_line:
                progress_list.append(UploadProgress(xml_line))

    return progress_list, error_list

if __name__ == '__main__':
    import cPickle as pickle

    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password', 'path', 'dir-entry-list'}
    optional_args = {'incremental', 'relative.store'}
    kwargs = process_command_line(required_args, optional_args)

    # Create callback if incremental is set
    callback = None
    if kwargs['incremental']:

        def dump_flist(f_list):
            pkled_f_list = pickle.dumps(f_list)

            # In incremental, write length of each batch first
            print len(pkled_f_list)
            print pkled_f_list

        callback = dump_flist

    # incremental is not accepted by list_files as an argument
    del kwargs['incremental']
    try:
        progress_list, error_list = upload(callback=callback, **kwargs)
    except (UploadError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        if progress_list is not None:
            print pickle.dumps(progress_list)
        if error_list is not None:
            sys.stderr.write(pickle.dumps(error_list))
            sys.exit(1)
