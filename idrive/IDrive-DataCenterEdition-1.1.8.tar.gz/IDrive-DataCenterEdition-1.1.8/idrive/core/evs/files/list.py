"""List remote path."""

import sys

from idrive.core.evs.idevsutil import execute_command, LIST
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, \
    EVSInvalidPathError, EVSInvalidServerError, EVSLoginError, EVSError

from idrive.core.evs.account import get_server_address, ServerAddressError
from idrive.core.evs.account.data_types.exceptions import ServerAddressLoginError
from idrive.core.evs.files.data_types import EVSDirEntry, ListingError, \
    ListingLoginError
from idrive.core.evs.files.data_types.exceptions import ListingInvalidPathError


def _do_callback(callback, path, succ_cb_data, err_cb_data):
    """Internal callback function."""

    if err_cb_data:
        callback(ListingError(err_cb_data))

    file_list = []
    if succ_cb_data:
        for xml_line in succ_cb_data.split('\n'):
            if xml_line:
                file_list.append(EVSDirEntry(xml_line, path))

    callback(file_list)


def list_files(username, password, path, pvtkey=None, callback=None):
    """Lists files/folders from EVS.

    @param username: EVS username
    @param password: EVS password
    @param pvtkey: EVS private key. Optional
    @param callback: callback to get progressive output

    @return: A list of EVSDirEntry objects if callback is None. Otherwise
    callback will be called with incremental list of EVSDirEntry objects.

    @raise ListingLoginError: Invalid username/password
    @raise ListingInvalidPathErro: Invalid path
    @raise ListingError: All other error

    @note: list_files() is not reentrant if callback is provided.
    """

    # retry with cached=False on EVSInvalidServerError
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise ListingLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise ListingError(str(err)), None, tb

        # vars
        ipaddress = server_address.CLU_SERVER_IP
        callback_lambda = None
        if callback is not None:
            def callback_lambda(s, e):
                _do_callback(callback, path, s, e)

        try:
            succ_xml, err_xml = execute_command(LIST, username, password,
                                                pvtkey=pvtkey,
                                                server_address=ipaddress,
                                                remote_path=path,
                                                callback=callback_lambda)
            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise ListingLoginError(err)
        except EVSInvalidPathError as err:
            raise ListingInvalidPathError(err)
        except (EVSInvalidServerError) as err:
            if cached:
                continue
            else:
                raise ListingError(str(err))
        except (EVSError) as err:
            _, _, tb = sys.exc_info()
            raise ListingError(str(err)), None, tb
        else:
            break

    file_list = None
    if callback is None:
        file_list = []
        for xml_line in succ_xml.split('\n'):
            if xml_line == '':
                continue

            try:
                # TODO - Should we bail out or just NOT append
                #  anything to the list?
                file_list.append(EVSDirEntry(xml_line, path))
            except ValueError as err:
                raise ListingError(str(err))

    return file_list

if __name__ == '__main__':
    import cPickle as pickle

    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password', 'path'}
    optional_args = {'incremental'}
    kwargs = process_command_line(required_args, optional_args)

    # Create callback if incremental is set
    callback = None
    if kwargs['incremental']:

        def dump_flist(f_list):
            pkled_f_list = pickle.dumps(f_list)
            # In incremental, write length of each batch first
            print len(pkled_f_list)
            print pkled_f_list

        callback = dump_flist

    # incremental is not accepted by list_files as an argument
    del kwargs['incremental']

    try:
        file_list = list_files(callback=callback, **kwargs)
    except (ValueError, ListingError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        if file_list is not None:
            print pickle.dumps(file_list)

        sys.exit(0)
