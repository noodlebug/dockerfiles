"""Search files in EVS."""

import sys

from idrive.core.evs.idevsutil import execute_command, SEARCH
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSInvalidServerError, EVSLoginError, EVSAccountUnderMaintenanceError, \
    EVSCommunicationError
from idrive.core.evs.account.data_types import ServerAddressError, \
    ServerAddressLoginError
from idrive.core.evs.account.server_address import get_server_address
from idrive.core.evs.files.data_types import EVSDirEntry
from idrive.core.evs.files.data_types.exceptions import SearchError, \
    SearchLoginError, SearchAccountUnderMaintenanceError, \
    SearchCommunicationError


def _do_callback(succ_cb_data, err_cb_data):
    """Internal callback function."""

    if err_cb_data:
        _callback_fn(SearchError(err_cb_data))

    file_list = []
    if succ_cb_data:
        for xml_line in succ_cb_data.split('\n'):
            if xml_line:
                file_list.append(EVSDirEntry(xml_line))

    _callback_fn(file_list)


def search_files(username, password, search_for,
                 search_path='/', in_trash=False, callback=None,
                 offset=None, limit=None, collate_trash=False):
    """Search files in evs.

    @param username: EVS username
    @param password: EVS password
    @param search_for: Search criteria. *.* to search for everything
    @param search_path: From where search will start. Defaults to /
    @param in_trash: If search should be done in trash. This can be used to
        list files in trash
    @param callback: Optional callback function to get search results in
        increments
    @param offset: Optional offset from where to start searching. Useful for
        pagination
    @param limit: Optional, number of entries from offset. Useful for
        pagination
    @param collate_trash: Optional parameter to collate trash results based
        on deleted_at_level attribute of EVSDirEntry. deleted_at_level
        determines which ancestor of a file was deleted which
        resulted in the file getting moved into trash. deleted_at_level=0
        means the file itself was directly deleted.
        Note: modified_date is not accurate when collate_trash is used.

    @raise SearchLoginError: Invalid username/password
    @raise SearchAccountUnderMaintenanceError: Account under maintenance
    @raise SearchError: All other error

    """

    # retry with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise SearchLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise SearchError(err), None, tb

        do_callback = None
        if callback is not None:
            global _callback_fn
            _callback_fn = callback
            do_callback = _do_callback

        try:
            ipaddress = server_address.CLU_SERVER_IP
            remote_path = search_path + search_for
            succ_xml, err_xml = execute_command(SEARCH, username, password,
                                                server_address=ipaddress,
                                                remote_path=remote_path,
                                                in_trash=in_trash,
                                                callback=do_callback,
                                                offset=offset, limit=limit)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise SearchLoginError(err)
        except EVSAccountUnderMaintenanceError as err:
            raise SearchAccountUnderMaintenanceError(err)
        except EVSCommunicationError as err:
            raise SearchCommunicationError(err)
        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise SearchError(err)
        except EVSError as err:
            _, _, tb = sys.exc_info()
            raise SearchError(err), None, tb
        else:
            break

    file_list = None
    if callback is None:
        file_list = set() if collate_trash else []
        for item in succ_xml.split('\n'):
            if item == '':
                continue
            evs_dir_entry = EVSDirEntry(item)
            if collate_trash:
                if evs_dir_entry.deleted_at_level > 0:
                    # Create EVSDirEntry for the ancestor at level
                    #  deleted_at_level and discard the file entry
                    level = evs_dir_entry.deleted_at_level
                    name = evs_dir_entry.name
                    evs_dir_entry.name = '/'.join(name.split('/')[:level])
                    evs_dir_entry.isfile = False
                    evs_dir_entry.has_thumbnail = False
                    evs_dir_entry.size = 0
                    delattr(evs_dir_entry, 'version')

                file_list.add(evs_dir_entry)
            else:
                file_list.append(evs_dir_entry)

    return list(file_list) if collate_trash else file_list

if __name__ == '__main__':
    import cPickle as pickle

    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password', 'search-for'}
    optional_args = {'search-path.store./', 'in-trash', 'incremental'}
    kwargs = process_command_line(required_args, optional_args)

    # Create callback if incremental is set
    callback = None
    if kwargs['incremental']:

        def dump_flist(f_list):
            pkled_f_list = pickle.dumps(f_list)
            # In incremental, write length of each batch first
            print len(pkled_f_list)
            print pkled_f_list

        callback = dump_flist

    # incremental is not accepted by list_files as an argument
    del kwargs['incremental']

    try:
        file_list = search_files(callback=callback, **kwargs)
    except (ValueError, SearchError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        if file_list is not None:
            print pickle.dumps(file_list)

        sys.exit(0)
