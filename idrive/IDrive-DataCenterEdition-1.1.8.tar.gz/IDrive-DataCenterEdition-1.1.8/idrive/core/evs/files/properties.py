"""List properties path."""

import sys

from idrive.core.evs.idevsutil import execute_command, PROPERTIES
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSInvalidServerError, EVSLoginError, EVSInvalidPathError

from idrive.core.evs.account.server_address import get_server_address, \
    ServerAddressError, ServerAddressLoginError
from idrive.core.evs.files.data_types import EVSPropertyEntry
from idrive.core.evs.files.data_types.exceptions import PropertiesError, \
    PropertiesLoginError, PropertiesInvalidPathError


def get_properties(username, password, path, pvtkey=None):
    """Lists file/folder properties from EVS.

    @param username: EVS username
    @param password: EVS password
    @param pvtkey: EVS private key. Optional

    @return: Return a list of EVSPropertyEntry objects if callback is None.
    Otherwise callback will be called with incremental list of
    EVSPropertyEntry object

    @raise ValueError: If inputs are None
    @raise PropertiesLoginError: Invalid username/password
    @raise PropertiesInvaidPathError: Invalid path
    @raise PropertiesError: All other error
    """

    if None in (username, password, path):
        raise ValueError('Invalid parameters passed')

    # retry with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise PropertiesLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise PropertiesError(err), None, tb

        ipaddress = server_address.CLU_SERVER_IP

        try:
            xml_success, xml_error = execute_command(PROPERTIES, username,
                                                     password, pvtkey=pvtkey,
                                                     server_address=ipaddress,
                                                     remote_path=path)

            if xml_error:
                raise EVSErrorFactory.get_error(xml_error)

        except EVSLoginError as err:
            raise PropertiesLoginError(err)
        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise PropertiesError(err)

        except EVSInvalidPathError as err:
            raise PropertiesInvalidPathError(err)
        except (EVSError) as err:
            _, _, tb = sys.exc_info()
            raise PropertiesError(err), None, tb
        else:
            break

    properties = EVSPropertyEntry(xml_success, path)

    return properties


if __name__ == '__main__':
    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    REQ_ARGS = {'username', 'password', 'path'}
    KWARGS = process_command_line(REQ_ARGS)

    try:
        PROPERTIES = get_properties(**KWARGS)
    except (ValueError, PropertiesError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        if PROPERTIES is not None:
            print pickle.dumps(PROPERTIES)

        sys.exit(0)
