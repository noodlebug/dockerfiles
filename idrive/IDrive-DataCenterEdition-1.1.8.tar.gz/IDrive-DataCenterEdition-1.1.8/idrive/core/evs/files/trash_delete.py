"""Delete file/folder from trash."""

from idrive.core.evs.files.private.delete_restore import do_operation, \
    do_operation_ci
from idrive.core.evs.idevsutil import TRASH_DELETE


def trash_delete(username, password, file_list, pvtkey=None):
    """Delete file/folder from trash.

    @param username: EVS username
    @param password: EVS password
    @param file_list: list of file/folder path to delete.
    @param pvtkey: Private key. Optional.

    @return: Instance of DeleteResult class, even if remote delete fails

    @raise DeleteLoginError: Invalid username/password
    @raise DeleteError: All other error except error in delete remote file.
    Such error are reported in DeleteResult itself.

    """

    # Common code for both restore/delete is defined in delete_restore
    # module. From here we only call do_operation with proper operation type
    return do_operation(TRASH_DELETE, username, password, file_list, pvtkey)

if __name__ == '__main__':
    do_operation_ci(TRASH_DELETE)
