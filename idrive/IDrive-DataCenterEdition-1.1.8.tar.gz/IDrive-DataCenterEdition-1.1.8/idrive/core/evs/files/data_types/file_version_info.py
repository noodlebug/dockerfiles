"""Encapsulates version info of a file."""

import re

from datetime import datetime

from idrive.core.evs.idevsutil.data_types import EVSResponse


class FileVersionInfo(object):
    """Encapsulates version info of a file."""

    def __init__(self, xml_string):
        """Constructor."""

        xml_string = re.sub('>[^<]*<', '>\n<', xml_string.strip(),
                            flags=re.DOTALL)

        self.versions = {}
        for xml_line in xml_string.split('\n'):
            xml = EVSResponse(xml_line).xml

            if xml is None:
                raise ValueError("Invalid data : {xml}".format(xml=xml_string))

            if xml.tag == 'item':
                try:
                    version_number = int(xml.get('ver'))
                    size = int(xml.get('size'))
                    modified_date = datetime.strptime(xml.get('mod_time'),
                                                      "%Y/%m/%d %H:%M:%S")
                except (TypeError, ValueError):
                    raise ValueError(('Insufficient data: '
                                      '{}').format(xml_string))

                self.versions[version_number] = \
                    {'size': size, 'modified_date': modified_date}
