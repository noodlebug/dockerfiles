""""Encapsulates file entry retrieved from EVS."""

import os
import re

from idrive.core.data_types import DirEntry
from idrive.core.evs.idevsutil.data_types import EVSResponse


class EVSDirEntry(DirEntry):
    """Encapsulates file entry retrieved from EVS.

    Attributes:
        name              Inherited from DirEntry
        isfile            Inherited from DirEntry
        modified_date     Inherited from DirEntry
        size              Inherited from DirEntry
        version           <type 'int'>. File version
        has_thumbnail     <type 'bool'>. Thumbnail exists for file?
        ref_id            Referrence id of dir entry. Only set
                          for search results which are paginated.

    """

    def __init__(self, xml_string, path=None):
        """Creates an EVSDirEntry object.

        xml_string is a single xml file/folder entry received from
        idevsutil module path is required when xml_enty doesn't contain path
        like in listing. For search, path is already present in fname.

        """

        xml = EVSResponse(xml_string).xml
        if xml is None:
            raise ValueError("Invalid data from EVS " + xml_string)

        name = xml.get('fname')
        restype = xml.get('restype')
        if restype is None:
            restype = 'D' if xml.get('file_ver') == '0' else 'F'
        size = xml.get('size')
        modified_date = xml.get('mod_time')
        thumb = xml.get('thumb')
        ref_id = xml.get('ref_id')
        if ref_id is not None:
            ref_id = int(ref_id)
        deleted_at_level = xml.get('level')
        if deleted_at_level is not None:
            deleted_at_level = int(deleted_at_level)

        if None in [name, restype, size, modified_date, thumb]:
            raise ValueError("Insufficient data : {repl}"
                             .format(repl=xml_string))

        # Make sure path is not passed for XML created by SEARCH
        if name.startswith('/'):
            if path is not None:
                raise ValueError('Multiple path information found')

            path = '/'

        elif path is None:
            raise ValueError("'path' is required")

        name = u'{path}/{name}'.format(path=path, name=name)
        name = re.sub(r'/+', r'/', os.path.realpath(name))

        isfile = restype == 'F'
        try:
            size = int(xml.get('size'))
        except TypeError:
            raise ValueError("Invalid data : {repl}"
                             .format(repl=xml_string))

        super(EVSDirEntry, self).__init__(name, isfile, modified_date, size,
                                          True)

        self.has_thumbnail = thumb == '1'
        self.version = None
        if self.isfile:
            try:
                self.version = int(xml.get('file_ver'))
            except TypeError:
                raise ValueError("Invalid data : {repl}"
                                 .format(repl=xml_string))

        self.ref_id = ref_id
        if deleted_at_level is not None:
            self.deleted_at_level = deleted_at_level
