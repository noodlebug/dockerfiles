
from idrive.core.evs.files.data_types import RenameError
from idrive.core.evs.idevsutil.data_types import EVSResponse


class RenameResult(EVSResponse):
    """Encapsulates rename result."""

    def __init__(self, xml_string=None):
        """Constructor."""

        super(RenameResult, self).__init__(xml_string)

        try:
            self.op_status = self.xml.get('op_status')
            self.oldname = self.xml.get('oldname')
            self.newname = self.xml.get('newname')
        except AttributeError:
            raise RenameError("Insufficient data : {}".format(xml_string))

        if None in [self.op_status, self.oldname, self.newname]:
            raise RenameError("Insufficient data : {}".format(xml_string))
