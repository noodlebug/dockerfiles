"""Contains the idevsutil executable"""

import datetime
import os
import platform
import re
import sys

from idrive import flavors
from idrive.core.evs.idevsutil import EVSValueError


# idevsutil version. please bump whenever updating
VERSION = (1, 0, 2, 8)
RELEASE_DATE = datetime.date(2015, 3, 16)

# the executable folder
FOLDER = os.path.dirname(os.path.realpath(__file__))


def get_version(with_date=False):
    '''
    get the idevsutil version as a string

    @keyword with_date: True if you would like the release date returned with
                        the version
    '''
    version = '.'.join(map(str, VERSION))
    if with_date:
        version += ' ' + RELEASE_DATE.strftime('%Y-%m-%d')
    return version


def get_idevsutil_name():
    '''
    get the name of the idevsutil executable
    '''
    name = platform.system()
    if name == 'Darwin':
        return '_'.join([flavors.current(), 'mac'])
    elif name == 'Linux':
        is_64bit = sys.maxsize > 2 ** 32
        architecture = 'x64' if is_64bit else 'x32'
        return '_'.join([flavors.current(), 'linux', architecture])

    raise EVSValueError('Unsupported platform executable')


def set_idevsutil_executable():
    '''
    marks all the idevsutil* files as executable by the system
    '''
    folder = os.path.dirname(os.path.realpath(__file__))

    for executable in os.listdir(folder):
        if not re.search(r'\.py[oc]?$', executable, re.IGNORECASE):
            os.chmod(os.path.join(folder, executable), 0755)
