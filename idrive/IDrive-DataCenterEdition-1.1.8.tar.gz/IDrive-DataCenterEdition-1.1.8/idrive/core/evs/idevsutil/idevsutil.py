""""Wrapper around idevsutil executable"""

import datetime
import collections
import os
import pwd
import re
import select
import subprocess
import sys
import threading
import time

from tempfile import NamedTemporaryFile, gettempdir

from idrive.core.evs.idevsutil import output_filters
from idrive.core.evs.idevsutil.executable import get_idevsutil_name, \
    FOLDER as EXECUTABLE_FOLDER
from idrive.core.evs.idevsutil.data_types import EVSError, EVSValueError, \
    EVSCommunicationError, EVSErrorFactory


VALIDATE = 10
CONFIGURE = 20
GET_ADDRESS = 30
QUOTA = 40
LIST = 50
SEARCH = 60
VERSION = 70
PROPERTIES = 80
UPLOAD = 90
DOWNLOAD = 110
DELETE = 120
RESTORE = 130
TRASH_DELETE = 140
CREATE_DIR = 150
RENAME = 160
COPY = 170
_ENCODE = 180  # internal command to get encoded password/pvtkey
UPLOAD_LOG = 190
VALIDATE_PVTKEY = 200

VERSION_ID = '_IBVER{:03d}'

CANCEL_OP_INIT = '1'
CANCEL_OP = '3'

_IDEVSUTIL = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                          EXECUTABLE_FOLDER, get_idevsutil_name())

_COMMANDS = {
    VALIDATE: '--validate',
    CONFIGURE: '--config-account',
    GET_ADDRESS: '--getServerAddress',
    QUOTA: '--get-quota',
    LIST: '--auth-list',
    SEARCH: '--search',
    VERSION: '--version-info',
    PROPERTIES: '--properties',
    DELETE: '--delete-items',
    RESTORE: '--moveto-original',
    TRASH_DELETE: '--deletefrom-trash',
    CREATE_DIR: '--create-dir',
    RENAME: '--rename2',
    COPY: '--copy-within',
    UPLOAD: None,
    DOWNLOAD: None,
    UPLOAD_LOG: '--backup-log',
    _ENCODE: '--string-encode',
    VALIDATE_PVTKEY: None,
}

_MIN_PVTKEY_LEN = 4

_CALLBACK_TIMEOUT = 0.25
_THREAD_JOIN_TIMEOUT = 0.25
_MAX_OUTPUT_LINES = 100

_PASSWORD_PROMPT = 'Password: '
_PASSWORD_PROMPT_TIMEOUT = 20  # seconds

# _PROCESS_MAX_WAIT_TIMES * _CALLBACK_TIMEOUT = total timeout time
# in seconds after which we'll kill the idevsutil process if it doesn't
# feed us anything in stderr or stdout
_PROCESS_MAX_WAIT_TIMES = 7200  # 30 minutes


def _read_data_loop(file_fd, data_deque, filter_index):
    '''
    Thread method for reading data into a deque
    '''
    # read data till '' which mean EOF
    while True:
        line = file_fd.readline()
        if line == '':
            break

        # skip blank lines or lines with only whitespaces
        if re.match('^\s*$', line) is not None:
            continue

        line = output_filters.clean(line, filter_index)
        data_deque.append(line)


def _read_data(stdout_, stderr_, stdout_deque, stderr_deque):
    '''
    Internal method to read data in thread
    '''
    stdout_thread = threading.Thread(
        target=_read_data_loop,
        args=(stdout_, stdout_deque, output_filters.STDOUT))
    stderr_thread = threading.Thread(
        target=_read_data_loop,
        args=(stderr_, stderr_deque, output_filters.STDERR))

    # These threads will automatically die when main thread exits
    stdout_thread.daemon = True
    stderr_thread.daemon = True

    stdout_thread.start()
    stderr_thread.start()

    return stdout_thread, stderr_thread


def _translate(command, username, password, pvtkey, server_address,
               remote_path, local_path, file_list, relative, in_trash,
               tmp_file, tmp_check_cancel_file, tmp_bandwidth_file,
               offset, limit):
    """Internal method to translate given command and params
    to those required by idevsutil utility
    """
    idevsutil_cmd = [_IDEVSUTIL]

    # for internal ENCODE command
    if command == _ENCODE:
        idevsutil_cmd.append('{}={}'.format(_COMMANDS[command],
                                            (password or pvtkey)))

    # For all other commands
    else:
        idevsutil_cmd.extend(('--add-progress', '--xml-output', '--encode'))

        # vars
        local_username = pwd.getpwuid(os.getuid()).pw_name
        local_path = local_path or '/'
        local_path = os.path.normpath(u'/' + local_path.lstrip('/'))

        if _COMMANDS[command] is not None:
            if command == CREATE_DIR:
                remote_path = os.path.normpath(u"/" + remote_path.lstrip('/'))
                idevsutil_cmd.append(u'{}={}'
                                     .format(_COMMANDS[command], remote_path))
                remote_path = None
            else:
                idevsutil_cmd.append(_COMMANDS[command])

        if command == CONFIGURE:
            if pvtkey is not None:
                idevsutil_cmd.append('--enc-type=PRIVATE')
            else:
                idevsutil_cmd.append('--enc-type=DEFAULT')

        if pvtkey is not None:
            idevsutil_cmd.append('--pvt-key={}'.format(pvtkey))

        if command in [VALIDATE, CONFIGURE]:
            idevsutil_cmd.append('--user=' + username)

        if command == GET_ADDRESS:
            idevsutil_cmd.append(username)

        if command == UPLOAD and tmp_bandwidth_file:
            idevsutil_cmd.append('--bw-file={}'
                                 .format(tmp_bandwidth_file.name))

        if command in [DELETE, RESTORE, TRASH_DELETE, COPY, UPLOAD, DOWNLOAD,
                       UPLOAD_LOG]:
            if command == COPY:
                file_list = remote_path['from']
                remote_path = os.path.normpath(u"/" +
                                               remote_path['to'].lstrip('/'))

            # append newline to each path and write to tmp file
            file_list = [(l.encode('utf8') if isinstance(l, unicode) else l) +
                         '\n' for l in file_list]

            tmp_file.writelines(file_list)
            tmp_file.flush()  # Must flush for file list to be available

            idevsutil_cmd.append('--files-from={}'.format(tmp_file.name))

        if command == RENAME:
            from_path = os.path.normpath("/" + remote_path['from'].lstrip('/'))
            to_path = os.path.normpath("/" + remote_path['to'].lstrip('/'))
            remote_path = None

            if isinstance(from_path, unicode):
                from_path = from_path.encode('utf8')
            if isinstance(to_path, unicode):
                to_path = to_path.encode('utf8')

            # using --rename with --old-path and --new-path does not work
            #  for unicode filenames. Need to use --files-from instead
            tmp_file.writelines(['--O={old}\n'.format(old=from_path),
                                 '--N={new}'.format(new=to_path)])
            tmp_file.flush()  # Must flush for file list to be available

            idevsutil_cmd.append('--files-from={}'.format(tmp_file.name))

        if command in [UPLOAD, DOWNLOAD]:
            if relative is not None:
                idevsutil_cmd.append('--relative')
            else:
                idevsutil_cmd.append('--no-relative')

            idevsutil_cmd.append('--temp=' +
                                 os.path.join(gettempdir(), local_username,
                                              username) + '/')

            if tmp_check_cancel_file is not None:
                idevsutil_cmd.append('--chk-cancel={}'
                                     .format(tmp_check_cancel_file.name))

        if command == UPLOAD_LOG:
            idevsutil_cmd.append('--no-relative')
            idevsutil_cmd.append('--temp=' +
                                 os.path.join(gettempdir(), local_username,
                                              username) + '/')

        if command in [UPLOAD, UPLOAD_LOG]:
            idevsutil_cmd.append(local_path)

        if command == SEARCH:
            if offset is not None:
                idevsutil_cmd.append('--rowid={:d}'.format(offset))
                idevsutil_cmd.append('--limit={:d}'.format(limit))

            if in_trash:
                idevsutil_cmd.append('--trash')
                idevsutil_cmd.append('--level')

        if (command in [QUOTA, LIST, SEARCH,
                        VERSION, PROPERTIES,
                        DELETE, RESTORE, TRASH_DELETE,
                        CREATE_DIR, RENAME, COPY,
                        UPLOAD, DOWNLOAD, UPLOAD_LOG,
                        VALIDATE_PVTKEY]):
            remote_path = remote_path or '/'
            remote_path = os.path.normpath(u"/" + remote_path.lstrip('/'))
            idevsutil_cmd.extend(['--',
                                  u'{user}@{server}::home{path}'
                                  .format(user=username, server=server_address,
                                          path=(remote_path))])

        if command == DOWNLOAD:
            idevsutil_cmd.append(local_path)

    return idevsutil_cmd


def _check_params(command, username, password, pvtkey, server_address,
                  remote_path, local_path, file_list, callback, bandwidth,
                  offset, limit):
    """Validates parameters for idevsutil

    Enforces different validation requirements for different commands
    """

    if command not in _COMMANDS:
        raise EVSValueError('invalid command')

    if not username and not password and not pvtkey:
        raise EVSValueError("'username' required.")

    if not password and not pvtkey:
        raise EVSValueError("'password' required.")

    if pvtkey is not None and len(pvtkey) < _MIN_PVTKEY_LEN:
        raise EVSValueError("'pvtkey' must be at least {len} chars"
                            .format(len=_MIN_PVTKEY_LEN))

    if (command not in (_ENCODE, VALIDATE, CONFIGURE, GET_ADDRESS) and
            server_address is None):
        raise EVSValueError("'server_address' required.")

    if callback is not None and not callable(callback):
        raise EVSValueError("Invalid callback.")

    if (command in (LIST, SEARCH, VERSION, PROPERTIES, CREATE_DIR, UPLOAD,
                    UPLOAD_LOG) and remote_path is None):
        raise EVSValueError("'remote_path' required.")

    if command in (DELETE, RESTORE, TRASH_DELETE, UPLOAD, DOWNLOAD,
                   UPLOAD_LOG):
        if (file_list is None or not isinstance(file_list, list) or
                not file_list):
            raise EVSValueError("'file_list' is invalid.")

        if command in (UPLOAD, UPLOAD_LOG):
            # Note: Not checking local file existence here as schedule
            # backups will not start if we don't allow non existent
            # files to be backup up
            local_path = local_path or '/'
            file_list = [os.path.normpath(os.path.join(local_path, path))
                         for path in file_list]

    if command in (RENAME, COPY):
        if (remote_path is None or not isinstance(remote_path, dict) or
                not remote_path):
            raise EVSValueError("'remote_path' is invalid")

        if 'from' not in remote_path or 'to' not in remote_path:
            raise EVSValueError("'remote_path' is invalid")

        if command == COPY:
            if (remote_path['from'] is None or
                    not isinstance(remote_path['from'], list) or
                    not remote_path['from']):
                raise EVSValueError("'remote_path' is invalid")

    if command == DOWNLOAD:
        if local_path is None:
            raise EVSValueError("'local_path' required.")
        elif not os.path.isdir(local_path):
            raise EVSValueError("'local_path' is invalid.")

    if command == UPLOAD and bandwidth is None:
        raise EVSValueError('"bandwidth" is required for uploads')

    if command == VALIDATE_PVTKEY:
        if pvtkey is None or pvtkey == '':
            raise EVSValueError("'pvtkey' required")

    if command == SEARCH:
        if limit is not None:
            if not isinstance(limit, int):
                raise EVSValueError("'limit' must be an integer")
            if offset is None:
                raise EVSValueError("'offset' is required")
            if not isinstance(offset, int):
                raise EVSValueError("'offset' must be an integer")


def _run(idevsutil_cmd, command, password, callback):
    """Runs a formatted idevsutil_cmd on idevsutil and returns the results

    @param idevsutil_cmd: a list containing the idevsutil_cmd and flags/params
        to pass to idevsutil
    @param command: the command itself, not the translated command to pass
        to idevsutil
    @param password: user's password
    @param callback: function to call during commands that need progress
        updates - e.g. uploads, downloads
    """
    try:
        process = subprocess.Popen(idevsutil_cmd, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, bufsize=4096,
                                   stdin=subprocess.PIPE,
                                   preexec_fn=os.setsid)
    except OSError as err:
        _, _, traceback = sys.exc_info()
        raise EVSError(str(err)), None, traceback

    # write password directly to the process' stdin, don't pass as parameter
    if command != _ENCODE:
        prompt = ''
        prompt_timeout = datetime.datetime.now()
        prompt_timeout += datetime.timedelta(seconds=_PASSWORD_PROMPT_TIMEOUT)

        while not prompt.endswith(_PASSWORD_PROMPT):
            if datetime.datetime.now() > prompt_timeout:
                process.kill()

                # did we get any meaningful data from idevsutil before timeout
                for error_line in output_filters.clean(prompt).splitlines():
                    if error_line.startswith('@E'):
                        raise EVSErrorFactory.get_error(error_line[2:])

                # raise generic timeout error if no meaningful data received
                raise EVSCommunicationError(
                    'idevsutil timed out while waiting for password prompt'
                )

            readable = select.select([process.stderr.fileno()], [], [], 1)[0]

            # password prompt comes on stderr
            if process.stderr.fileno() in readable:
                # Note: use os.read(). file.read() resets the read bit
                #  on process.stderr which causes select to timeout
                prompt += os.read(process.stderr.fileno(), 1)

        process.stdin.write(password + '\n')
        process.stdin.flush()

    # read data from process in a thread
    stdout_deque = collections.deque()
    stderr_deque = collections.deque()
    stdout_thread, stderr_thread = _read_data(process.stdout, process.stderr,
                                              stdout_deque, stderr_deque)

    # monitor child process and read data from deque
    success_data = ''
    error_data = ''
    process_check_count = 0
    while process.poll() is None:
        # poll() will return immediately, whether or not child process
        #  has spilled some data to read. We will sleep for some time
        #  if there was no data from child process to read before
        #  going for next iteration. This significantly brings down
        #  CPU usage. Otherwise, continuous poll()ing of child process
        #  uses up all CPU.

        should_sleep = True
        if stdout_deque:
            process_check_count = 0
            should_sleep = False
            for _ in range(1, _MAX_OUTPUT_LINES):
                try:
                    line = stdout_deque.popleft()
                    if line[0:2] == '@E':
                        error_data += line[2:]
                    else:
                        success_data += line
                except IndexError:
                    # @1 - Got less than _MAX_OUTPUT_LINES
                    #  wait _CALLBACK_TIMEOUT below before doing callback
                    should_sleep = True
                    break
        if stderr_deque:
            process_check_count = 0
            should_sleep = False
            while True:
                try:
                    error_data += stderr_deque.popleft()
                except IndexError:
                    break

        # sleep before doing callback so that @1 above is handled
        if should_sleep:
            time.sleep(_CALLBACK_TIMEOUT)

            if not success_data and not error_data:
                # no data? increment process_check_count
                process_check_count += 1
                if process_check_count > _PROCESS_MAX_WAIT_TIMES:
                    # When process_check_count reaches _PROCESS_MAX_WAIT_TIMES
                    #  we would have already waited for
                    #  _CALLBACK_TIMEOUT * _PROCESS_MAX_WAIT_TIMES seconds
                    #  and still no data received from idevsutil. We'll kill
                    #  process and raise error.
                    process.kill()
                    stdout_thread.join(_THREAD_JOIN_TIMEOUT)
                    stderr_thread.join(_THREAD_JOIN_TIMEOUT)

                    # raise generic timeout error as there was no data received
                    raise EVSCommunicationError(
                        'idevsutil timed out while waiting for output'
                    )

        if callback and (success_data or error_data):
            callback(success_data.rstrip(), error_data.rstrip())
            success_data = ''
            error_data = ''

    # Wait for _THREAD_JOIN_TIMEOUT for threads to finish reading data
    #  if threads don't join, they will automatically die when
    #  the main thread exits
    stdout_thread.join(_THREAD_JOIN_TIMEOUT)
    stderr_thread.join(_THREAD_JOIN_TIMEOUT)

    # get any remaining data out of deque
    while True:
        try:
            line = stdout_deque.popleft()
            if line[0:2] == '@E':
                error_data += line[2:]
            else:
                success_data += line
        except IndexError:
            break

    while True:
        try:
            error_data += stderr_deque.popleft()
        except IndexError:
            break

    if callback:
        callback(success_data.rstrip(), error_data.rstrip())
        return None, None
    else:
        return success_data.rstrip(), error_data.rstrip()


def execute_command(command, username, password, pvtkey=None,
                    server_address=None, remote_path=None, local_path=None,
                    file_list=None, callback=None, relative=None,
                    in_trash=False, check_cancel=None, bandwidth=None,
                    offset=None, limit=None):
    """Interface to idevsutil subsystem.

    If 'callback' is provided, calls the callable with
    tuple (success_data, error_data) every 100 lines of output or whenever
    there is error_data or every _CALLBACK_TIMEOUT seconds. Return value
    of execute_command will be None when all output has been received.

    If callback is not provided, return value is
    tuple (success_data, error_data).

    error_data represents error received from idevsutil after it started
    execution.

    @param remote_path:
        For command=SEARCH, use remote_path to indicate search criteria

        For copy/move/rename, remote_path should be a dictionary, with keys
        'from' and 'to'.
        'from' should be string for rename, list for copy/move
        'to' should be string

    @param relative: only for upload/download operations

    @param in_trash: applies only for SEARCH

    For downloads, any file_list entry can be appended by
    idevsutil.VERSION_ID.format(n)
    where n represents a file version in integer
    to download a particular version of that file.

    @param check_cancel: applies only to upload and download. If passed, it
    must be a dict which will be assigned a file path against the 'filename'
    key. This file can be used to cancel an ongoing upload/download by writing
    CANCEL_OP into the file.

    @param bandwidth: for uploads only. integer between 1 and 100 indicating
        how much percent of the user's bandwidth may be used

    @param offset: Only applicable to SEARCH. This is the ref_id of the
        file/folder after which the search should begin.
    @param limit: Only applicable to SEARCH. This is the max number of
        files/folders displayed in search result. offset is necessary for
        limit to work.

    """
    _check_params(command, username, password, pvtkey, server_address,
                  remote_path, local_path, file_list, callback, bandwidth,
                  offset, limit)
    tmp_file = None
    tmp_check_cancel_file = None
    tmp_bandwidth_file = None

    # encode if necessary
    if command is not _ENCODE:
        # encode password
        if password is not None:
            password = execute_command(_ENCODE, None, password)[0]
            password = password.split('=')[1]

        # encode pvtkey
        if pvtkey is not None:
            pvtkey = execute_command(_ENCODE, None, None, pvtkey)[0]
            pvtkey = pvtkey.split('=')[1]

        # tmp_file must open here so that it gets deleted at end of method
        tmp_file = NamedTemporaryFile(delete=True)
        # cancel
        if isinstance(check_cancel, dict):
            tmp_check_cancel_file = NamedTemporaryFile(delete=True)
            tmp_check_cancel_file.write(CANCEL_OP_INIT)
            tmp_check_cancel_file.flush()
            check_cancel['filename'] = tmp_check_cancel_file.name
        # bandwidth
        if bandwidth:
            tmp_bandwidth_file = NamedTemporaryFile(delete=True)
            tmp_bandwidth_file.write(str(bandwidth))
            tmp_bandwidth_file.flush()

    idevsutil_cmd = _translate(command, username, password, pvtkey=pvtkey,
                               server_address=server_address,
                               remote_path=remote_path, local_path=local_path,
                               file_list=file_list, relative=relative,
                               in_trash=in_trash, tmp_file=tmp_file,
                               tmp_check_cancel_file=tmp_check_cancel_file,
                               tmp_bandwidth_file=tmp_bandwidth_file,
                               offset=offset, limit=limit)

    return _run(idevsutil_cmd, command, password, callback)
