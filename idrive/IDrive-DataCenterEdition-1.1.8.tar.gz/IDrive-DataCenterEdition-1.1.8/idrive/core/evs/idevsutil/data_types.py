"""idevsutil related data types. Most Exception classes."""

from xml.etree import ElementTree


class EVSResponse(object):
    """Base class for parsing XML returned from EVS"""

    def __init__(self, xml_string=None):
        '''
        Parses the xml_string

        @param xml_string: Only xml strings are processed, everything else is
        ignored.

        @note: xml_string must represent a single root xml element, which
        can have children. Multiple xml elements at root level will not
        work.
        '''
        self.xml = None

        # element tree only consumes byte strings in python 2.x
        if isinstance(xml_string, unicode):
            xml_string = xml_string.encode('utf-8')

        if isinstance(xml_string, str):
            try:
                root = ElementTree.fromstring(xml_string)
            except ElementTree.ParseError:
                pass
            else:
                self.xml = root


class EVSError(Exception):
    """Base EVS Exception class"""

    def __init__(self, data=None):
        '''
        Constructor

        @param data: Can be an XML string, a subclass of EVSError (with a
                     "message" attribute or a plain string
        '''
        self.xml = EVSResponse(data).xml
        if self.xml is not None:
            self.message = self.xml.get('desc').strip().lower().capitalize()
        elif isinstance(data, (str, unicode)):
            self.message = data.lower().capitalize()
        elif hasattr(data, 'message'):
            self.message = data.message

        super(EVSError, self).__init__(self.message)

    def __eq__(self, other):
        return hasattr(other, 'message') and self.message == other.message


class EVSLoginError(EVSError):
    """"Invalid username/password error."""
    pass


class EVSInvalidPathError(EVSError):
    """"Invalid path error."""

    def __init__(self, data=None):
        """Constructor

        @param data: Can be xml, string or another EVSError object

        """

        super(EVSInvalidPathError, self).__init__(data)

        if self.xml is not None:
            if 'path' in self.xml.attrib:
                self.path = self.xml.get('path')

            elif 'oldname' in self.xml.attrib:
                self.path = self.xml.get('oldname')
        else:
            if hasattr(data, 'path'):
                self.path = data.path


class EVSInvalidServerError(EVSError):
    """"Invalid server address error."""
    pass


class EVSValueError(EVSError):
    """"Invalid parameter error."""
    pass


class EVSMultipleError(EVSError):
    """Container for mutiple errors."""

    def __init__(self):
        """Constructor"""

        self.errors = []

    def add(self, error):
        self.errors.append(error)

    def __iter__(self):
        return iter(self.errors)


class EVSAccountUnderMaintenanceError(EVSError):
    """Account under maintenance"""
    pass


class EVSCommunicationError(EVSError):
    """Network/subsystem communication error"""
    pass


class EVSErrorFactory(object):
    """Factory class for exception object."""

    @classmethod
    def get_error(cls, xml_string):
        """Generates an exception object and returns base on input xml."""

        evs_multiple_error = EVSMultipleError()

        for xml_line in xml_string.split('\n'):
            error = EVSError(xml_line)
            err_msg = error.message.lower()

            if (err_msg in ['no such file or directory', 'invalid old path',
                            'permission denied', 'new path already exists',
                            'path not found']):
                # Note: EVSInvalidPathError needs the xml to get the path
                #  out. Don't pass EVSError here
                evs_multiple_error.add(EVSInvalidPathError(xml_line))

            elif err_msg == 'invalid username or password':
                evs_multiple_error.add(EVSLoginError(error))

            elif err_msg == 'invalid server for user':
                evs_multiple_error.add(EVSInvalidServerError(error))

            elif err_msg.startswith('invalid value passed for'):
                evs_multiple_error.add(EVSValueError(error))

            elif err_msg == 'account is under maintenance':
                evs_multiple_error.add(EVSAccountUnderMaintenanceError(error))

            elif (err_msg.startswith('failed to connect') or
                    err_msg.startswith('getaddrinfo') or
                    err_msg == 'network timeout'):
                evs_multiple_error.add(EVSCommunicationError(error))

            else:
                evs_multiple_error.add(error)

        if len(evs_multiple_error.errors) == 1:
            return evs_multiple_error.errors[0]
        else:
            return evs_multiple_error
