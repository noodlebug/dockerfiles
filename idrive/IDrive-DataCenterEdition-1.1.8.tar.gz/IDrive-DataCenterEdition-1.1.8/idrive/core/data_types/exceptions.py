"""Exceptions used by core package."""


class ListingError(Exception):
    """Listing related errors"""
    pass
