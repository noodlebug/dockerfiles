'''Encapsulates a file/folder object, both remote and local.'''

import os
import hashlib

from datetime import datetime

from idrive.utils import pluralize


class DirEntry(object):
    '''
    Directory entry representing a file or folder

    isfile, size and modified_date are automatically filled up from system if
    not provided. File/folder must exist in system if only name is provided.

    Attributes:
        name            <type 'string'>. Full path of file/folder
        isfile          <type 'bool'>.
        modified_date   <type 'datetime'>
        size            <type int>. Size in bytes
        can_read        <type bool>. Optional.
    '''

    def __init__(self, name, isfile=None, modified_date=None, size=None,
                 can_read=None):
        '''
        If only name is given, rest of the attributes are filled
        up from system. Otherwise, all attributes must be passed.
        modified_date can be UNIX timestamp, string representing date
        or datetime object. size must be int, and isfile bool

        isfile is None if entry is neither a regular file, nor a directory

        For symlinks, the name will remain as the path to the symlink itself,
        however the "target" property will have the full path of target

        can_read is optional, unlike the other three params, isfile,
        modified_date and size when creating DirEntry directly.
        '''

        # accept all string types, but internally only use unicode
        if not isinstance(name, unicode):
            name = name.decode('utf8')

        name = os.path.normpath(name)
        if not os.path.isabs(name):
            raise ValueError("name must be absolute path")

        # only name provided
        if isfile is None and modified_date is None and size is None:
            # bug 450: use lexists() over exists() because the latter will
            # return false if its broken symlink
            if not os.path.lexists(name):
                raise ValueError('File/folder does not exist: %s' % name)

            if os.path.islink(name):
                self.isfile = None
                self.islink = True
                self.target = os.path.realpath(name)
            else:
                self.islink = False
                self.target = None

                if os.path.isdir(name):
                    self.isfile = False
                else:
                    self.isfile = True

            stats = os.lstat(name)  # use lstat() to not follow symlinks
            self.name = name
            self.size = stats.st_size
            self.modified_date = datetime.fromtimestamp(stats.st_mtime)
            self.can_read = os.access(name, os.R_OK)

        # otherwise all must be provided
        elif None in (isfile, modified_date, size):
            raise ValueError('Must provide all arguments or only name')

        else:
            self.name = name
            self.isfile = bool(isfile)
            self.can_read = can_read

            try:
                self.size = int(size)
            except ValueError:
                raise ValueError('Invalid size: %s' % size)

            try:
                if isinstance(modified_date, datetime):
                    self.modified_date = modified_date
                elif isinstance(modified_date, float):
                    self.modified_date = datetime.fromtimestamp(modified_date)
                else:
                    self.modified_date = \
                        datetime.strptime(modified_date, "%Y/%m/%d %H:%M:%S")
            except ValueError:
                raise ValueError('Invalid modified date: %s' % modified_date)

    def __hash__(self):
        '''
        object id
        '''
        return int(hashlib.md5(self.name.encode('utf8')).hexdigest(), 16)

    def __eq__(self, other):
        if isinstance(other, DirEntry):
            return self.name == other.name
        raise NotImplementedError(
            'Cannot compare {} with {}'.format(type(self), type(other)))

    def __ne__(self, other):
        return not self == other

    def __lt__(self, other):
        if isinstance(other, DirEntry):
            return self.name < other.name
        raise NotImplementedError(
            'Cannot compare {} with {}'.format(type(self), type(other)))

    def __gt__(self, other):
        if isinstance(other, DirEntry):
            return self.name > other.name
        raise NotImplementedError(
            'Cannot compare {} with {}'.format(type(self), type(other)))

    def __str__(self):
        return '{} || {} {} || {}'.format(
            self.name.encode('utf8'), self.size,
            pluralize.pluralize('byte', self.size),
            self.modified_date.strftime('%c'))

    def __repr__(self):
        return str(self)
