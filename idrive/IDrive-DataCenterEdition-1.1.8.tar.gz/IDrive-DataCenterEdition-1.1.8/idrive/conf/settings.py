'''Application settings classes.

Encapsulates application and user specific settings

'''

import os
import pwd
import ConfigParser

from idrive import SHORT_NAME, flavors
from idrive.utils.singleton import MetaSingleton
from idrive.utils.bunch import Bunch


_defaults_parser = flavors.get_config()


class BaseSettings(object):
    """Base class for settings classes"""

    def _load_config(self, config_file, path_prefix='/', defaults=None):
        """Loads configuration from config_file."""

        config_parser = ConfigParser.ConfigParser(defaults)
        try:
            with open(config_file) as fd:
                config_parser.readfp(fd)
        except (IOError, ConfigParser.Error) as err:
            raise ValueError("Error reading config file {} : {}"
                             .format(config_file, str(err)))

        defaults_keys = defaults.keys() if defaults is not None else []
        for section in config_parser.sections():
            dict_ = {}
            for option, value in config_parser.items(section):
                if option in defaults_keys:
                    continue

                # expand all relative paths
                if option.endswith('path') and not value.startswith('/'):
                    value = path_prefix + os.path.sep + value

                dict_[option] = value

            if hasattr(self, section):
                # For existing values, should updated existing dict with
                #  new dict to make sure newer values override older values
                getattr(self, section).__dict__.update(dict_)
            else:
                setattr(self, section, Bunch(dict_))

    def _update_config(self, config_file, section, option, value):
        """Write the config file."""

        config_parser = ConfigParser.SafeConfigParser()
        config_parser.read(config_file)

        if not config_parser.has_section(section):
            config_parser.add_section(section)

        if isinstance(value, unicode):
            value = value.encode('utf8')
        else:
            value = str(value)

        config_parser.set(section, option, value)
        try:
            with open(config_file, 'w') as fp:
                config_parser.write(fp)
        except IOError as err:
            raise ValueError("Could not write config file {} : {}"
                             .format(config_file, str(err)))

    def as_dict(self):
        """Returns a dictionary of all settings."""

        dict_ = {}
        for section in self:
            for option in self[section]:
                dict_.update({section + '_' + option: self[section][option]})

        return dict_


class GlobalSettings(BaseSettings):
    """Encapsulates global settings of the app.

    Settings are loaded from global.ini either provided to this app
    or from the default global.ini file.

    """

    __metaclass__ = MetaSingleton

    GLOBAL_CONFIG_FILENAME = u'global.ini'
    _DEFAULTS = dict(
        _defaults_parser.items('APP') + _defaults_parser.items('URL')
    )  # for interpolation

    def __init__(self, config_path=u'/etc/' + SHORT_NAME, app_path=None):
        """Constructor

        config_path is where the custom config file is stored.

        """

        if (config_path == u'/etc/' + SHORT_NAME and
                not os.path.exists(config_path) and
                os.getuid() == 0):
            # should be readable by 'nobody:nobody'
            os.makedirs(config_path, 0755)

        if app_path is None:
            app_path = \
                os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

        self._app_path = app_path
        self._config_file = os.path.join(config_path,
                                         self.GLOBAL_CONFIG_FILENAME)
        self._reload_config()

        self.APPLICATION.config_path = config_path

    def _reload_config(self):
        """Reloads config"""

        current_dir = os.path.dirname(os.path.realpath(__file__))

        # load ini file in current folder first
        config_file = os.path.join(current_dir, self.GLOBAL_CONFIG_FILENAME)
        if os.path.exists(config_file):
            self._load_config(config_file, self._app_path, self._DEFAULTS)

        # Now load custom config file
        if os.path.exists(self._config_file):
            self._load_config(self._config_file, self._app_path,
                              self._DEFAULTS)

    def update_config(self, section, option, value):
        """Write the config file."""
        try:
            self._update_config(self._config_file, section, option, value)
            self._reload_config()
        except OSError:
            pass  # no permissions

    def __repr__(self):
        """Pretty printing."""

        return repr(self.__dict__)

    def __getitem__(self, index):
        """Subscript access."""

        try:
            item = getattr(self, index)
        except AttributeError:
            raise IndexError("{} not found".format(index))

        return item

    def __iter__(self):
        """Iterator."""

        for section in self.__dict__:
            if section.startswith('_'):
                continue
            yield section


class UserSettings(BaseSettings):
    """Encapsulates User specific settings.

    Default user settings is loaded from user_settings.ini and
    remote_user_settings.ini. These are overridden by .ini files in
    users home directory.

    """

    USER_SETTINGS_DIR = '.{}'.format(SHORT_NAME)
    DEFAULT_LOCAL_CFGFILE = 'local_settings.ini'
    DEFAULT_REMOTE_CFGFILE = 'remote_settings.ini'

    def __init__(self, remote_username=None):
        """Constructor."""

        # first load the global settings into self
        global_settings = GlobalSettings()
        for section in global_settings:
            setattr(self, section, global_settings[section])

        # Load the default local .ini files
        user_root = os.path.join(pwd.getpwuid(os.getuid()).pw_dir,
                                 self.USER_SETTINGS_DIR)
        default_local_cfgfile = global_settings.APPLICATION.local_cfgfile_path
        self._load_config(default_local_cfgfile, user_root)

        # Load user's custom local .ini file
        local_cfgfile = self.LOCAL.cfgfile_path
        if os.path.exists(local_cfgfile):
            self._load_config(local_cfgfile, user_root)

        # remote settings are loaded only if remote_username is passed
        self._remote_username = None
        if remote_username is not None:
            # First load remote default .ini file
            remote_user_root = self.LOCAL.path + remote_username
            default_remote_cfgfile = \
                global_settings.APPLICATION.remote_cfgfile_path
            self._load_config(default_remote_cfgfile, remote_user_root)

            # Load user's custom remote .ini file
            remote_cfgfile = self.REMOTE.cfgfile_path
            if os.path.exists(remote_cfgfile):
                self._load_config(remote_cfgfile, remote_user_root)

            self._remote_username = remote_username

    def update_local(self, section, option, value):
        """Update local_settings.ini in users home directory."""

        if not os.path.exists(self.LOCAL.path):
            os.makedirs(self.LOCAL.path, mode=0700)

        self._update_config(self.LOCAL.cfgfile_path, section, option, value)
        self._load_config(self.LOCAL.cfgfile_path,
                          pwd.getpwuid(os.getuid()).pw_dir)

        return self

    def update_remote(self, section, option, value):
        """Update remote_settings.ini in users home directory.

        remote_username must be set in constructor for this to work.

        """

        if self._remote_username is None:
            raise ValueError("remote_username not set during init")

        if not os.path.exists(self.REMOTE.path):
            os.makedirs(self.REMOTE.path, mode=0700)
        self._update_config(self.REMOTE.cfgfile_path, section, option, value)
        self._load_config(self.REMOTE.cfgfile_path, self.REMOTE.path)

        return self

    def __repr__(self):
        """Pretty printing."""

        dict_ = self.__dict__.copy()
        del dict_['_remote_username']
        return str(dict_)

    def __getitem__(self, index):
        """Subscript access."""

        try:
            item = getattr(self, index)
        except AttributeError:
            raise IndexError("{} not found".format(index))

        return item

    def __iter__(self):
        """Iterator."""

        dict_ = self.__dict__.copy()
        del dict_['_remote_username']
        return iter(dict_)
