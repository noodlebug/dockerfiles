"""Configuration Package.

Stores all application configuration data

"""
