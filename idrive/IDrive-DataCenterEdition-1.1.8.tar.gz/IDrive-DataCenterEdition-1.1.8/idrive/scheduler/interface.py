"""Interface to interact with the scheduler daemon."""

import os
import pwd
import sys
import socket

from multiprocessing.connection import Client, AuthenticationError

from idrive.common.data_types import LoginData
from idrive.conf.settings import GlobalSettings
from idrive.scheduler import _AUTHKEY
from idrive.scheduler.data_types import JobSchedule
from idrive.scheduler.private import ADD_JOB, REMOVE_JOB, GET_JOBS, \
    GET_PROGRESS, CANCEL_JOB, BACKUP_JOB, RESTORE_JOB, \
    CLIENT_RETRY_TIMEOUT  # @UnusedImport
from idrive.utils import log


def _send_job_to_server(job_details):
    """Internal function to send job to server."""

    g = GlobalSettings()
    try:
        host = g.SCHEDULER.host
    except AttributeError:
        log.warning("Could not get scheduler server host from conf")
        log.warning("Connecting to default 'localhost'")
        host = 'localhost'

    try:
        port = int(g.SCHEDULER.port)
    except (AttributeError, ValueError):
        log.warning("Could not get scheduler server port from conf")
        log.warning("Connecting to default port '50000'")
        port = 50000

    log.debug("Connecting to scheduler at {}:{}"
              .format(host, port), mod_name=__name__)
    try:
        connection = Client((host, port), authkey=_AUTHKEY)
    except socket.error:
        raise RuntimeError("Scheduler daemon not running")
    except AuthenticationError:
        raise RuntimeError("Scheduler may not be running on default port")

    log.debug("Sending command to scheduler", mod_name=__name__)
    connection.send((job_details))

    return connection


def _reply_client(connection):
    """Returns data to client read from connection or raises exception"""

    result = None
    try:
        result = connection.recv()
    except EOFError:
        log.error("No data received from scheduler", mod_name=__name__)
        raise RuntimeError("There was some error communicating with scheduler")
    else:
        if isinstance(result, Exception):
            log.error("Scheduler returned error : {}".format(str(result)),
                      mod_name=__name__)
            _, _, tb = sys.exc_info()
            raise result.__class__, result, tb

        log.debug("Scheduler returned success", mod_name=__name__)

        return result


def add_job(job_type, for_user, job_schedule, retry_count=0):
    """Add a job to the scheduler.

    @param job_type: BACKUP_JOB|RESTORE_JOB
    @param for_user: Remote user
    @param job_schedule: Instance of JobSchedule()

    @return: None on success

    @raise ValueError: Invalid input
    @raise RuntimeError: Other errors

    """

    if job_type not in [BACKUP_JOB, RESTORE_JOB]:
        raise ValueError("Invalid job_type : {}".format(str(job_type)))

    LoginData().load(for_user)

    if not isinstance(job_schedule, JobSchedule):
        raise ValueError("Invalid data for job_schedule")

    as_user = pwd.getpwuid(os.geteuid()).pw_name

    log.debug("Trying to add {} job to scheduler for '{}'"
              .format(job_type, for_user), mod_name=__name__)
    connection = _send_job_to_server((ADD_JOB, (job_type, for_user,
                                                as_user, job_schedule,
                                                retry_count)))

    return _reply_client(connection)


def remove_job(job_type, for_user):
    """Remove a job from the scheduler.

    @param job_type: BACKUP_JOB|RESTORE_JOB
    @param for_user: Remote User

    @return: None on success.

    @raise ValueError: For invalid input.
    @raise KeyError: If no jobs found.
    @raise RuntimeError: Other errors

    """

    if job_type not in [BACKUP_JOB, RESTORE_JOB]:
        raise ValueError("Invalid job_type : {}".format(str(job_type)))

    LoginData().load(for_user)

    as_user = pwd.getpwuid(os.geteuid()).pw_name

    log.debug("Trying to remove {} job from scheduler for '{}'"
              .format(job_type, for_user), mod_name=__name__)
    connection = _send_job_to_server((REMOVE_JOB, (job_type,
                                                   for_user, as_user)))

    return _reply_client(connection)


def get_jobs(for_user):
    """Get jobs from the scheduler.

    @param for_user: Remote user

    @return: List of tuples (job_type, JobSchedule). Empty list of no jobs
    found for user.

    @raise ValueError: Invalid input.
    @raise RuntimeError: Other errors.

    """

    LoginData().load(for_user)

    as_user = pwd.getpwuid(os.geteuid()).pw_name

    log.debug("Trying to get jobs from scheduler for '{}'"
              .format(for_user), mod_name=__name__)
    connection = _send_job_to_server((GET_JOBS, (for_user, as_user)))

    return _reply_client(connection)


def get_progress(job_type, for_user):
    """Get progress for a job from the scheduler.

    This function will wait for some time for data to become available.
    After some timeout, it will return empty list. Client can retry after
    CLIENT_RETRY_TIMEOUT and call get_progress again.

    @param job_type: BACKUP_JOB, RESTORE_JOB
    @param for_user: Remote user.

    @return: None if no job running for user.
    Empty list if job is running but no progress yet.
    List of UploadProgress, DownloadProgress objects.

    @raise RuntimeError: All errors.

    """

    if job_type not in [BACKUP_JOB, RESTORE_JOB]:
        raise ValueError("Invalid job_type : {}".format(str(job_type)))

    LoginData().load(for_user)

    as_user = pwd.getpwuid(os.geteuid()).pw_name

    log.debug("Trying to get progress for {} job from scheduler for '{}'"
              .format(job_type, for_user), mod_name=__name__)
    connection = _send_job_to_server((GET_PROGRESS,
                                      (job_type, for_user, as_user)))

    return _reply_client(connection)


def cancel_job(job_type, for_user):
    """Cancels a currently running job in scheduler.

    @raise RuntimeError: All errors.

    """

    if job_type not in [BACKUP_JOB, RESTORE_JOB]:
        raise ValueError("Invalid job_type : {}".format(str(job_type)))

    LoginData().load(for_user)

    as_user = pwd.getpwuid(os.geteuid()).pw_name

    log.debug("Trying to cancel {} job from scheduler for '{}'"
              .format(job_type, for_user), mod_name=__name__)
    connection = _send_job_to_server((CANCEL_JOB, (job_type,
                                                   for_user, as_user)))

    return _reply_client(connection)
