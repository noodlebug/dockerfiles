"""Scheduler package."""

NAME = 'Backup Scheduler Service'
DESC = ('The {} manages and schedules your backups to run on '
        'your system').format(NAME)

_AUTHKEY = 'ibl_authkey'
