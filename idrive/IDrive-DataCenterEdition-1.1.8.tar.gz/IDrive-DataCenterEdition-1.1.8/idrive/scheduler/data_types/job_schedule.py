"""Encapsulates a backup/restore job schedule."""

import datetime

from idrive.utils.validations import time_occurs_after


class JobSchedule(object):
    """Encapsulates a backup/restore job schedule.

    Clients should use this class to add a schedule
    to the main scheduler.
    """

    def __init__(self, days, start_time, cutoff_time=None):
        """Constructor

        @param days: 'days' should be list of int, from 0 to 6.
        Max length is 7. 0 means Monday and 6 means Sunday

        @param start_time: should be 'datetime.time' with hour, minute
        second setup.
        @param cutoff_time: should be 'datetime.time' with hour, minute
        second setup. Must be > start_time
        """

        if not isinstance(days, list):
            raise ValueError("'days' must be a list of int")

        if len(days) > 7:
            raise ValueError("'days' has too many weekdays")

        if days and not set(days).issubset(set(range(0, 7))):
            raise ValueError("'days' has invalid value")

        # Reduce duplicates
        days = list(set(days))
        days.sort()

        if not isinstance(start_time, datetime.time):
            raise ValueError("'start_time' is invalid")

        if cutoff_time is not None:
            if not isinstance(cutoff_time, datetime.time):
                raise ValueError("'cutoff_time' is invalid")

            timeout = self._get_timeout(start_time, cutoff_time)
        else:
            timeout = None

        self.days = days
        self.start_time = start_time
        self.cutoff_time = cutoff_time
        self.timeout = timeout

    def __eq__(self, other):
        """Equality of two job schedules."""

        for day in self.days:
            if day not in other.days:
                return False

        today = datetime.datetime.now().date()

        # compare start time up to seconds, we don't care about microseconds
        t1 = datetime.datetime.combine(today, self.start_time)
        t2 = datetime.datetime.combine(today, other.start_time)
        result = abs(t1 - t2).seconds == 0

        # now compare cutoff time
        result = result and (self.cutoff_time == other.cutoff_time)
        if result and self.cutoff_time is not None:
            t1 = datetime.datetime.combine(today, self.cutoff_time)
            t2 = datetime.datetime.combine(today, other.cutoff_time)
            result = abs(t1 - t2).seconds == 0

        return result

    def __ne__(self, other):
        return not self.__eq__(other)

    def _get_timeout(self, start_time, cutoff_time):
        '''get timeout of the job

        @raise ValueError: if cutoff time is before start time
        @return: total time (in seconds) before timeout occurs
        '''
        if not time_occurs_after(start_time, cutoff_time):
            raise ValueError('Invalid cutoff time')

        today = datetime.date.today()
        timeout = (datetime.datetime.combine(today, cutoff_time) -
                   datetime.datetime.combine(today, start_time))
        return int(timeout.total_seconds())

    def next_run_time(self):
        """Calculates the next run time."""

        now = datetime.datetime.now()
        weekday_today = now.weekday()

        # Will run today?
        if weekday_today in self.days:
            run_time = datetime.datetime.combine(now.date(), self.start_time)

            if run_time > now:
                return run_time

        # If not running today, then next run day is after today
        #  in this week, or first scheduled day of next week
        add_days = None
        for day in self.days:
            if day > weekday_today:
                add_days = day - weekday_today
                break
        else:
            add_days = min(self.days or [0]) + (7 - weekday_today)

        run_time = datetime.datetime.combine(now.date(), self.start_time) + \
            datetime.timedelta(add_days)

        return run_time

    def __str__(self):
        me = '{}(Days: {} | Start Time: {} | Cutoff Time: {} | Timeout: {})'
        cutoff = self.cutoff_time
        if cutoff:
            cutoff = cutoff.strftime('%X')
        return me.format(self.__class__.__name__, self.days,
                         self.start_time.strftime('%X'), cutoff, self.timeout)

    def __unicode__(self):
        return u'' + self.__str__()

    def __repr__(self):
        return self.__str__()
