'''ldb.scheduler.private.before_after_run.after_actions'''

import functools

from idrive.conf.settings import UserSettings
from idrive.core.evs.files.data_types import SYNC, FULL, INCREMENTAL
from idrive.core.evs.files.data_types.exceptions import UploadInvalidPathError, \
    DownloadInvalidPathError, UploadAccountUnderMaintenanceError, \
    DownloadAccountUnderMaintenanceError, UploadCommunicationError, \
    DownloadCommunicationError, UploadCancelledError, DownloadCancelledError
from idrive.utils import log
from idrive.scheduler.data_types.exceptions import NoBackupSetError, \
    NoRestoreSetError


def _cached(callable_):
    '''
    decorator method for easy accessing of class cached values, otherwise calls
    the method that will calculate them
    '''
    @functools.wraps(callable_)
    def wrapper(self, *args, **kwargs):
        name = '__' + callable_.__name__
        value = getattr(self, name, None)
        if value is not None:
            return value
        result = callable_(self, *args, **kwargs)
        setattr(self, name, result)
        return result

    return wrapper


class TransferAnalyzer(object):
    '''
    TransferAnalyzer class will check the results of a backup/restore and
    return information about it.

    @note: This class will only calculate items the first time they are
           requested. After that, it will return the cached results for faster
           access.
    '''

    def __init__(self, files, errors):
        '''
        @param files: list of files from the backup/restore
        @param errors: list of errors during the backup/restore
        '''
        self.files = files
        self.errors = errors

    @_cached
    def total_files(self):
        '''
        @return: the total number of files involved in this transfer
        '''
        return (self.files_in_sync() + self.files_full() +
                self.files_incremental() + self.file_errors())

    @_cached
    def files_transferred(self):
        '''
        @return: the total number of files actually transferred over the
            network (ie files not in sync)
        '''
        return self.files_full() + self.files_incremental()

    @_cached
    def files_in_sync(self):
        '''
        get a count of the number of files in sync
        '''
        return reduce(lambda x, y: x + 1 if is_in_sync(y) else x,
                      self.files, 0)

    @_cached
    def files_full(self):
        '''
        get a count of the number of files fully transferred
        '''
        return reduce(lambda x, y: x + 1 if is_full(y) else x, self.files, 0)

    @_cached
    def files_incremental(self):
        '''
        get a count of the number of files incrementally transferred
        '''
        return reduce(lambda x, y: x + 1 if is_incremental(y) else x,
                      self.files, 0)

    @_cached
    def file_errors(self):
        '''
        get a count of the number of files in error during a transfer
        '''
        return reduce(lambda x, y: x + 1 if is_file_error(y) else x,
                      self.errors, 0)

    @_cached
    def is_communication_error(self):
        '''
        check for errors relating network errors

        @return: True if there are any
        '''
        communication_error = (UploadCommunicationError,
                               DownloadCommunicationError)
        for e in self.errors:
            if isinstance(e, communication_error):
                return True
        return False

    @_cached
    def is_under_maintenance(self):
        '''
        check for errors relating to account being under maintenance

        @return: True if there are any
        '''
        maintenance_error = (UploadAccountUnderMaintenanceError,
                             DownloadAccountUnderMaintenanceError)

        for e in self.errors:
            if isinstance(e, maintenance_error):
                return True
        return False

    @_cached
    def has_no_transfer_set(self):
        '''
        check for errors relating to lack of set of files to transfer

        @return: True if there are any
        '''
        no_transfer_set_error = (NoBackupSetError, NoRestoreSetError)

        for e in self.errors:
            if isinstance(e, no_transfer_set_error):
                return True
        return False

    @_cached
    def is_cancelled(self):
        '''
        check for errors relating to cancellation

        @return: True if there are any
        '''
        cancelled_error = (UploadCancelledError, DownloadCancelledError)

        for e in self.errors:
            if isinstance(e, cancelled_error):
                return True
        return False

    @_cached
    def get_threshold(self):
        '''
        determine the allowed failure threshold number for a user

        @return: number of allowed file errors after which a transfer will be
                 considered failed
        '''
        try:
            threshold = UserSettings().APPLICATION.failure_threshold
        except (AttributeError, ValueError):
            threshold = '0'  # Convert to int later, must be str here

        # if in percent, convert to file count
        if threshold.endswith('pc'):
            try:
                threshold = int(threshold.rstrip('pc'))
                threshold = (self.total_files() * threshold) / 100
            except ValueError:
                threshold = 0
        else:
            try:
                threshold = int(threshold)
            except ValueError:
                threshold = 0

        return threshold

    @_cached
    def over_error_threshold(self):
        '''
        check if # of files errors is greater than user's defined threshold

        @return: True if # of file errors is >= threshold
        '''
        error_count = self.file_errors()

        if error_count < 1:
            return False

        return error_count > self.get_threshold()

    @_cached
    def unknown_errors(self):
        '''
        Check if some unknown error occurred during the transfer

        @return: True if any did
        '''
        return self.file_errors() == 0 and len(self.errors) > 0


def is_in_sync(file_):
    '''
    @return: True if the file was in sync for the transfer
    '''
    if hasattr(file_, 'transfer_type'):
        return file_.transfer_type == SYNC
    return False


def is_full(file_):
    '''
    @return: True if the file was fully transfered
    '''
    if hasattr(file_, 'transfer_type'):
        return file_.transfer_type == FULL
    return False


def is_incremental(file_):
    '''
    @return: True if the file was incrementally transfered
    '''
    if hasattr(file_, 'transfer_type'):
        return file_.transfer_type == INCREMENTAL
    return False


def is_file_error(error):
    '''
    @return: True if error is a file related error
    '''
    UIPE = UploadInvalidPathError
    DIPE = DownloadInvalidPathError
    return isinstance(error, (UIPE, DIPE))


def log_transfer_errors(errors):
    '''
    Log all errors in a transfer including path information if present
    '''
    for error in errors:
        try:
            message = u'{}'.format(error.path)
        except AttributeError:
            message = u'{}'.format(type(error).__name__)

        reason = unicode(error)
        if reason:
            message = u'{}: {}'.format(message, reason)

        log.error(message, mod_name=__name__)
