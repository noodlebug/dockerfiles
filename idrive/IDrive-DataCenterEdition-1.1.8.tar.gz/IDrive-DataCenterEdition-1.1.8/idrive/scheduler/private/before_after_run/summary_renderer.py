'''ldb.scheduler.private.before_after_run.summary_renderer'''

from idrive.scheduler.private.before_after_run.after_actions import is_full, \
    is_in_sync, is_incremental, is_file_error
from idrive.templating import Renderer


class SummaryRenderer(Renderer):

    STRFTIME_FULL = '%A %B %d, %Y at %I:%M:%S %p'
    STRFTIME_DAY = '%A %B %d, %Y'

    def add_filters(self):
        '''
        override to add additional filters
        '''
        super(SummaryRenderer, self).add_filters()
        self.add_filter(strftime_full=lambda x: x.strftime(self.STRFTIME_FULL))
        self.add_filter(strftime_day=lambda x: x.strftime(self.STRFTIME_DAY))

    def add_tests(self):
        '''
        override to add additional tests
        '''
        super(SummaryRenderer, self).add_tests()
        self.add_test(full=is_full)
        self.add_test(in_sync=is_in_sync)
        self.add_test(incremental=is_incremental)
        self.add_test(file_error=is_file_error)
