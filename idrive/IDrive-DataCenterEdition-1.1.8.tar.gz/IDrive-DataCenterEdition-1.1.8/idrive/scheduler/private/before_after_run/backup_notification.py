'''backup completion notification'''

import re
import urllib
import urllib2

from contextlib import closing

from idrive.conf.settings import UserSettings
from idrive.utils import log, network_proxy


# Note : This URL is same for both flavors
_NOTIFY_EMAIL_URL = 'https://webdav.ibackup.com/cgi-bin/Notify_email_ibl'


def send_notification_email(success, username, password, subject, content):
    '''
    Send user a notification email about their backup/restore based on their
    notification preferences

    @param success: {boolean} was transfer a success?
    @param username: {string} remote username
    @param password: {string} remote password
    @param subject: {string} email subject
    @param content: {string} email body content
    '''
    settings = UserSettings(username)

    # vars
    emails = settings.BACKUP.notify_emails
    notify_on_success = settings.BACKUP.notify_on_success == 'yes'
    notify_on_error = settings.BACKUP.notify_on_error == 'yes'

    # only send an email if user always wants to be notified or if the status
    # matches their "on success/error" criteria. otherwise we bail out.
    if not emails:
        return
    elif not notify_on_success and not notify_on_error:
        return
    elif not notify_on_success and success:
        return
    elif not notify_on_error and not success:
        return

    # proxy
    proxy = network_proxy.get_proxy()
    if proxy is not None:
        log.debug('Using proxy to send notification email', mod_name=__name__)
        proxy = urllib2.ProxyHandler(dict(http=proxy, https=proxy))
        opener = urllib2.build_opener(proxy)
        urllib2.install_opener(opener)

    emails = [str.strip(x) for x in re.split(',|;', emails) if x != '']
    for email in emails:
        data = urllib.urlencode(dict(to_email=email, subject=subject,
                                     content=content, username=username,
                                     password=password))

        try:
            with closing(urllib2.urlopen(_NOTIFY_EMAIL_URL, data=data)) as r:
                if r.getcode() != 200:
                    raise urllib2.URLError(r.read(1000))
        except urllib2.URLError as e:
            log.error('Error sending notification email to "{}": {}'
                      .format(email, str(e)), mod_name=__name__)
        else:
            log.info('Notification email sent to "{}"'.format(email),
                     mod_name=__name__)
