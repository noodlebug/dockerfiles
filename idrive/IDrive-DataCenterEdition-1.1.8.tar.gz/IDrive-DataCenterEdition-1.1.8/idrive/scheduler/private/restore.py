"""Runs restore for_user as_user."""

import idrive.scheduler.private.backup_restore as backup_restore


def run(for_user, as_user, timeout=None, can_retry=False, retry_count=0,
        relative=True):
    """Runs restore for_user, as_user.

    @param for_user: EVS user
    @param as_user: Local system user.
    @param timeout: In seconds, decides for how long backup should run.
    @param can_try: If restore fails, it can decide to retry

    """

    backup_restore.run(for_user=for_user, as_user=as_user, timeout=timeout,
                       can_retry=can_retry, retry_count=retry_count,
                       relative=relative, is_backup=False)


def get_progress(for_user, as_user):
    """Get restore progress information for a user.

    @return: UploadProgress - if progress info is available
    [] - if upload is in progress but progress info not available yet
    None - if no upload is going on.

    """

    return backup_restore.get_progress(for_user, as_user, is_backup=False)


def cancel_job(for_user, as_user):
    """Cancels an ongoing backup job."""

    return backup_restore.cancel_job(for_user, as_user, is_backup=False)
