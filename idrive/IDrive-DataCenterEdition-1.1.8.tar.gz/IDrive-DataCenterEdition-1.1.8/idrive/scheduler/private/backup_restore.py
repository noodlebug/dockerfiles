"""Common operations of backup/restore"""

import datetime
import multiprocessing
import os
import pwd
import Queue
import signal
import sys
import threading
import time

from collections import namedtuple

from idrive.conf.settings import GlobalSettings
from idrive.core.evs.files.data_types import UploadError, DownloadError
from idrive.core.evs.files.download import download
from idrive.core.evs.files.upload import upload
from idrive.scheduler.data_types import BackupRestoreJob
from idrive.scheduler.data_types.exceptions import NoBackupSetError, \
    NoRestoreSetError, TransferError
from idrive.scheduler.private.before_after_run.before_run import before_run
from idrive.scheduler.private.before_after_run.after_run import after_run
from idrive.utils import log, network_proxy, bunch

from . import _QUEUE_WAIT_TIME, CLIENT_RETRY_TIMEOUT  # @UnusedImport


_SUCCESS = 0
_ERROR = 1

_PROGRESS_DATA_QUEUES = {}
_QUEUE_SIZE = 50

_CHILD_PIDS = {}
_CANCEL_SIGNAL = signal.SIGUSR1

_Results = namedtuple('_Results', ('success', 'error'))


def _cancel_job(cancel_lambda):
    """Internal function to cancel ongoing backup/restore."""

    if cancel_lambda.call:
        log.info("Cancelling file transfer")
        cancel_lambda.call()


def _progress_callback(callback_data_list, progress_data_queue,
                       transfer_result, is_backup):
    """Internal function for upload/download callback."""

    if not callback_data_list:
        return

    # push progress/error info into queue so parent process can access it
    try:
        progress_data_queue.put_nowait(callback_data_list)
    except Queue.Full:
        log.debug("Progress queue got full", mod_name=__name__)

        try:
            progress_data_queue.get_nowait()
            log.debug("Removed oldest progress data", mod_name=__name__)
        except Queue.Empty:
            pass

        try:
            progress_data_queue.put_nowait(callback_data_list)
        except Queue.Full:
            log.error("Progress queue is full", mod_name=__name__)

    # Error data
    if isinstance(callback_data_list[0], Exception):
        transfer_result.error.extend(callback_data_list)

    # Progress data
    else:
        # store only completed progress in transfer_result
        transfer_result.success.extend(
            [x for x in callback_data_list if x.complete]
        )


def _run(is_backup, for_user, as_user, relative, timeout, can_retry,
         retry_count, progress_data_queue):
    '''
    Internal function which starts the actual backup/restore
    '''
    if GlobalSettings().LOGS.loglevel == 'DEBUG':
        try:
            os.dup2(log.get_handlers()[0].stream.fileno(), sys.stdout.fileno())
            os.dup2(log.get_handlers()[0].stream.fileno(), sys.stderr.fileno())
        except AttributeError:
            pass  # logging has not been initialized

    result = _SUCCESS
    results = _Results([], [])

    # lower privileges to given user/group of as_user
    try:
        pw_data = pwd.getpwnam(as_user)
        os.setgid(pw_data.pw_gid)
        os.setuid(pw_data.pw_uid)
    except (KeyError, OSError):
        error = ('Error starting file transfer. Cannot get privileges '
                 'of user "{}"'.format(as_user))

        log.error(error, mod_name=__name__)
        results.error.append(TransferError(error))
        result = _ERROR

    # setup environment
    try:
        proxy = network_proxy.get_proxy()
        if proxy is not None:
            log.debug(('Set proxy environmental variable $EVS_PROXY'),
                      mod_name=__name__)
            os.environ['EVS_PROXY'] = proxy
    except ValueError as e:
        error = 'Environment setup error: {}'.format(str(e))

        log.error(error, mod_name=__name__)
        results.error.append(TransferError(error))
        result = _ERROR

    job_type = 'backup' if is_backup else 'restore'
    op_start_time = datetime.datetime.now()

    # Load backup set information
    log.info("Starting {} for '{}'".format(job_type, for_user))
    if result == _SUCCESS:
        try:
            log.debug("Creating {} job".format(job_type))

            backup_restore_job = BackupRestoreJob(
                username=for_user,
                job_type=(BackupRestoreJob.BACKUP if is_backup else
                          BackupRestoreJob.RESTORE)
            )
        except ValueError as e:
            error = 'Error in creating the {} job'.format(job_type)

            log.error(error, mod_name=__name__)
            log.debug(str(e), mod_name=__name__)
            results.error.append(TransferError(error))
            result = _ERROR

    if result == _SUCCESS:
        username, password, pvtkey = backup_restore_job.login_data.get()
        file_list, path = backup_restore_job.backup_restore_set.get()

        operation_settings = before_run(is_backup)

        if file_list:
            log.info('Starting file transfer')

            # create a signal handler to receive cancel signal from scheduler
            # note: don't use a namedtuple here, they are immutable
            cancel_lambda = bunch.Bunch({'call': False})
            signal.signal(_CANCEL_SIGNAL,
                          lambda signum, frame: _cancel_job(cancel_lambda))

            # The callback lambda would create a closure with
            # progress_data_queue, results and is_backup
            operation = upload if is_backup else download
            try:
                operation(username, password, path, file_list,
                          pvtkey=pvtkey, relative=relative,
                          cancel_lambda=cancel_lambda,
                          callback=lambda progress:
                              _progress_callback(progress, progress_data_queue,
                                                 results, is_backup),
                          **operation_settings)

            except (UploadError, DownloadError) as e:
                log.error("Error transferring files for '{}' : {}"
                          .format(username, str(e)))
                results.error.append(e)
                try:
                    # Append as a list, otherwise interface will think
                    #  its an exception
                    progress_data_queue.put_nowait([e])
                except Queue.Full:
                    log.error("Progress queue is full", mod_name=__name__)
                result = _ERROR
            finally:
                log.info("{} completed".format(job_type.capitalize()))

        else:
            if is_backup:
                no_set_error = NoBackupSetError()
            else:
                no_set_error = NoRestoreSetError()

            log.error(str(no_set_error), mod_name=__name__)
            results.error.append(no_set_error)
            result = _ERROR

    # Both close() and cancle_join_thread() are important
    # Otherwise this process will wait for the queue on the
    # parent process to clear so that it can flush
    # the pending data into the queue. close() indicates
    # to receiver side that no more data is coming.
    # cancel_join_thread ensure that this process is not waiting for the
    # queue writer thread to finish flushing data into queue
    progress_data_queue.close()
    progress_data_queue.cancel_join_thread()

    op_end_time = datetime.datetime.now()

    # take care of post backup/restore tasks
    after_run(is_backup, backup_restore_job, results.success, results.error,
              op_start_time, op_end_time, timeout, can_retry, retry_count)

    return result


def run(for_user, as_user, timeout=None, can_retry=False, retry_count=0,
        relative=True, is_backup=True):
    """Runs backup/restore for remote user as local user

    @param for_user: EVS user
    @param as_user: Local user
    @param timeout: timeout is seconds for operation to finish
    @param can_retry: Can retry operation if it fails
    @param relative: backup/restore should be relative?
    @param is_backup: True if operation is backup, False otherwise
    """

    job_type = "backup" if is_backup else "restore"

    log.info("Starting {} for '{}' as '{}'"
             .format(job_type, for_user, as_user))

    # Create a queue to communicate with the child process
    #  This queue will hold progress information which
    #  can be used by get_progress()
    global _PROGRESS_DATA_QUEUES

    key = "{}{}_{}".format(for_user, as_user, job_type)
    if key in _PROGRESS_DATA_QUEUES:
        log.error("{} already running for '{}' as '{}'"
                  .format(job_type.capitalize(), for_user, as_user))
        return

    _PROGRESS_DATA_QUEUES[key] = multiprocessing.Queue(_QUEUE_SIZE)

    backup_restore_process = multiprocessing.Process(
        target=_run,
        args=(is_backup, for_user, as_user, relative, timeout, can_retry,
              retry_count, _PROGRESS_DATA_QUEUES[key])
    )

    # Store the child pid for cancel_job to use later
    backup_restore_process.start()
    _CHILD_PIDS[key] = backup_restore_process.pid

    # If timeout is set, cancel backup/restore after timeout
    timer = None
    if timeout is not None:
        log.info("Setting timeout for {} to {} seconds".format(job_type,
                                                               timeout))
        timer = threading.Timer(
            timeout, cancel_job, args=(for_user, as_user, is_backup)
        )
        timer.start()

    backup_restore_process.join()
    del _CHILD_PIDS[key]

    if timer is not None:
        timer.cancel()

    if backup_restore_process.exitcode != _SUCCESS:
        log.error("Error running {} for '{}' as '{}'"
                  .format(job_type, for_user, as_user))
    else:
        log.info("{} completed for '{}' as '{}'"
                 .format(job_type.capitalize(), for_user, as_user))

    # Wait for some time for any clients querying progress data
    # to get the last bit before we remove the progress data queue
    time.sleep(_QUEUE_WAIT_TIME * 10)

    _PROGRESS_DATA_QUEUES[key].close()
    _PROGRESS_DATA_QUEUES[key].cancel_join_thread()
    del _PROGRESS_DATA_QUEUES[key]


def get_progress(for_user, as_user, is_backup):
    """Get backup/restore progress information for a user.

    @return: UploadProgress/DownloadProgress if progress info is available
    [] if upload/download is in progress but progress info not
    available yet.
    None if no upload/download is going on.
    """

    global _PROGRESS_DATA_QUEUES

    job_type = 'backup' if is_backup else 'restore'

    log.debug("get_progress for {}".format(job_type), mod_name=__name__)

    return_data = None
    key = "{}{}_{}".format(for_user, as_user, job_type)
    if key in _PROGRESS_DATA_QUEUES:
        try:
            upload_progress = _PROGRESS_DATA_QUEUES[key].get(True,
                                                             _QUEUE_WAIT_TIME)
        except Queue.Empty:
            log.debug("Empty progress", mod_name=__name__)
            return_data = []
        except Exception as e:
            log.error("Exception in get_progress " + str(e), mod_name=__name__)
        else:
            return_data = upload_progress
    else:
        log.debug("No progress in queue", mod_name=__name__)

    return return_data


def cancel_job(for_user, as_user, is_backup):
    """Cancels an ongoing backup/restore job.

    @return: True if job was successfully interrupted. False otherwise.
    """

    job_type = 'backup' if is_backup else 'restore'

    log.info("Cancelling {}".format(job_type), mod_name=__name__)

    return_data = False
    key = "{}{}_{}".format(for_user, as_user, job_type)
    if key in _CHILD_PIDS:
        os.kill(_CHILD_PIDS[key], _CANCEL_SIGNAL)
        return_data = True

    else:
        log.debug("No child pid found", mod_name=__name__)

    return return_data
