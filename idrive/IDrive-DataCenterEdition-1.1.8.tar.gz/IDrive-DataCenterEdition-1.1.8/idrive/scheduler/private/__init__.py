"""Private modules of scheduler package."""

# Used by server_callbacks
ADD_JOB = 10
REMOVE_JOB = 20
GET_JOBS = 30
GET_PROGRESS = 40
CANCEL_JOB = 50

# Used by apscheduler
BACKUP_JOB = 'BACKUP_JOB'
RESTORE_JOB = 'RESTORE_JOB'

# Used by backup_restore
_QUEUE_WAIT_TIME = 0.5
CLIENT_RETRY_TIMEOUT = _QUEUE_WAIT_TIME / 2
