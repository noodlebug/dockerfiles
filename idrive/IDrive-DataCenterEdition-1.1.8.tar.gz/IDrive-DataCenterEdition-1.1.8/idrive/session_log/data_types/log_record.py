"""Encapsulates a single session log record"""

import datetime

from os import path
from xml.etree import ElementTree as ET
from xml.etree.ElementTree import Element

from idrive.conf.settings import GlobalSettings

_RECORD_XML_TEMPLATE_FILENAME = 'record.xml'

_TIME_FORMAT_1 = "%Y-%m-%d %H:%M:%S"  # For DateTime
_TIME_FORMAT_2 = "%m/%d/%Y %H:%M:%S"  # For content part
_TIME_FORMAT_3 = "%m%d%Y%H%M%S"  # For filename


class LogRecord(object):
    """Container for LogRecord objects"""

    OP_NONE = None
    OP_BACKUP = u'backup'
    OP_RESTORE = u'restore'
    OP_DELETE = u'delete'
    OP_PUTBACK = u'move to original'
    OP_RENAME = u'rename'

    _CANCELLED_TEXT = 'Cancelled'

    _op_status = {
        "": None,
        "Success": True,
        "Failure": False,
        _CANCELLED_TEXT: False
    }

    _op_status_r = {
        True: 'Success',
        False: 'Failure'
    }

    _op_mappings = {
        '': OP_NONE,
        OP_BACKUP: OP_BACKUP,
        OP_RESTORE: OP_RESTORE,
        OP_DELETE: OP_DELETE,
        OP_PUTBACK: OP_PUTBACK,
        OP_RENAME: OP_RENAME
    }

    _content_templt = ('Ref : Username - {user}!!!Computer Name : '
                       '{comp}!!!{succ}!!!{op} Start Time : {st_time}!!!'
                       '{op} End Time : {end_time}')

    def __init__(self, xml=None):
        """Constructor"""

        self._operation = self.OP_NONE
        self._op_successful = None
        self._op_cancelled = None
        self._username = None
        self._computer_name = None
        self._op_start_time = None
        self._op_end_time = None
        self._op_details_id = None

        if xml is None:
            record_xml_template_file = GlobalSettings().APPLICATION.path + \
                path.sep + 'session_log' + path.sep + 'data_types' \
                + path.sep + _RECORD_XML_TEMPLATE_FILENAME

            record_template = ET.parse(record_xml_template_file)
            xml = record_template.getroot()

        elif not isinstance(xml, Element):
            raise ValueError("Invalid input '{}'".format(xml))

        # Following are directly available from xml
        self._operation = self._op_mappings[xml.findtext('optype', '').lower()]
        self._op_successful = self._op_status[xml.findtext('status', '')]
        self._op_cancelled = (xml.findtext('status', '') ==
                              self._CANCELLED_TEXT)
        self._username = unicode(xml.findtext('uname'))
        self._op_end_time = xml.findtext('DateTime')
        if self._op_end_time is not None:
            self._op_end_time = datetime.datetime.strptime(self._op_end_time,
                                                           _TIME_FORMAT_1)
        self._op_details_id = xml.findtext('lpath').split('.')[0]

        # Following needs to be harvested from 'content'
        self._computer_name = None
        self._op_start_time = None

        content = unicode(xml.findtext('content'))
        if content is not None:
            content_parts = content.split('!!!')

            self._computer_name = unicode(content_parts[1]
                                          .split(':', 1)[1].strip())

            self._op_start_time = content_parts[3].split(':', 1)[1].strip()
            self._op_start_time = \
                datetime.datetime.strptime(self._op_start_time,
                                           _TIME_FORMAT_2)

        if None in self.__dict__.values():
            raise ValueError("Invalid XML {}".format(ET.tostring(xml)))

        self.xml = xml

    def _update_xml(self):
        """Updates the xml."""

        xml = self.xml
        st_time = self._op_start_time.strftime(_TIME_FORMAT_2)
        xml.find('DateTime').text = self._op_end_time.strftime(_TIME_FORMAT_1)
        end_time = self._op_end_time.strftime(_TIME_FORMAT_2)
        xml.find('uname').text = self._username
        if self._op_cancelled:
            xml.find('status').text = status = self._CANCELLED_TEXT
        else:
            xml.find('status').text = status = \
                self._op_status_r[self._op_successful]
        xml.find('optype').text = op_type = \
            self._op_mappings[self._operation].capitalize()
        xml.find('lpath').text = self._op_end_time.strftime(_TIME_FORMAT_3) + \
            ".txt"
        xml.find('content').text = \
            self._content_templt.format(user=self._username,
                                        comp=self._computer_name,
                                        succ=status, op=op_type,
                                        st_time=st_time, end_time=end_time)

    def _set(self, key, value):
        """Set value for key. Automatically updates xml"""

        if not hasattr(self, key):
            raise ValueError("Invalid key '{}'".format(key))

        # coerce str to unicode
        if isinstance(value, str):
            value = unicode(value)

        if not isinstance(value, getattr(self, key).__class__):
            raise ValueError(('Invalid value "{}" for key "{}". Should be {} '
                              'provided '
                              '{}').format(value, key,
                                           getattr(self, key).__class__,
                                           type(value)))

        setattr(self, key, value)
        self._update_xml()
        self._op_details_id = self.xml.findtext('lpath').split('.')[0]

    @property
    def operation(self):
        return self._operation

    @operation.setter
    def operation(self, value):
        self._set('_operation', value)

    @property
    def op_successful(self):
        return self._op_successful

    @op_successful.setter
    def op_successful(self, value):
        self._set('_op_successful', value)

    @property
    def op_cancelled(self):
        return self._op_cancelled

    @op_cancelled.setter
    def op_cancelled(self, value):
        self._set('_op_cancelled', value)

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        self._set('_username', value)

    @property
    def computer_name(self):
        return self._computer_name

    @computer_name.setter
    def computer_name(self, value):
        self._set('_computer_name', value)

    @property
    def op_start_time(self):
        return self._op_start_time

    @op_start_time.setter
    def op_start_time(self, value):
        self._set('_op_start_time', value)

    @property
    def op_end_time(self):
        return self._op_end_time

    @op_end_time.setter
    def op_end_time(self, value):
        self._set('_op_end_time', value)

    @property
    def op_details_id(self):
        return self._op_details_id

    def __str__(self):
        """String representation of underlying xml."""

        return ET.tostring(self.xml)

    def __hash__(self):
        """Object id."""

        return int(self._op_details_id)

    def __eq__(self, other):
        """Comparison."""

        return self._op_details_id == other._op_details_id
