"""Data types."""

from idrive.session_log.data_types.log_record import LogRecord
from idrive.session_log.data_types.log_records import LogRecords
