"""Interface to session logs"""

import codecs
import os
import datetime

from idrive.conf.settings import UserSettings
from idrive.session_log.data_types import LogRecord, LogRecords
from idrive.session_log.private.upload_logs import upload_logs

_RECORDS_XML_FILENAME = '%m-%d-%Y.xml'
_RECORDS_BACKUP_FILENAME = '%m-%d-%Y_%m%d%Y%H%M%S.xml'
_RECORD_DETAILS_FILENAME = '{id}.txt'


def _get_logs_dir(username):
    '''
    Return the path of the logs directory for a given remote username
    '''
    return os.path.join(UserSettings(username).REMOTE.path, 'session_logs')


def _get_details_dir(username):
    '''
    Return the path of the log details directory for a given remote username
    '''
    return os.path.join(_get_logs_dir(username), 'log')


def add_log_record(record):
    '''Add a new log record.'''

    if not isinstance(record, LogRecord):
        raise ValueError('Invalid parameter')

    logs_dir = _get_logs_dir(record.username)
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir, mode=0700)

    records_xml_file = \
        os.path.join(logs_dir,
                     record.op_end_time.strftime(_RECORDS_XML_FILENAME))

    if os.path.exists(records_xml_file):
        with codecs.open(records_xml_file, 'r', 'utf-8') as f:
            log_records = LogRecords(f.read())
    else:
        log_records = LogRecords()

    log_records.add_record(record)

    with codecs.open(records_xml_file, 'w', 'utf-8') as f:
        f.write(u'<records>' + unicode(log_records).strip().replace('\n', '') +
                '</records>')


def get_log_records(username, since=None):
    '''Returns a list of LogRecords objects, optionally since datetime.date

    LogRecords is a container for LogRecord objects. There is one LogRecords
    object for each day. This function returns LogRecords for multiple days.
    '''
    if since is not None:
        if (not isinstance(since, datetime.date) or
                datetime.date.today() - since < datetime.timedelta(0)):
            raise ValueError('Invalid "since" value')
    else:
        since = datetime.date(1, 1, 1)

    log_records_arr = []
    logs_dir = _get_logs_dir(username)

    if os.path.exists(logs_dir):
        for filename in os.listdir(logs_dir):
            if not filename.endswith('.xml'):
                continue

            try:
                file_date = \
                    datetime.datetime.strptime(filename,
                                               _RECORDS_XML_FILENAME).date()
            except ValueError:
                continue

            if file_date - since > datetime.timedelta(0):
                filename = os.path.join(logs_dir, filename)
                with codecs.open(filename, 'r', 'utf-8') as f:
                    log_records_arr.append(LogRecords(f.read()))

    return log_records_arr


def add_log_details(record, details, upload=True):
    '''Add log record details.'''

    if not isinstance(record, LogRecord):
        raise ValueError('Invalid params')

    logs_dir = _get_logs_dir(record.username)
    details_dir = _get_details_dir(record.username)

    if not os.path.exists(details_dir):
        os.makedirs(details_dir, mode=0700)

    filename = _RECORD_DETAILS_FILENAME.format(id=record.op_details_id)
    filename = os.path.join(details_dir, filename)
    with codecs.open(filename, 'a', 'utf-8') as f:
        f.write(details)

    if upload:
        upload_logs(record.username, record.computer_name, logs_dir)


def get_log_details(record):
    '''Get details of a log record if any.'''

    if not isinstance(record, LogRecord):
        raise ValueError('Invalid params')

    details_dir = _get_details_dir(record.username)

    filename = _RECORD_DETAILS_FILENAME.format(id=record.op_details_id)
    filename = os.path.join(details_dir, filename)

    if not os.path.exists(filename):
        return u''

    with codecs.open(filename, 'r', 'utf-8') as f:
        return f.read()


def delete_record(record):
    '''Deletes a record from local system. '''

    logs_dir = _get_logs_dir(record.username)
    details_dir = _get_details_dir(record.username)

    if not os.path.exists(logs_dir):
        raise KeyError('No log records exist')

    for filename in os.listdir(logs_dir):
        if not filename.endswith('.xml'):
            continue

        try:
            file_date = \
                datetime.datetime.strptime(filename,
                                           _RECORDS_XML_FILENAME).date()
        except ValueError:
            continue

        if file_date == record.op_end_time.date():
            filename = os.path.join(logs_dir, filename)
            # File containing log record found
            with codecs.open(filename, 'r', 'utf-8') as f:
                log_records = LogRecords(f.read())

            # delete the log record
            log_records.remove_record(record)

            with codecs.open(filename, 'w', 'utf-8') as f:
                f.write(u'<records>' + unicode(log_records) + '</records>')

            # delete record details file
            log_details_file = \
                _RECORD_DETAILS_FILENAME.format(id=record.op_details_id)
            log_details_file = os.path.join(details_dir, log_details_file)
            if os.path.exists(log_details_file):
                os.unlink(log_details_file)

            # write the deleted record to a backup file and upload it
            backup_filename = \
                record.op_end_time.strftime(_RECORDS_BACKUP_FILENAME)
            backup_file = os.path.join(logs_dir, backup_filename)

            log_records = LogRecords()
            log_records.add_record(record)
            with codecs.open(backup_file, 'w', 'utf-8') as f:
                f.write(u'<records>' + unicode(log_records) + '</records>')

            # remove the backup file from local system after upload
            upload_logs(record.username, record.computer_name,
                        logs_dir,
                        callback=lambda: os.unlink(backup_file))

            break
    else:
        raise KeyError('Log record not found')
