"""Uploads the session logs to the user's account"""

import os

from idrive.common.data_types import LoginData
from idrive.core.evs.account import get_server_address, \
    ServerAddressError, server_address
from idrive.core.evs.idevsutil import execute_command, UPLOAD_LOG
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSInvalidServerError
from idrive.utils import log

_REMOTE_LOG_PATH = '/backup_restore_logs_do_not_delete/{}/'


def upload_logs(for_user, computer_name, log_path, callback=None):
    """Upload the session logs to user's account."""

    # fork() out a child to upload logs
    #  parent doesn't wait for child to upload logs
    if os.fork():
        log.debug("Forked out child to upload logs", mod_name=__name__)
        return

    # child uploads logs and exits
    try:
        login_data = LoginData().load(for_user)
    except KeyError:
        log.error("Could not backup logs for {}".format(for_user),
                  mod_name=__name__)
        return

    file_list = map(lambda x: os.path.abspath(log_path + os.path.sep + x),
                    os.listdir(log_path))

    username, password, pvtkey = login_data.get()

    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password,
                                                cached=cached)
        except ServerAddressError as err:
            log.error("Error in getting server address : {}"
                      .format(str(err)), mod_name=__name__)
            return

        try:
            remote_path = _REMOTE_LOG_PATH.format(computer_name)
            _, err_xml = \
                execute_command(UPLOAD_LOG, username, password,
                                pvtkey=pvtkey,
                                server_address=server_address.CLU_SERVER_IP,
                                remote_path=remote_path,
                                file_list=file_list)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSInvalidServerError as e:
            if cached:
                continue
            else:
                raise EVSError(str(e))

        except EVSError as err:
            log.error("Error uploading logs : {}".format(str(err)),
                      mod_name=__name__)
            break
        else:
            log.debug("Session logs uploaded successfully", mod_name=__name__)

            if callback is not None:
                log.debug("Doing callback after uploading logs",
                          mod_name=__name__)
                callback()
            break

    os._exit(0)
