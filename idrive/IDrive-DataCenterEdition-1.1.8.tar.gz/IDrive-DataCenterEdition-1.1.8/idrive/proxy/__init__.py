"""Proxy package."""

NAME = 'Command Proxy Service'
DESC = ('The {} executes commands & requests from the web as local users on '
        'the system').format(NAME)
