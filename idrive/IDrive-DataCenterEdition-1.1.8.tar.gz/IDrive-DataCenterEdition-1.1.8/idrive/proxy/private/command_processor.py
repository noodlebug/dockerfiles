"""Command processor"""

import os
import sys
import pwd
import json
import pam

import idrive.utils.log as log
from idrive.conf.settings import GlobalSettings
from idrive.utils.import_module import import_module
from idrive.utils import network_proxy


_MAPPINGS_FILE = GlobalSettings().APPLICATION.path + \
    '/proxy/private/command_mappings.json'

with open(_MAPPINGS_FILE) as f:
    _proxy_command_mappings = json.load(f)


def _send_to_parent(data, conn_send):
    """Internal function to send data to parent."""

    try:
        conn_send.send(data)
        conn_send.close()
    except ValueError:
        log.error("conn_send got full", mod_name=__name__)
        return False
    else:
        log.debug("data sent to parent", mod_name=__name__)
        return True


def _list_of_exceptions(str_exception_list):
    """Returns a list of exception classes from the string representation
    of the exception.

    """

    exception_list = []
    for str_except in str_exception_list:
        module_to_load, _, exception_class_name = str_except.rpartition('.')

        try:
            exception_list.append(getattr(sys.modules['exceptions'],
                                          str_except))
        except AttributeError:
            loaded_module = import_module(module_to_load)

            exception_class = getattr(loaded_module,
                                      exception_class_name,
                                      False)

            if exception_class:
                exception_list.append(exception_class)

    return exception_list


def process_command(username, password, command, args, conn_send):
    """Processes a command as username.

    This method will first validate credentials, lower privileges to
    the passed username and then execute the command with args.
    All results are passed via the conn_send end of the Pipe() created by the
    parent.
    """

    if not pam.authenticate(username, password, service='login'):
        log.debug("Authentication failed for {}".format(username),
                  mod_name=__name__)
        _send_to_parent(ValueError("Authentication failed"), conn_send)
        return

    # lower privileges to given user/group
    try:
        pw_data = pwd.getpwnam(username)
        os.setgid(pw_data.pw_gid)
        os.setuid(pw_data.pw_uid)
    except (KeyError, OSError):
        log.error("Cannot get privileges of user '{}'".format(username),
                  mod_name=__name__)
        _send_to_parent(ValueError("Failed to get privileges"), conn_send)
        return

    # setup environment
    try:
        proxy = network_proxy.get_proxy()
        if proxy is not None:
            log.debug(('Set proxy environmental variable $EVS_PROXY'),
                      mod_name=__name__)
            os.environ['EVS_PROXY'] = proxy
    except ValueError as e:
        log.error('Environment setup error: {}'.format(str(e)))
        _send_to_parent(e, conn_send)
        return

    log.debug("Processing {}".format(command), mod_name=__name__)

    try:
        if command not in _proxy_command_mappings:
            msg = "Invalid command {}".format(command)
            log.error(msg)
            raise ValueError(msg)

        mapped_target = _proxy_command_mappings[command]['target']

        log.debug("Mapped target {}".format(mapped_target),
                  mod_name=__name__)

        module_to_load, _, target_name = mapped_target.rpartition('.')
        loaded_module = import_module(module_to_load)

        target = getattr(loaded_module, target_name, False)

        if not target:
            raise ImportError("{} not present in {}"
                              .format(target_name, module_to_load))

        if _proxy_command_mappings[command]['type'] == 'function':
            if 'params' not in args:
                raise ValueError("'params' not passed")

            return_data = target(*args['params'])
        else:
            if 'init_params' not in args:
                raise ValueError("'init_params' not passed")

            obj = target(*args['init_params'])

            if 'method' in args:
                if 'params' not in args:
                    raise ValueError("'params' not passed")

                return_data = getattr(obj, args['method'])(*args['params'])
            else:
                return_data = obj

    except Exception as err:
        log.error("Exception: {}".format(str(err)), traceback=True,
                  mod_name=__name__)

        exception_list = []
        if (command in _proxy_command_mappings and
                'exceptions' in _proxy_command_mappings[command]):
            str_exceptions = _proxy_command_mappings[command]['exceptions']
            try:
                exception_list = _list_of_exceptions(str_exceptions)
            except ImportError as imp_err:
                err = imp_err

        exception_list.extend([ValueError, ImportError])

        return_data = err

    log.debug("sending {} to parent".format("data"), mod_name=__name__)

    _send_to_parent(return_data, conn_send)
