'''Product flavors package'''

import errno
import os
import subprocess

from ConfigParser import SafeConfigParser

# flavor names
DEFAULTS = 'defaults.ini'
CURRENT = 'CURRENT.ini'
IDRIVE = 'idrive.ini'
IBACKUP = 'ibackup.ini'

_FLAVORS_DIR = os.path.dirname(os.path.abspath(__file__))
_CURRENT_PATH = os.path.join(_FLAVORS_DIR, CURRENT)


def config_paths():
    '''The paths of the flavor config files
    @return: List of paths
    '''
    _check_current_exists()
    return [os.path.join(_FLAVORS_DIR, DEFAULTS), _CURRENT_PATH]


def get_config():
    '''Get the flavor config parser

    @return: ConfigParser
    '''
    config = SafeConfigParser()
    config.read(config_paths())

    return config


def current(simple=True):
    '''Name of current flavor
    @param simple: if false, will return the full file name

    @return: Flavor name
    '''
    _check_current_exists()
    config = SafeConfigParser()
    config.read(config_paths())

    name = config.get('DEFAULT', 'short_name')

    if not simple:
        name += '.ini'

    return name


def is_(name):
    '''Check if the current flavor is active

    @return: True if name == current flavor
    '''
    return current(False) == name


def choices(simple=True):
    '''List of flavor choices'''
    if simple:
        return [IDRIVE[:-4], IBACKUP[:-4]]
    else:
        return [IDRIVE, IBACKUP]


def switch_to(name):
    '''Switches the current flavor'''

    if not name.endswith('.ini'):
        name += '.ini'

    if name not in choices(simple=False):
        raise ValueError('Invalid flavor')

    _remove_current()
    subprocess.check_call(['ln', name, CURRENT], cwd=_FLAVORS_DIR)


def _check_current_exists():
    if not os.path.exists(_CURRENT_PATH):
        raise ValueError(('Current flavor not found. Make sure the file "{}" '
                          'exists in "{}" and that it is hard linked to one '
                          'of the existing flavor configuration '
                          'files.').format(CURRENT, _FLAVORS_DIR))


def _remove_current():
    '''Removes the current flavor'''
    try:
        os.unlink(_CURRENT_PATH)

    # use old style catch here as file can be executed by python < 2.5
    except OSError, e:
        if e.errno != errno.ENOENT:
            raise
