'''ldb.utils.network_proxy'''

import re

from idrive.conf.settings import UserSettings


def get_proxy():
    '''
    Returns a formatted proxy string suitable to be used when making requests
    through a proxy

    @return: formatted string or None if proxy is disabled
    '''
    settings = UserSettings()

    if settings.NETWORKPROXY.proxy != 'manual':
        return None

    scheme = ''
    host = settings.NETWORKPROXY.host
    port = settings.NETWORKPROXY.port
    credentials = ''
    username = settings.NETWORKPROXY.username
    password = settings.NETWORKPROXY.password

    if re.match('^(https?|ftp)://', host, re.IGNORECASE):
        scheme, host = host.split('://', 1)
        scheme += '://'

    if username:
        credentials = username
        if password:
            credentials += ':' + password
        credentials += '@'

    return '{}{}{}:{}'.format(scheme, credentials, host, port)
