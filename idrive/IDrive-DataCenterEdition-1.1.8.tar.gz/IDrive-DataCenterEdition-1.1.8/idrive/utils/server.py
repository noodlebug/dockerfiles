"""Server interface."""

import socket
from multiprocessing.connection import Listener, AuthenticationError
from threading import Thread

from idrive.utils import log

_listener = None


class ServerError(Exception):
    """Server errors."""
    pass


def _do_callback(connection, callback):
    """Makes the callback and closes connection."""

    data = connection.recv()
    log.debug("Server received data", mod_name=__name__)

    try:
        return_data = callback(data)
    except Exception as err:
        return_data = err
        log.debug("Error calling '{}' : {}".format(callback.func_name,
                                                   str(err)),
                  mod_name=__name__)
    else:
        log.debug("Server called '{}'".format(callback.func_name),
                  mod_name=__name__)

    log.debug("Sending data returned by '{}' to client"
              .format(callback.func_name), mod_name=__name__)
    connection.send(return_data)

    connection.close()


def _start_listening(address, callback, authkey=None):
    """Internal function which starts the server."""

    if not callable(callback):
        raise ServerError("'callback' must be callable")

    global _listener
    while True:
        try:
            connection = _listener.accept()
            log.debug("New connection at server", mod_name=__name__)
        except AuthenticationError as err:
            log.error("Authentication error at server : {}".format(err),
                      mod_name=__name__)
            continue
        except socket.error as err:
            raise ServerError(err)
        except KeyboardInterrupt:
            # SIGINT will cause this
            _listener.close()
            return

        thread = Thread(target=_do_callback, args=(connection, callback))
        thread.daemon = True
        thread.start()


def start(address, callback, authkey=None, embedded=False):
    """Starts a server on address.

    callback is called when anyone connects and sends data over.

    embedded=True means start() will create a thread and
    return immediately.

    """

    global _listener

    if _listener is not None:
        raise ServerError("One server is already running")

    try:
        log.debug("Starting server at {}:{}".format(address[0], address[1]),
                  mod_name=__name__)
        _listener = Listener(address=address, authkey=authkey)
    except (socket.gaierror, socket.error) as err:
        raise ServerError(err)

    if embedded:
        log.debug("Starting the listener thread", mod_name=__name__)
        main_thread = Thread(target=_start_listening,
                             args=(address, callback, authkey))
        main_thread.daemon = True
        main_thread.start()
    else:
        _start_listening(address, callback, authkey)


def stop():
    """Stop the server."""

    global _listener
    if _listener is not None:
        log.debug("Stopping the server", mod_name=__name__)
        _listener.close()
        _listener = None
