'''
Pluralize
'''

IRREGULAR_PLURALS = {
    'person': 'people'
}


def pluralize(word, num=None):
    """ Will return the pluralized version of a word based on language rules"""
    num = int(num)

    if num is None or num != 1:
        if word in IRREGULAR_PLURALS:
            return IRREGULAR_PLURALS[word]
        elif word.endswith('y'):
            return word[:-1] + 'ies'
        elif word[-1] in 'sx' or word[-2:] in ['sh', 'ch']:
            return word + 'es'
        elif word.endswith('an'):
            return word[:-2] + 'en'
        else:
            return word + 's'

    return word

if __name__ == '__main__':
    import sys

    from idrive.utils.command_line import process_command_line

    required_args = {'word', 'num'}
    kwargs = process_command_line(required_args)

    print pluralize(**kwargs)

    sys.exit(0)
