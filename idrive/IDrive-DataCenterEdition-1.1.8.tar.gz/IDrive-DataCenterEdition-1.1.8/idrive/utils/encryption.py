'''
Utility module to encrypt/decrypt data
'''

from Crypto.Cipher import AES
from base64 import b64encode, b64decode
from hashlib import sha256
from os import urandom

DEFAULT_KEY = "x92jYs#80MCPG*2k2^!lksjdfaisoienc.owyacgkeolsl.91doq-uje-fhd320\
93yqoi"


class EncryptError(Exception):
    pass


def encrypt_data(data, key=DEFAULT_KEY):
    '''Method to encrypt data using AES 256 encryption
       If key is not passed, we use DEFAULT KEY'''
    try:
        padded_key = sha256(key).digest()
        iv = urandom(AES.block_size)
        cipher = AES.new(padded_key, AES.MODE_CFB, iv)
        encrypted_data = b64encode(iv + cipher.encrypt(data))
        return encrypted_data
    except Exception as e:
        raise EncryptError(e)


def decrypt_data(encrypted_data, key=DEFAULT_KEY):
    '''Method to de-crypt data using AES 256 encryption
       If key is not passed, we use DEFAULT KEY'''
    try:
        padded_key = sha256(key).digest()
        encrypted_data = b64decode(encrypted_data)
        encrypted_msg = encrypted_data[AES.block_size:]
        iv = encrypted_data[:AES.block_size]
        cipher = AES.new(padded_key, AES.MODE_CFB, iv)
        decrypted_data = cipher.decrypt(encrypted_msg)
        return decrypted_data
    except Exception as e:
        raise EncryptError(e)
