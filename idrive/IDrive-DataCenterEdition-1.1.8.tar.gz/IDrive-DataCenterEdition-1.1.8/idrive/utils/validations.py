'''common validation methods'''

import datetime
import os


def valid_path(path):
    '''Check if path is valid path
    The use of realpath() here also accounts for any relative path parts
    (ie contains '../' because realpath() will turn the path into an absolute
    path
    '''
    return os.path.realpath(path) == path


def time_occurs_after(earlier_time, later_time):
    '''check if the later time occurs after the given time in the day'''

    today = datetime.date.today()
    difference = (datetime.datetime.combine(today, later_time) -
                  datetime.datetime.combine(today, earlier_time))
    difference = int(difference.total_seconds())

    return difference > 0 and difference <= 24 * 60 * 60
