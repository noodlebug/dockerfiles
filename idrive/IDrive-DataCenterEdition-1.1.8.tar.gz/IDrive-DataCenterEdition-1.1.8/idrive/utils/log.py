'''Provides routines for generating application logs.

Application logs are written to a log file somewhere inside
user's home directory based on the global configuration.
debug(), info(), warning(), error() and critical() methods
generate the log messages. Whether a log generated
will be written to the log file or not
is determined by the GlobalSettings().LOGS.loglevel

'''

import logging
import logging.handlers as handlers
import os
import os.path as path
import pwd

from idrive.conf.settings import UserSettings, GlobalSettings
from idrive import SHORT_NAME


_logger = None
_user = None

_LOG_FORMAT = '%(asctime)s %(name)s: %(message)s'
_TIME_FORMAT = '%c'
_LOG_FILE_NAME = '{}_application.log'.format(SHORT_NAME)


def _get_formatted_message(message, mod_name, line_no):
    """Internal function to prepend the module
    name to the message to make the log more descriptive.
    """
    # do we need to reinitialize?
    if _user is not None and _user != pwd.getpwuid(os.getuid()).pw_name:
        init()

    msg = u""
    if mod_name is not None:
        msg += mod_name
    if line_no is not None:
        msg += str(line_no)
    if msg != u"":
        msg += u": "

    if isinstance(message, str):
        message = message.decode('utf8', 'replace')
    elif not isinstance(message, unicode):
        message = str(message).decode('utf8', 'replace')

    return u"{}{}".format(msg, message)


def init(name=None, log_handler=None):
    '''Initializes the logger.

     This must be called once during the initialization of the
     application for logging to work. Logging level is automatically
     picked up from GlobalSettings()

     log_handler can be set outside init and passed here. In such cases
     init() will not try to set a default handler by using the current
     username. Caller has to take care of permission etc. of the handler.
    '''
    # create the formatter, handler and logger on first invocation
    global _logger
    if _logger is None:
        _logger = logging.getLogger()

        # logger log level is always highest, the handler takes care of
        # filtering out necessary log level for the _user
        _logger.setLevel(logging.DEBUG)

    # for every invocation, set name and Level
    if name is not None:
        _logger.name = name

    # if handler is passed from outside, set it and return
    if log_handler is not None:
        try:
            _logger.removeHandler(_logger.handlers[0])
        except IndexError:
            pass
        _logger.addHandler(log_handler)
        return

    # otherwise set the log file path based on current user
    if os.getuid() == 0:
        settings = GlobalSettings()
    else:
        settings = UserSettings()
        if not os.path.exists(settings.LOGS.path):
            os.makedirs(settings.LOGS.path, mode=0700)

    global _user
    _user = pwd.getpwuid(os.getuid()).pw_name
    if (not _logger.handlers or
            _logger.handlers[0].name != _user):

        if _logger.handlers:
            _logger.removeHandler(_logger.handlers[0])

        formatter = logging.Formatter(_LOG_FORMAT, _TIME_FORMAT)

        handler = handlers.RotatingFileHandler(
            settings.LOGS.path + path.sep + _LOG_FILE_NAME,
            maxBytes=int(settings.LOGS.max_size),
            backupCount=int(settings.LOGS.max_log_files))
        handler.set_name(_user)
        handler.setFormatter(formatter)

        _logger.addHandler(handler)

    loglevel = logging.getLevelName(settings.LOGS.loglevel)
    if isinstance(loglevel, str):
        loglevel = logging.WARN
    _logger.handlers[0].setLevel(loglevel)


def debug(message, mod_name=None, line_no=None):
    '''Generate debug log.
    '''
    if _logger is not None:
        _logger.debug(_get_formatted_message(message, mod_name, line_no))


def info(message, mod_name=None, line_no=None):
    '''Generate information log.
    '''
    if _logger is not None:
        _logger.info(_get_formatted_message(message, mod_name, line_no))


def warning(message, mod_name=None, line_no=None):
    '''Generate warning log.
    '''
    if _logger is not None:
        _logger.warn(_get_formatted_message(message, mod_name, line_no))


def error(message, traceback=False, mod_name=None, line_no=None):
    '''Generate error log.
    '''
    if _logger is not None:
        _logger.error(_get_formatted_message(message, mod_name, line_no),
                      exc_info=traceback)


def critical(message, mod_name=None, line_no=None):
    '''Generate critical log.
    '''
    if _logger is not None:
        _logger.critical(_get_formatted_message(message, mod_name, line_no))


def log(level, message, traceback=False, mod_name=None, line_no=None):
    '''Generate critical log.
    '''
    if _logger is not None:
        _logger.log(level, _get_formatted_message(message, mod_name, line_no),
                    exc_info=traceback)


def get_handlers():
    '''Utility function to get the handlers currently registered.
    '''
    return _logger.handlers
